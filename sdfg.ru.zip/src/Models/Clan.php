<?php
/**
 * Модель клана
 */

class Clan extends Model {
    protected string $table = 'clans';

    // Роли в клане
    public const ROLE_YOUNG = 'young';
    public const ROLE_WARRIOR = 'warrior';
    public const ROLE_SOTNIK = 'sotnik';
    public const ROLE_SHAMAN = 'shaman';
    public const ROLE_CHIEF = 'chief';

    /**
     * Найти клан по названию
     */
    public function findByName(string $name): ?array {
        return $this->findOne(['name' => $name]);
    }

    /**
     * Найти клан по тегу
     */
    public function findByTag(string $tag): ?array {
        return $this->findOne(['tag' => $tag]);
    }

    /**
     * Получить клан игрока
     */
    public function getByPlayerId(int $playerId): ?array {
        $stmt = $this->db->prepare("
            SELECT c.* FROM {$this->table} c
            JOIN clan_members cm ON c.id = cm.clan_id
            WHERE cm.player_id = ?
        ");
        $stmt->execute([$playerId]);
        return $stmt->fetch() ?: null;
    }

    /**
     * Создать клан
     */
    public function createClan(string $name, string $tag, string $description, int $chiefId): int {
        $this->db->beginTransaction();
        try {
            $clanId = $this->create([
                'name' => $name,
                'tag' => $tag,
                'description' => $description,
                'bronze_treasury' => 0,
                'gold_treasury' => 0,
                'koumiss' => 0,
                'member_count' => 1,
                'max_members' => 20,
            ]);

            // Добавить вождя как первого члена
            $stmt = $this->db->prepare("
                INSERT INTO clan_members (clan_id, player_id, role, joined_at, contribution)
                VALUES (?, ?, ?, NOW(), 0)
            ");
            $stmt->execute([$clanId, $chiefId, self::ROLE_CHIEF]);

            // Обновить игрока
            $playerRepo = new PlayerRepository();
            $playerRepo->update($chiefId, [
                'clan_id' => $clanId,
                'clan_role' => self::ROLE_CHIEF,
            ]);

            $this->db->commit();
            return $clanId;
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    /**
     * Добавить члена в клан
     */
    public function addMember(int $clanId, int $playerId, string $role = self::ROLE_YOUNG): bool {
        $this->db->beginTransaction();
        try {
            // Добавить в clan_members
            $stmt = $this->db->prepare("
                INSERT INTO clan_members (clan_id, player_id, role, joined_at)
                VALUES (?, ?, ?, NOW())
            ");
            $stmt->execute([$clanId, $playerId, $role]);

            // Обновить игрока
            $playerRepo = new PlayerRepository();
            $playerRepo->update($playerId, [
                'clan_id' => $clanId,
                'clan_role' => $role,
            ]);

            // Увеличить счетчик
            $this->update($clanId, ['member_count' => $this->getField($clanId, 'member_count') + 1]);

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }

    /**
     * Удалить члена из клана
     */
    public function removeMember(int $clanId, int $playerId): bool {
        $this->db->beginTransaction();
        try {
            // Получить роль
            $member = $this->getMember($clanId, $playerId);
            $role = $member['role'] ?? '';

            // Удалить из clan_members
            $stmt = $this->db->prepare("DELETE FROM clan_members WHERE clan_id = ? AND player_id = ?");
            $stmt->execute([$clanId, $playerId]);

            // Сбросить клан у игрока
            $playerRepo = new PlayerRepository();
            $playerRepo->update($playerId, ['clan_id' => null, 'clan_role' => '']);

            // Уменьшить счетчик
            $this->update($clanId, ['member_count' => $this->getField($clanId, 'member_count') - 1]);

            // Если ушел вождь - передать лидерство
            if ($role === self::ROLE_CHIEF) {
                $this->transferLeadership($clanId);
            }

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }

    /**
     * Получить члена клана
     */
    public function getMember(int $clanId, int $playerId): ?array {
        $stmt = $this->db->prepare("
            SELECT * FROM clan_members
            WHERE clan_id = ? AND player_id = ?
        ");
        $stmt->execute([$clanId, $playerId]);
        return $stmt->fetch() ?: null;
    }

    /**
     * Получить всех членов клана
     */
    public function getMembers(int $clanId): array {
        $stmt = $this->db->prepare("
            SELECT cm.*, p.username, p.level, p.last_login_at
            FROM clan_members cm
            JOIN players p ON cm.player_id = p.id
            WHERE cm.clan_id = ?
            ORDER BY
                CASE cm.role
                    WHEN 'chief' THEN 1
                    WHEN 'shaman' THEN 2
                    WHEN 'sotnik' THEN 3
                    WHEN 'warrior' THEN 4
                    ELSE 5
                END,
                cm.joined_at ASC
        ");
        $stmt->execute([$clanId]);
        return $stmt->fetchAll();
    }

    /**
     * Передать лидерство
     */
    private function transferLeadership(int $clanId): void {
        // Найти старейшего сотника или шамана
        $stmt = $this->db->prepare("
            SELECT player_id FROM clan_members
            WHERE clan_id = ? AND role IN ('sotnik', 'shaman')
            ORDER BY joined_at ASC
            LIMIT 1
        ");
        $stmt->execute([$clanId]);
        $newChief = $stmt->fetch();

        if ($newChief) {
            $this->db->prepare("UPDATE clan_members SET role = 'chief' WHERE player_id = ?")->execute([$newChief['player_id']]);
            $playerRepo = new PlayerRepository();
            $playerRepo->update($newChief['player_id'], ['clan_role' => self::ROLE_CHIEF]);
        } else {
            // Распустить клан
            $this->delete($clanId);
        }
    }

    /**
     * Пожертвование в казну
     */
    public function donate(int $clanId, int $bronze = 0, int $gold = 0, int $koumiss = 0): bool {
        $clan = $this->find($clanId);
        if (!$clan) return false;

        return $this->update($clanId, [
            'bronze_treasury' => $clan['bronze_treasury'] + $bronze,
            'gold_treasury' => $clan['gold_treasury'] + $gold,
            'koumiss' => $clan['koumiss'] + $koumiss,
        ]);
    }

    /**
     * Улучшить здание
     */
    public function upgradeBuilding(int $clanId, string $buildingType): bool {
        $clan = $this->find($clanId);
        if (!$clan) return false;

        $currentLevel = $clan[$buildingType] ?? 1;
        $costBronze = 100 * ($currentLevel + 1);
        $costGold = 10 * ($currentLevel + 1);

        if ($clan['bronze_treasury'] < $costBronze || $clan['gold_treasury'] < $costGold) {
            return false;
        }

        return $this->update($clanId, [
            'bronze_treasury' => $clan['bronze_treasury'] - $costBronze,
            'gold_treasury' => $clan['gold_treasury'] - $costGold,
            $buildingType => $currentLevel + 1,
        ]);
    }

    /**
     * Сбросить кумыс (еженедельно)
     */
    public function resetKoumiss(): void {
        $this->db->exec("UPDATE {$this->table} SET koumiss = 0");
    }

    private function getField(int $id, string $field): int {
        $record = $this->find($id);
        return $record[$field] ?? 0;
    }
}
