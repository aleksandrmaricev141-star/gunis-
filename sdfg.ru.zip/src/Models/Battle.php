<?php
/**
 * Модель боя
 */

class Battle extends Model {
    protected string $table = 'battles';

    // Типы боев
    public const TYPE_ARENA = 'arena';
    public const TYPE_PVP = 'pvp';
    public const TYPE_CAMPAIGN = 'campaign';
    public const TYPE_SIEGE = 'siege';
    public const TYPE_RAID = 'raid';

    /**
     * Создать запись о бое
     */
    public function createBattle(array $data): int {
        return $this->create(array_merge($data, [
            'created_at' => date('Y-m-d H:i:s'),
        ]));
    }

    /**
     * Получить историю боев игрока
     */
    public function getPlayerHistory(int $playerId, int $limit = 20, int $offset = 0): array {
        $stmt = $this->db->prepare("
            SELECT * FROM {$this->table}
            WHERE player_id = ?
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$playerId, $limit, $offset]);
        return $stmt->fetchAll();
    }

    /**
     * Получить статистику боев игрока
     */
    public function getPlayerStats(int $playerId): array {
        $stmt = $this->db->prepare("
            SELECT
                COUNT(*) as total_battles,
                SUM(CASE WHEN is_victory = 1 THEN 1 ELSE 0 END) as victories,
                SUM(CASE WHEN is_victory = 0 THEN 1 ELSE 0 END) as defeats,
                SUM(damage_dealt) as total_damage,
                SUM(exp_gained) as total_exp,
                SUM(bronze_gained) as total_bronze
            FROM {$this->table}
            WHERE player_id = ?
        ");
        $stmt->execute([$playerId]);
        return $stmt->fetch();
    }

    /**
     * Проверить кулдаун арены
     */
    public function checkArenaCooldown(int $playerId, int $cooldownSeconds): array {
        $stmt = $this->db->prepare("
            SELECT created_at FROM {$this->table}
            WHERE player_id = ? AND battle_type = ?
            ORDER BY created_at DESC
            LIMIT 1
        ");
        $stmt->execute([$playerId, self::TYPE_ARENA]);
        $lastBattle = $stmt->fetch();

        if (!$lastBattle) {
            return ['on_cooldown' => false, 'remaining' => 0];
        }

        $lastBattleTime = strtotime($lastBattle['created_at']);
        $elapsed = time() - $lastBattleTime;
        $remaining = max(0, $cooldownSeconds - $elapsed);

        return [
            'on_cooldown' => $remaining > 0,
            'remaining' => $remaining,
        ];
    }

    /**
     * Посчитать количество боев сегодня
     */
    public function getTodayBattleCount(int $playerId): int {
        $today = date('Y-m-d 00:00:00');
        $stmt = $this->db->prepare("
            SELECT COUNT(*) as count FROM {$this->table}
            WHERE player_id = ? AND battle_type = ? AND created_at >= ?
        ");
        $stmt->execute([$playerId, self::TYPE_ARENA, $today]);
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    }

    /**
     * Сохранить лог боя (в отдельную таблицу)
     */
    public function saveLog(int $battleId, array $log): void {
        foreach ($log as $round => $entry) {
            $this->db->prepare("
                INSERT INTO battle_logs (battle_id, round, message, damage, is_critical, is_block)
                VALUES (?, ?, ?, ?, ?, ?)
            ")->execute([
                $battleId,
                $round,
                $entry['message'],
                $entry['damage'] ?? 0,
                $entry['is_critical'] ?? 0,
                $entry['is_block'] ?? 0,
            ]);
        }
    }

    /**
     * Получить лог боя
     */
    public function getLog(int $battleId): array {
        $stmt = $this->db->prepare("
            SELECT * FROM battle_logs WHERE battle_id = ? ORDER BY round ASC
        ");
        $stmt->execute([$battleId]);
        return $stmt->fetchAll();
    }
}
