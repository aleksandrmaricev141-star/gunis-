<?php
/**
 * Модель предмета
 */

class Item extends Model {
    protected string $table = 'items';

    // Типы предметов
    public const TYPE_WEAPON = 'weapon';
    public const TYPE_HELMET = 'helmet';
    public const TYPE_ARMOR = 'armor';
    public const TYPE_BOOTS = 'boots';
    public const TYPE_AMULET = 'amulet';
    public const TYPE_RUNE = 'rune';
    public const TYPE_MATERIAL = 'material';
    public const TYPE_POTION = 'potion';

    // Редкость
    public const RARITY_COMMON = 'common';
    public const RARITY_UNCOMMON = 'uncommon';
    public const RARITY_RARE = 'rare';
    public const RARITY_EPIC = 'epic';
    public const RARITY_LEGENDARY = 'legendary';

    /**
     * Получить все предметы игрока
     */
    public function getByPlayer(int $playerId): array {
        $stmt = $this->db->prepare("
            SELECT * FROM {$this->table}
            WHERE player_id = ?
            ORDER BY is_equipped DESC, rarity DESC, enhance_level DESC
        ");
        $stmt->execute([$playerId]);
        return $stmt->fetchAll();
    }

    /**
     * Получить экипированные предметы
     */
    public function getEquipped(int $playerId): array {
        $stmt = $this->db->prepare("
            SELECT * FROM {$this->table}
            WHERE player_id = ? AND is_equipped = 1
        ");
        $stmt->execute([$playerId]);
        return $stmt->fetchAll();
    }

    /**
     * Получить предмет по ID с проверкой владельца
     */
    public function getByPlayerAndId(int $playerId, int $itemId): ?array {
        return $this->findOne(['id' => $itemId, 'player_id' => $playerId]);
    }

    /**
     * Создать предмет
     */
    public function createItem(int $playerId, array $itemData): int {
        return $this->create(array_merge([
            'player_id' => $playerId,
            'created_at' => date('Y-m-d H:i:s'),
        ], $itemData));
    }

    /**
     * Надеть предмет
     */
    public function equip(int $playerId, int $itemId, string $type): bool {
        $this->db->beginTransaction();
        try {
            // Снять аналогичный предмет
            $stmt = $this->db->prepare("
                UPDATE {$this->table}
                SET is_equipped = 0
                WHERE player_id = ? AND type = ? AND is_equipped = 1
            ");
            $stmt->execute([$playerId, $type]);

            // Надеть новый
            $stmt = $this->db->prepare("
                UPDATE {$this->table}
                SET is_equipped = 1
                WHERE id = ? AND player_id = ?
            ");
            $stmt->execute([$itemId, $playerId]);

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }

    /**
     * Снять предмет
     */
    public function unequip(int $itemId): bool {
        return $this->update($itemId, ['is_equipped' => 0]);
    }

    /**
     * Улучшить предмет (заточка)
     */
    public function enhance(int $itemId, int $level): bool {
        return $this->update($itemId, ['enhance_level' => $level]);
    }

    /**
     * Удалить предмет
     */
    public function remove(int $itemId): bool {
        return $this->delete($itemId);
    }

    /**
     * Генерация случайного предмета (дроп)
     */
    public function generateDrop(int $playerId, int $enemyLevel, bool $isElite = false): array {
        $config = require __DIR__ . '/../../config/config.php';

        // Шансы редкости
        $rarityChances = $isElite ? [
            self::RARITY_COMMON => 30,
            self::RARITY_UNCOMMON => 30,
            self::RARITY_RARE => 25,
            self::RARITY_EPIC => 10,
            self::RARITY_LEGENDARY => 5,
        ] : [
            self::RARITY_COMMON => 60,
            self::RARITY_UNCOMMON => 25,
            self::RARITY_RARE => 10,
            self::RARITY_EPIC => 4,
            self::RARITY_LEGENDARY => 1,
        ];

        $rarity = $this->getRandomRarity($rarityChances);

        // Базовые названия предметов
        $names = [
            self::TYPE_WEAPON => ['Ржавый акинак', 'Скифский меч', 'Копье кочевника', 'Лук степи'],
            self::TYPE_HELMET => ['Кожаный шлем', 'Медный шлем', 'Шлем вождя'],
            self::TYPE_ARMOR => ['Кожаный панцирь', 'Медная чешуя', 'Доспех сармата'],
            self::TYPE_BOOTS => ['Кожаные сапоги', 'Сапоги всадника'],
        ];

        $type = array_rand($names);
        $nameList = $names[$type];
        $name = $nameList[array_rand($nameList)];

        // Бонусы в зависимости от редкости
        $bonusMultiplier = [
            self::RARITY_COMMON => 1,
            self::RARITY_UNCOMMON => 2,
            self::RARITY_RARE => 3,
            self::RARITY_EPIC => 5,
            self::RARITY_LEGENDARY => 10,
        ][$rarity];

        $itemData = [
            'name' => $name,
            'type' => $type,
            'rarity' => $rarity,
            'bonus_rage' => rand(1, 3) * $bonusMultiplier,
            'bonus_blood' => rand(1, 2) * $bonusMultiplier,
            'bonus_scale' => rand(1, 2) * $bonusMultiplier,
            'enhance_level' => 0,
            'is_equipped' => 0,
            'stackable' => 0,
            'stack_size' => 1,
        ];

        $itemId = $this->createItem($playerId, $itemData);
        $itemData['id'] = $itemId;

        return $itemData;
    }

    private function getRandomRarity(array $chances): string {
        $total = array_sum($chances);
        $rand = rand(1, $total);
        $cumulative = 0;

        foreach ($chances as $rarity => $chance) {
            $cumulative += $chance;
            if ($rand <= $cumulative) {
                return $rarity;
            }
        }

        return self::RARITY_COMMON;
    }
}
