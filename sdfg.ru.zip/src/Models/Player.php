<?php
/**
 * Модель игрока
 */

class Player extends Model {
    protected string $table = 'players';

    /**
     * Найти игрока по имени пользователя
     */
    public function findByUsername(string $username): ?array {
        return $this->findOne(['username' => $username]);
    }

    /**
     * Найти игрока по email
     */
    public function findByEmail(string $email): ?array {
        return $this->findOne(['email' => $email]);
    }

    /**
     * Создать нового игрока
     */
    public function createPlayer(string $username, string $email, string $passwordHash): int {
        $config = require __DIR__ . '/../../config/config.php';
        $game = $config['game'];

        $maxHp = 100 + 1 * 10; // Базовое HP

        return $this->create([
            'username' => $username,
            'email' => $email,
            'password_hash' => $passwordHash,
            'level' => 1,
            'experience' => 0,
            'experience_to_next' => 100,
            'rage_steppe' => 1,
            'blood_nomad' => 1,
            'copper_scale' => 1,
            'bronze_tips' => $game['starting_bronze'],
            'gold_kurgan' => $game['starting_gold'],
            'current_hp' => $maxHp,
            'max_hp' => $maxHp,
            'amulet_level' => 1,
        ]);
    }

    /**
     * Обновить ресурсы игрока
     */
    public function updateResources(int $id, array $resources): bool {
        return $this->update($id, $resources);
    }

    /**
     * Добавить опыт игроку
     */
    public function addExperience(int $id, int $exp): bool {
        $player = $this->find($id);
        if (!$player) return false;

        $newExp = $player['experience'] + $exp;
        $newLevel = $player['level'];
        $expToNext = $player['experience_to_next'];

        // Проверка на повышение уровня
        while ($newExp >= $expToNext) {
            $newLevel++;
            $expToNext = (int) ($expToNext * 1.5);
        }

        return $this->update($id, [
            'experience' => $newExp,
            'level' => $newLevel,
            'experience_to_next' => $expToNext,
        ]);
    }

    /**
     * Тренировать параметр
     */
    public function trainStat(int $id, string $stat): array {
        $player = $this->find($id);
        if (!$player) {
            return ['success' => false, 'error' => 'Player not found'];
        }

        $config = require __DIR__ . '/../../config/config.php';
        $baseCost = $config['game']['training_base_cost'];
        $multiplier = $config['game']['training_cost_multiplier'];

        $currentLevel = $player[$stat];
        $cost = (int) ($baseCost * pow($multiplier, $currentLevel));

        if ($player['bronze_tips'] < $cost) {
            return ['success' => false, 'error' => 'Недостаточно бронзовых наконечников'];
        }

        // Списываем бронзу и увеличиваем параметр
        $this->update($id, [
            'bronze_tips' => $player['bronze_tips'] - $cost,
            $stat => $currentLevel + 1,
        ]);

        // Пересчитываем HP если тренировали кровь
        if ($stat === 'blood_nomad') {
            $newMaxHp = 100 + ($player['blood_nomad'] + 1) * 10;
            $this->update($id, ['max_hp' => $newMaxHp, 'current_hp' => $newMaxHp]);
        }

        return [
            'success' => true,
            'cost' => $cost,
            'new_level' => $currentLevel + 1,
        ];
    }

    /**
     * Получить максимальное HP
     */
    public function getMaxHp(int $bloodNomad): int {
        return 100 + $bloodNomad * 10;
    }

    /**
     * Получить базовый урон
     */
    public function getDamage(int $rageSteppe): int {
        return 5 + $rageSteppe * 3;
    }

    /**
     * Получить броню
     */
    public function getArmor(int $copperScale): int {
        return $copperScale * 2;
    }
}
