<?php
/**
 * Репозиторий игрока
 */

class PlayerRepository extends Player {
    /**
     * Проверка пароля
     */
    public function verifyPassword(string $password, string $hash): bool {
        return password_verify($password, $hash);
    }

    /**
     * Хэширование пароля
     */
    public function hashPassword(string $password): string {
        return password_hash($password, PASSWORD_DEFAULT);
    }

    /**
     * Обновить последнюю активность
     */
    public function updateLastActivity(int $id): void {
        $this->update($id, ['last_login_at' => date('Y-m-d H:i:s')]);
    }

    /**
     * Установить онлайн статус
     */
    public function setOnline(int $id, bool $online): void {
        $this->update($id, ['is_online' => $online ? 1 : 0]);
    }

    /**
     * Получить игроков для PvP (онлайн, схожий уровень)
     */
    public function findPvPOpponents(int $playerId, int $level, int $limit = 10): array {
        $minLevel = max(1, $level - 2);
        $maxLevel = $level + 2;

        $stmt = $this->db->prepare("
            SELECT id, username, level, rage_steppe, blood_nomad, copper_scale, current_hp, max_hp
            FROM players
            WHERE id != ?
            AND is_online = 1
            AND level BETWEEN ? AND ?
            AND clan_id IS NOT NULL
            ORDER BY RAND()
            LIMIT ?
        ");
        $stmt->execute([$playerId, $minLevel, $maxLevel, $limit]);
        return $stmt->fetchAll();
    }

    /**
     * Получить топ игроков
     */
    public function getTopPlayers(int $limit = 10): array {
        $stmt = $this->db->prepare("
            SELECT id, username, level, experience, rage_steppe, blood_nomad, copper_scale
            FROM players
            ORDER BY experience DESC
            LIMIT ?
        ");
        $stmt->execute([$limit]);
        return $stmt->fetchAll();
    }

    /**
     * Получить статистику игрока
     */
    public function getStats(int $id): ?array {
        $player = $this->find($id);
        if (!$player) return null;

        return [
            'max_hp' => $player['max_hp'],
            'damage' => $this->getDamage($player['rage_steppe']),
            'armor' => $this->getArmor($player['copper_scale']),
            'crit_chance' => min(50, $player['rage_steppe'] * 2), // Макс 50%
            'block_chance' => min(30, $player['copper_scale'] * 1.5), // Макс 30%
        ];
    }
}
