<?php
/**
 * Сервис боевой системы
 */

class BattleService {
    private Battle $battleModel;
    private PlayerRepository $playerRepo;
    private Item $itemModel;

    public function __construct() {
        $this->battleModel = new Battle();
        $this->playerRepo = new PlayerRepository();
        $this->itemModel = new Item();
    }

    /**
     * Провести бой на арене (PvE)
     */
    public function arenaFight(int $playerId): array {
        $player = $this->playerRepo->find($playerId);
        if (!$player) {
            return ['success' => false, 'error' => 'Игрок не найден'];
        }

        // Проверка кулдауна
        $config = require __DIR__ . '/../../config/config.php';
        $cooldown = $config['game']['arena_cooldown'];
        $cooldownCheck = $this->battleModel->checkArenaCooldown($playerId, $cooldown);

        if ($cooldownCheck['on_cooldown']) {
            return [
                'success' => false,
                'error' => 'Арена на кулдауне',
                'cooldown_remaining' => $cooldownCheck['remaining'],
            ];
        }

        // Проверка лимита боев
        $battleCount = $this->battleModel->getTodayBattleCount($playerId);
        $maxBattles = $config['game']['arena_battle_count'];

        if ($battleCount >= $maxBattles) {
            return ['success' => false, 'error' => 'Достигнут лимит боев сегодня'];
        }

        // Генерация врага
        $enemy = $this->generateEnemy($player['level']);

        // Боевой цикл
        $battleResult = $this->simulateBattle($player, $enemy);

        // Награды
        $expGained = $battleResult['is_victory'] ? $enemy['exp_reward'] : (int)($enemy['exp_reward'] * 0.5);
        $bronzeGained = $battleResult['is_victory'] ? $enemy['bronze_reward'] : (int)($enemy['bronze_reward'] * 0.5);
        $goldGained = 0;

        // Шанс выпадения золота с элитных врагов
        if ($enemy['is_elite'] && $battleResult['is_victory'] && rand(1, 100) <= 10) {
            $goldGained = 1;
        }

        // Сохранение боя
        $battleId = $this->battleModel->createBattle([
            'player_id' => $playerId,
            'enemy_name' => $enemy['name'],
            'battle_type' => Battle::TYPE_ARENA,
            'is_victory' => $battleResult['is_victory'] ? 1 : 0,
            'damage_dealt' => $battleResult['damage_dealt'],
            'damage_received' => $battleResult['damage_received'],
            'critical_hits' => $battleResult['critical_hits'],
            'rounds' => $battleResult['rounds'],
            'exp_gained' => $expGained,
            'bronze_gained' => $bronzeGained,
            'gold_gained' => $goldGained,
        ]);

        // Обновление игрока
        $newHp = $battleResult['is_victory']
            ? min($player['current_hp'] + 10, $player['max_hp'])
            : max(1, $player['current_hp'] - $battleResult['damage_received']);

        $this->playerRepo->update($playerId, [
            'current_hp' => $newHp,
            'bronze_tips' => $player['bronze_tips'] + $bronzeGained,
            'gold_kurgan' => $player['gold_kurgan'] + $goldGained,
        ]);

        $this->playerRepo->addExperience($playerId, $expGained);

        // Генерация дропа
        $drop = null;
        if ($battleResult['is_victory'] && rand(1, 100) <= 30) {
            $drop = $this->itemModel->generateDrop($playerId, $enemy['level'], $enemy['is_elite']);
        }

        return [
            'success' => true,
            'battle_id' => $battleId,
            'is_victory' => $battleResult['is_victory'],
            'enemy_name' => $enemy['name'],
            'damage_dealt' => $battleResult['damage_dealt'],
            'damage_received' => $battleResult['damage_received'],
            'critical_hits' => $battleResult['critical_hits'],
            'rounds' => $battleResult['rounds'],
            'exp_gained' => $expGained,
            'bronze_gained' => $bronzeGained,
            'gold_gained' => $goldGained,
            'log' => $battleResult['log'],
            'drop' => $drop,
            'player_hp' => $newHp,
        ];
    }

    /**
     * Симуляция боя
     */
    private function simulateBattle(array $player, array $enemy): array {
        $playerHp = $player['current_hp'];
        $enemyHp = $enemy['hp'];
        $playerDamage = $this->playerRepo->getDamage($player['rage_steppe']);
        $playerArmor = $this->playerRepo->getArmor($player['copper_scale']);
        $critChance = min(50, $player['rage_steppe'] * 2);
        $blockChance = min(30, $player['copper_scale'] * 1.5);

        $log = [];
        $round = 0;
        $totalDamageDealt = 0;
        $totalDamageReceived = 0;
        $criticalHits = 0;

        while ($playerHp > 0 && $enemyHp > 0 && $round < 50) {
            $round++;

            // Ход игрока
            $isCrit = rand(1, 100) <= $critChance;
            $damage = $playerDamage;
            if ($isCrit) {
                $damage = (int)($damage * 2);
                $criticalHits++;
            }

            // Учет брони врага (упрощенно)
            $actualDamage = max(1, $damage - (int)($enemy['armor'] * 0.5));
            $enemyHp -= $actualDamage;
            $totalDamageDealt += $actualDamage;

            $log[] = [
                'round' => $round,
                'message' => "Вы наносите {$actualDamage} урона " . ($isCrit ? "(КРИТ!)" : ""),
                'damage' => $actualDamage,
                'is_critical' => $isCrit,
            ];

            if ($enemyHp <= 0) break;

            // Ход врага
            $isBlock = rand(1, 100) <= $blockChance;
            $enemyDamage = max(1, $enemy['damage'] - (int)($playerArmor * 0.5));
            if ($isBlock) {
                $enemyDamage = (int)($enemyDamage * 0.5);
            }

            $playerHp -= $enemyDamage;
            $totalDamageReceived += $enemyDamage;

            $log[] = [
                'round' => $round,
                'message' => "Враг наносит {$enemyDamage} урона " . ($isBlock ? "(БЛОК!)" : ""),
                'damage' => $enemyDamage,
                'is_block' => $isBlock,
            ];
        }

        return [
            'is_victory' => $enemyHp <= 0,
            'damage_dealt' => $totalDamageDealt,
            'damage_received' => $totalDamageReceived,
            'critical_hits' => $criticalHits,
            'rounds' => $round,
            'log' => $log,
        ];
    }

    /**
     * Генерация врага
     */
    private function generateEnemy(int $playerLevel): array {
        $enemies = [
            ['name' => 'Дикий кабан', 'level' => 1, 'hp' => 50, 'damage' => 5, 'armor' => 0, 'exp_reward' => 10, 'bronze_reward' => 5],
            ['name' => 'Кочевник-изгой', 'level' => 2, 'hp' => 70, 'damage' => 8, 'armor' => 2, 'exp_reward' => 15, 'bronze_reward' => 8],
            ['name' => 'Греческий дезертир', 'level' => 3, 'hp' => 90, 'damage' => 10, 'armor' => 5, 'exp_reward' => 20, 'bronze_reward' => 12],
            ['name' => 'Разбойник', 'level' => 4, 'hp' => 110, 'damage' => 12, 'armor' => 7, 'exp_reward' => 25, 'bronze_reward' => 15],
            ['name' => 'Воин чужого племени', 'level' => 5, 'hp' => 130, 'damage' => 15, 'armor' => 10, 'exp_reward' => 30, 'bronze_reward' => 20],
        ];

        $eliteEnemies = [
            ['name' => 'Римский центурион', 'level' => 10, 'hp' => 300, 'damage' => 25, 'armor' => 20, 'exp_reward' => 100, 'bronze_reward' => 50, 'is_elite' => true],
            ['name' => 'Вождь сарматов', 'level' => 15, 'hp' => 500, 'damage' => 35, 'armor' => 30, 'exp_reward' => 200, 'bronze_reward' => 100, 'is_elite' => true],
        ];

        // 10% шанс элитного врага
        if (rand(1, 100) <= 10) {
            $baseEnemy = $eliteEnemies[array_rand($eliteEnemies)];
        } else {
            $index = min($playerLevel - 1, count($enemies) - 1);
            $baseEnemy = $enemies[$index];
        }

        return array_merge([
            'is_elite' => false,
            'hp' => $baseEnemy['hp'],
        ], $baseEnemy);
    }

    /**
     * PvP бой
     */
    public function pvpFight(int $playerId, int $enemyId): array {
        $player = $this->playerRepo->find($playerId);
        $enemy = $this->playerRepo->find($enemyId);

        if (!$player || !$enemy) {
            return ['success' => false, 'error' => 'Игрок не найден'];
        }

        // Упрощенная симуляция PvP
        $playerPower = $player['rage_steppe'] * 3 + $player['blood_nomad'] * 2 + $player['copper_scale'] * 2;
        $enemyPower = $enemy['rage_steppe'] * 3 + $enemy['blood_nomad'] * 2 + $enemy['copper_scale'] * 2;

        // Случайный фактор
        $playerPower += rand(-10, 10);
        $enemyPower += rand(-10, 10);

        $isVictory = $playerPower >= $enemyPower;

        $expGained = $isVictory ? 50 : 25;
        $bronzeGained = $isVictory ? 30 : 15;

        $battleId = $this->battleModel->createBattle([
            'player_id' => $playerId,
            'enemy_id' => $enemyId,
            'enemy_name' => $enemy['username'],
            'battle_type' => Battle::TYPE_PVP,
            'is_victory' => $isVictory ? 1 : 0,
            'damage_dealt' => rand(50, 100),
            'damage_received' => rand(30, 80),
            'exp_gained' => $expGained,
            'bronze_gained' => $bronzeGained,
        ]);

        // Обновление ресурсов
        $this->playerRepo->update($playerId, [
            'bronze_tips' => $player['bronze_tips'] + $bronzeGained,
        ]);
        $this->playerRepo->addExperience($playerId, $expGained);

        return [
            'success' => true,
            'battle_id' => $battleId,
            'is_victory' => $isVictory,
            'enemy_name' => $enemy['username'],
            'exp_gained' => $expGained,
            'bronze_gained' => $bronzeGained,
        ];
    }
}
