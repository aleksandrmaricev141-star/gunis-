<?php
/**
 * СКИФЫ - Контроллер боя
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;

class BattleController extends BaseController
{
    public function __construct(Auth $auth, Database $db)
    {
        parent::__construct($auth, $db);
    }

    public function indexAction(): void
    {
        $userId = $this->getUserId();

        $stats = $this->db->fetchOne(
            'SELECT energy, max_energy, battle_count_today, battle_cooldown_until,
                    fury_steppe, blood_nomad, copper_scale, current_hp
             FROM hero_stats WHERE user_id = ?',
            [$userId]
        );

        $level = $this->db->fetchValue(
            'SELECT level FROM hero_stats WHERE user_id = ?',
            [$userId]
        ) ?? 1;

        $enemies = $this->db->fetchAll(
            'SELECT id, name, base_level, base_hp, base_fury, base_copper, 
                    exp_reward, bronze_reward_min, bronze_reward_max, category, icon
             FROM enemy_types
             WHERE base_level <= ?
             ORDER BY base_level ASC
             LIMIT 10',
            [$level + 3]
        );

        $canFight = true;
        $cooldownSeconds = 0;

        if ($stats && $stats['battle_cooldown_until'] && strtotime($stats['battle_cooldown_until']) > time()) {
            $canFight = false;
            $cooldownSeconds = strtotime($stats['battle_cooldown_until']) - time();
        }

        if ($stats && $stats['battle_count_today'] >= MAX_BATTLES_PER_DAY) {
            $canFight = false;
        }

        if ($stats && $stats['energy'] <= 0) {
            $canFight = false;
        }

        $this->render('battle/index', [
            'title' => 'Дикое Поле',
            'stats' => $stats,
            'enemies' => $enemies,
            'canFight' => $canFight,
            'cooldownSeconds' => $cooldownSeconds,
        ]);
    }

    public function startAction(): void
    {
        $this->requireAjax();
        $this->requirePost();

        if (!$this->verifyCsrf()) {
            $this->json(['error' => 'Ошибка безопасности'], 400);
            return;
        }

        $userId = $this->getUserId();
        $enemyId = $this->postInt('enemy_id');

        if (!$enemyId) {
            $this->json(['error' => 'Выберите врага'], 400);
            return;
        }

        $stats = $this->db->fetchOne(
            'SELECT energy, battle_count_today, battle_cooldown_until 
             FROM hero_stats WHERE user_id = ?',
            [$userId]
        );

        if (!$stats || $stats['energy'] <= 0) {
            $this->json(['error' => 'Недостаточно энергии'], 400);
            return;
        }

        if ($stats['battle_count_today'] >= MAX_BATTLES_PER_DAY) {
            $this->json(['error' => 'Лимит боёв достигнут'], 400);
            return;
        }

        $enemy = $this->db->fetchOne(
            'SELECT * FROM enemy_types WHERE id = ?',
            [$enemyId]
        );

        if (!$enemy) {
            $this->json(['error' => 'Враг не найден'], 400);
            return;
        }

        $playerPower = ($stats['fury_steppe'] * 2) + ($stats['blood_nomad'] / 10) + ($stats['copper_scale'] * 1.5);
        $enemyPower = ($enemy['base_fury'] * 2) + ($enemy['base_hp'] / 10) + ($enemy['base_copper'] * 1.5);

        $winChance = 0.5 + ($playerPower - $enemyPower) / 100;
        $winChance = max(0.2, min(0.8, $winChance));

        $isWin = rand(0, 100) / 100 < $winChance;

        $expReward = $enemy['exp_reward'];
        $bronzeReward = rand($enemy['bronze_reward_min'], $enemy['bronze_reward_max']);
        $goldReward = (rand(0, 100) / 100 < $enemy['gold_drop_chance']) ? 1 : 0;

        $this->db->update('hero_stats', [
            'energy' => $stats['energy'] - 1,
            'battle_count_today' => $stats['battle_count_today'] + 1,
            'battle_cooldown_until' => date('Y-m-d H:i:s', time() + BATTLE_COOLDOWN),
        ], 'user_id = ?', [$userId]);

        if ($isWin) {
            $currentExp = $this->db->fetchValue('SELECT experience FROM hero_stats WHERE user_id = ?', [$userId]);
            $this->db->update('hero_stats', [
                'experience' => $currentExp + $expReward,
            ], 'user_id = ?', [$userId]);

            $currentBronze = $this->db->fetchValue('SELECT bronze FROM user_currency WHERE user_id = ?', [$userId]);
            $currentGold = $this->db->fetchValue('SELECT gold FROM user_currency WHERE user_id = ?', [$userId]);
            
            $this->db->update('user_currency', [
                'bronze' => $currentBronze + $bronzeReward,
                'gold' => $currentGold + $goldReward,
            ], 'user_id = ?', [$userId]);

            $this->db->insert('battles', [
                'user_id' => $userId,
                'enemy_id' => $enemyId,
                'battle_type' => 'pve',
                'result' => 'win',
                'exp_gained' => $expReward,
                'bronze_gained' => $bronzeReward,
                'gold_gained' => $goldReward,
            ]);
        } else {
            $this->db->insert('battles', [
                'user_id' => $userId,
                'enemy_id' => $enemyId,
                'battle_type' => 'pve',
                'result' => 'lose',
            ]);
        }

        $this->json([
            'success' => true,
            'win' => $isWin,
            'exp' => $expReward,
            'bronze' => $bronzeReward,
            'gold' => $goldReward,
            'message' => $isWin ? '🎉 Победа!' : '💀 Поражение...',
        ]);
    }
}
