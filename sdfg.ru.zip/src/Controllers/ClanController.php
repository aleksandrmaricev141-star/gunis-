<?php
/**
 * СКИФЫ - Контроллер клана
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;

class ClanController extends BaseController
{
    public function __construct(Auth $auth, Database $db)
    {
        parent::__construct($auth, $db);
    }

    /**
     * Страница клана
     */
    public function indexAction(): void
    {
        $userId = $this->getUserId();

        // Проверяем, состоит ли игрок в клане
        $clanMember = $this->db->fetchOne(
            'SELECT cm.*, c.name, c.tag, c.level, c.description
             FROM clan_members cm
             JOIN clans c ON cm.clan_id = c.id
             WHERE cm.user_id = :id AND cm.is_approved = 1',
            ['id' => $userId]
        );

        if ($clanMember) {
            // Игрок в клане - показываем информацию
            $this->render('clan/view', [
                'title' => 'Племя',
                'clan' => $clanMember,
            ]);
        } else {
            // Игрок без клана - показываем список кланов
            $clans = $this->db->fetchAll(
                'SELECT c.*, u.username AS leader_name,
                        (SELECT COUNT(*) FROM clan_members WHERE clan_id = c.id AND is_approved = 1) AS member_count
                 FROM clans c
                 JOIN users u ON c.leader_id = u.id
                 ORDER BY c.siege_rating DESC
                 LIMIT 20'
            );

            $this->render('clan/list', [
                'title' => 'Племена',
                'clans' => $clans,
            ]);
        }
    }
}
