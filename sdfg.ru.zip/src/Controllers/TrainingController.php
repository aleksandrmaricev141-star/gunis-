<?php
/**
 * СКИФЫ - Контроллер тренировки
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;

use function BASE_URL;
use function redirect;

class TrainingController extends BaseController
{
    public function __construct(Auth $auth, Database $db)
    {
        parent::__construct($auth, $db);
    }

    /**
     * Страница тренировки
     */
    public function indexAction(): void
    {
        $userId = $this->getUserId();

        // Получаем данные героя
        $stats = $this->db->fetchOne(
            'SELECT hs.*, uc.bronze
             FROM hero_stats hs
             JOIN user_currency uc ON hs.user_id = uc.user_id
             WHERE hs.user_id = :id',
            ['id' => $userId]
        );

        if (!$stats) {
            $this->redirect(BASE_URL . '/profile');
            return;
        }

        // Расчёт стоимости прокачки
        $costs = [
            'fury_steppe' => $this->calcStatCost($stats['fury_steppe']),
            'blood_nomad' => $this->calcStatCost($stats['blood_nomad']),
            'copper_scale' => $this->calcStatCost($stats['copper_scale']),
        ];

        $this->render('training/index', [
            'title' => 'Тренировка',
            'stats' => $stats,
            'costs' => $costs,
        ]);
    }

    /**
     * Расчёт стоимости прокачки стата
     */
    private function calcStatCost(int $stat): int
    {
        return (int)(STAT_COST_BASE * pow(STAT_COST_MULTIPLIER, $stat / 10));
    }

    /**
     * Прокачка характеристики (AJAX)
     */
    public function trainAction(): void
    {
        $this->requireAjax();
        $this->requirePost();

        if (!$this->verifyCsrf()) {
            $this->json(['error' => 'Ошибка безопасности'], 400);
            return;
        }

        $userId = $this->getUserId();
        $statType = $this->postString('stat_type');
        $amount = $this->postInt('amount', 1);

        // Проверка типа стата
        $validStats = ['fury_steppe', 'blood_nomad', 'copper_scale'];
        if (!in_array($statType, $validStats)) {
            $this->json(['error' => 'Неверный тип характеристики'], 400);
            return;
        }

        // Получаем текущие данные
        $data = $this->db->fetchOne(
            'SELECT hs.stat_points, hs.fury_steppe, hs.blood_nomad, hs.copper_scale, uc.bronze
             FROM hero_stats hs
             JOIN user_currency uc ON hs.user_id = uc.user_id
             WHERE hs.user_id = :id',
            ['id' => $userId]
        );

        if ($data['stat_points'] < $amount) {
            $this->json(['error' => 'Недостаточно очков характеристик'], 400);
            return;
        }

        // Расчёт стоимости
        $cost = $this->calcStatCost($data[$statType]);

        if ($data['bronze'] < $cost) {
            $this->json(['error' => 'Недостаточно бронзы. Нужно: ' . $cost], 400);
            return;
        }

        $this->db->beginTransaction();
        try {
            // Увеличиваем стат
            $this->db->update('hero_stats', [
                $statType => $data[$statType] + $amount,
                'stat_points' => $data['stat_points'] - $amount,
            ], 'user_id = :id', ['id' => $userId]);

            // Если увеличили кровь - увеличиваем и текущее HP
            if ($statType === 'blood_nomad') {
                $this->db->update('hero_stats', [
                    'current_hp' => $data['blood_nomad'] + $amount,
                ], 'user_id = :id', ['id' => $userId]);
            }

            // Списываем бронзу
            $this->db->update('user_currency', [
                'bronze' => $data['bronze'] - $cost,
            ], 'user_id = :id', ['id' => $userId]);

            // Логирование
            $this->db->insert('currency_logs', [
                'user_id' => $userId,
                'currency_type' => 'bronze',
                'amount' => -$cost,
                'balance_after' => $data['bronze'] - $cost,
                'source' => 'training',
                'details' => json_encode(['stat' => $statType, 'amount' => $amount]),
            ]);

            $this->db->commit();

            $this->json([
                'success' => true,
                'message' => 'Характеристика улучшена!',
                'cost' => $cost,
            ]);

        } catch (\Exception $e) {
            $this->db->rollback();
            $this->json(['error' => 'Ошибка при прокачке: ' . $e->getMessage()], 500);
        }
    }
}
