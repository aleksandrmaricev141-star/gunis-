<?php
/**
 * СКИФЫ - Контроллер инвентаря
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;

class InventoryController extends BaseController
{
    public function __construct(Auth $auth, Database $db)
    {
        parent::__construct($auth, $db);
    }

    /**
     * Страница инвентаря
     */
    public function indexAction(): void
    {
        $userId = $this->getUserId();

        // Получаем экипировку
        $equipment = $this->db->fetchAll(
            'SELECT i.*, it.name, it.type, it.rarity, it.icon,
                    it.bonus_fury, it.bonus_blood, it.bonus_copper
             FROM inventory i
             JOIN items it ON i.item_id = it.id
             WHERE i.user_id = :id AND i.is_equipped = 1
             ORDER BY i.slot ASC',
            ['id' => $userId]
        );

        // Получаем предметы в рюкзаке
        $items = $this->db->fetchAll(
            'SELECT i.*, it.name, it.type, it.rarity, it.icon, it.base_price
             FROM inventory i
             JOIN items it ON i.item_id = it.id
             WHERE i.user_id = :id AND i.is_equipped = 0
             LIMIT 20',
            ['id' => $userId]
        );

        $this->render('inventory/index', [
            'title' => 'Инвентарь',
            'equipment' => $equipment,
            'items' => $items,
        ]);
    }
}
