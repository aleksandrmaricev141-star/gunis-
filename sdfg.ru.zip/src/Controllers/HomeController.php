<?php
/**
 * СКИФЫ - Домашний контроллер
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;

use function BASE_URL;
use function redirect;

class HomeController extends BaseController
{
    public function __construct(Auth $auth, Database $db)
    {
        parent::__construct($auth, $db);
    }

    /**
     * Главная страница
     */
    public function indexAction(): void
    {
        // Если авторизован - редирект в профиль
        if ($this->userId) {
            $this->redirect(BASE_URL . '/profile');
            return;
        }

        // Пустые массивы по умолчанию
        $topPlayers = [];
        $topClans = [];
        $activeEvents = [];

        $this->render('home/index', [
            'title' => 'СКИФЫ - Браузерная MMO RPG',
            'topPlayers' => $topPlayers,
            'topClans' => $topClans,
            'activeEvents' => $activeEvents,
        ]);
    }

    /**
     * О игре
     */
    public function aboutAction(): void
    {
        $this->render('home/about', [
            'title' => 'О игре СКИФЫ'
        ]);
    }

    /**
     * Правила
     */
    public function rulesAction(): void
    {
        $this->render('home/rules', [
            'title' => 'Правила игры'
        ]);
    }
}
