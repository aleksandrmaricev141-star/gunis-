<?php
/**
 * СКИФЫ - Базовый контроллер
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;

use function BASE_URL;
use function TEMPLATE_PATH;
use function generate_csrf_token;
use function verify_csrf_token;
use function redirect;
use function json_response;
use function log_message;
use function is_ajax_request;

abstract class BaseController
{
    protected Auth $auth;
    protected Database $db;
    protected ?int $userId = null;
    protected array $user = [];

    public function __construct(Auth $auth, Database $db)
    {
        $this->auth = $auth;
        $this->db = $db;
        $this->userId = $auth->getUserId();
        
        if ($this->userId !== null) {
            $this->loadUserData();
        }
    }

    private function loadUserData(): void
    {
        try {
            $this->user = $this->db->fetchOne(
                'SELECT u.username, uc.bronze, uc.gold, uc.sacred_koumiss
                 FROM users u, user_currency uc
                 WHERE u.id = uc.user_id AND u.id = ?',
                [$this->userId]
            ) ?? ['username' => 'Герой', 'bronze' => 100, 'gold' => 10, 'sacred_koumiss' => 0];
        } catch (\PDOException $e) {
            $this->user = ['username' => 'Герой', 'bronze' => 100, 'gold' => 10, 'sacred_koumiss' => 0];
        }
    }

    protected function render(string $template, array $data = []): void
    {
        $data['controller'] = $this->getControllerName();
        extract($data, EXTR_SKIP);
        
        $templatePath = \TEMPLATE_PATH . '/' . str_replace('.', '/', $template) . '.php';
        
        if (!file_exists($templatePath)) {
            throw new \RuntimeException("Шаблон не найден: $templatePath");
        }
        
        require_once \TEMPLATE_PATH . '/layouts/main.php';
    }

    private function getControllerName(): string
    {
        $class = get_class($this);
        $name = str_replace('App\\Controllers\\', '', $class);
        return strtolower(str_replace('Controller', '', $name));
    }

    protected function redirect(string $url): void
    {
        redirect($url);
    }

    protected function json(array $data, int $status = 200): void
    {
        json_response($data, $status);
    }

    protected function csrfToken(): string
    {
        return generate_csrf_token();
    }

    protected function verifyCsrf(): bool
    {
        return verify_csrf_token($_POST['csrf_token'] ?? '');
    }

    protected function post(string $key, $default = null)
    {
        return $_POST[$key] ?? $default;
    }

    protected function get(string $key, $default = null)
    {
        return $_GET[$key] ?? $default;
    }

    protected function postInt(string $key, int $default = 0): int
    {
        $value = filter_input(INPUT_POST, $key, FILTER_VALIDATE_INT);
        return $value !== false && $value !== null ? $value : $default;
    }

    protected function postString(string $key, string $default = ''): string
    {
        return trim($_POST[$key] ?? $default);
    }

    protected function isAjax(): bool
    {
        return is_ajax_request();
    }

    protected function requireAjax(): void
    {
        if (!$this->isAjax()) {
            $this->json(['error' => 'Invalid request'], 400);
        }
    }

    protected function requirePost(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->json(['error' => 'Method not allowed'], 405);
        }
    }

    protected function getUserId(): ?int
    {
        return $this->userId;
    }

    protected function logAction(string $action, array $details = []): void
    {
        log_message('info', "User {$this->userId}: $action", $details);
    }
}
