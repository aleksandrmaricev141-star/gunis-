<?php
/**
 * СКИФЫ - Контроллер авторизации
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;

use function BASE_URL;
use function redirect;
use function generate_csrf_token;

class AuthController extends BaseController
{
    private Auth $authService;

    public function __construct(Auth $auth, Database $db)
    {
        parent::__construct($auth, $db);
        $this->authService = $auth;
    }

    public function loginAction(): void
    {
        if ($this->authService->isAuthenticated()) {
            $this->redirect(BASE_URL . '/profile');
            return;
        }

        $error = null;
        $csrf_token = generate_csrf_token();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!$this->verifyCsrf()) {
                $error = 'Ошибка CSRF';
            } else {
                $login = $this->postString('login');
                $password = $this->postString('password');

                if (empty($login) || empty($password)) {
                    $error = 'Введите логин и пароль';
                } else {
                    $result = $this->authService->login($login, $password);
                    if ($result['success']) {
                        $this->redirect(BASE_URL . '/profile');
                        return;
                    } else {
                        $error = $result['error'];
                    }
                }
            }
        }

        $this->renderAuth('Вход', BASE_URL . '/auth/login', 'Войти', false, $error, $csrf_token);
    }

    public function registerAction(): void
    {
        if ($this->authService->isAuthenticated()) {
            $this->redirect(BASE_URL . '/profile');
            return;
        }

        $error = null;
        $csrf_token = generate_csrf_token();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!$this->verifyCsrf()) {
                $error = 'Ошибка CSRF';
            } else {
                $username = $this->postString('username');
                $email = $this->postString('email');
                $password = $this->postString('password');
                $passwordConfirm = $this->postString('password_confirm');

                if (empty($username) || empty($email) || empty($password)) {
                    $error = 'Заполните все поля';
                } elseif ($password !== $passwordConfirm) {
                    $error = 'Пароли не совпадают';
                } else {
                    $result = $this->authService->register($username, $email, $password);
                    if ($result['success']) {
                        $this->redirect(BASE_URL . '/profile');
                        return;
                    } else {
                        $error = $result['error'];
                    }
                }
            }
        }

        $this->renderAuth('Регистрация', BASE_URL . '/auth/register', 'Создать героя', true, $error, $csrf_token);
    }

    private function renderAuth(string $title, string $action, string $submitText, bool $isRegister, ?string $error, string $csrf_token): void
    {
        ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#1a1a2e">
    <title><?= e($title) ?> - СКИФЫ</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(180deg, #1a1a2e 0%, #0f0f1a 100%);
            color: #e8e8e8;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .auth-box {
            background: #16213e;
            border: 2px solid #2d2d44;
            border-radius: 12px;
            padding: 30px 20px;
            width: 100%;
            max-width: 400px;
        }
        .auth-header { text-align: center; margin-bottom: 25px; }
        .game-logo { font-size: 4rem; display: block; margin-bottom: 10px; }
        .auth-title { color: #c9a962; font-size: 1.5rem; font-weight: bold; }
        .error-box {
            background: rgba(220, 53, 69, 0.2);
            border: 1px solid #dc3545;
            color: #ff6b6b;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .form-group { margin-bottom: 15px; }
        .form-label { display: block; margin-bottom: 6px; color: #a0a0a0; font-size: 0.85rem; font-weight: bold; }
        .form-input {
            width: 100%;
            padding: 12px;
            background: #1f2940;
            border: 1px solid #2d2d44;
            border-radius: 8px;
            color: #e8e8e8;
            font-size: 1rem;
        }
        .form-input:focus { outline: none; border-color: #c9a962; }
        .btn-submit {
            width: 100%;
            background: linear-gradient(180deg, #c9a962 0%, #a08840 100%);
            color: #0f0f1a;
            border: none;
            border-radius: 8px;
            padding: 14px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
        }
        .auth-footer {
            text-align: center;
            color: #a0a0a0;
            font-size: 0.85rem;
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px solid #2d2d44;
        }
        .features {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 25px;
            flex-wrap: wrap;
        }
        .feature-item {
            text-align: center;
            padding: 10px 15px;
            background: #16213e;
            border: 1px solid #2d2d44;
            border-radius: 8px;
            min-width: 80px;
        }
        .feature-icon { font-size: 1.5rem; display: block; margin-bottom: 5px; }
        .feature-item { color: #a0a0a0; font-size: 0.8rem; }
    </style>
</head>
<body>
    <div class="auth-box">
        <div class="auth-header">
            <span class="game-logo">⚔️</span>
            <h1 class="auth-title"><?= e($title) ?></h1>
        </div>

        <?php if ($error): ?>
        <div class="error-box">⚠️ <?= e($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="<?= e($action) ?>">
            <input type="hidden" name="csrf_token" value="<?= e($csrf_token) ?>">

            <?php if ($isRegister): ?>
            <div class="form-group">
                <label class="form-label">Имя героя</label>
                <input type="text" name="username" class="form-input" placeholder="Введите имя" required minlength="3" autofocus>
            </div>
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-input" placeholder="Email" required>
            </div>
            <div class="form-group">
                <label class="form-label">Пароль</label>
                <input type="password" name="password" class="form-input" placeholder="Пароль" required minlength="6">
            </div>
            <div class="form-group">
                <label class="form-label">Повторите пароль</label>
                <input type="password" name="password_confirm" class="form-input" placeholder="Повторите" required minlength="6">
            </div>
            <button type="submit" class="btn-submit">🏹 Создать героя</button>
            <div class="auth-footer">
                Уже есть аккаунт? <a href="<?= BASE_URL ?>/auth/login">Войти</a>
            </div>
            <?php else: ?>
            <div class="form-group">
                <label class="form-label">Логин или Email</label>
                <input type="text" name="login" class="form-input" placeholder="Введите логин" required autofocus>
            </div>
            <div class="form-group">
                <label class="form-label">Пароль</label>
                <input type="password" name="password" class="form-input" placeholder="Пароль" required>
            </div>
            <button type="submit" class="btn-submit">⚔️ Войти</button>
            <div class="auth-footer">
                Нет аккаунта? <a href="<?= BASE_URL ?>/auth/register">Создать</a>
            </div>
            <?php endif; ?>
        </form>
    </div>

    <div class="features">
        <div class="feature-item"><span class="feature-icon">⚔️</span><span>Битвы</span></div>
        <div class="feature-item"><span class="feature-icon">🏕️</span><span>Племя</span></div>
        <div class="feature-item"><span class="feature-icon">📈</span><span>Прокачка</span></div>
    </div>
</body>
</html>
<?php
        exit;
    }

    public function logoutAction(): void
    {
        $this->authService->logout();
        $this->redirect(BASE_URL . '/');
    }
}
