<?php
/**
 * СКИФЫ - Контроллер профиля
 * Упрощённая версия
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;

use function BASE_URL;
use function redirect;

class ProfileController extends BaseController
{
    public function __construct(Auth $auth, Database $db)
    {
        parent::__construct($auth, $db);
    }

    public function indexAction(): void
    {
        $userId = $this->getUserId();

        // Данные по умолчанию
        $profile = ['username' => 'Герой', 'bronze' => 100, 'gold' => 10];
        $stats = [
            'level' => 1, 'experience' => 0, 'experience_to_next' => 100,
            'fury_steppe' => 10, 'blood_nomad' => 100, 'copper_scale' => 5,
            'energy' => 10, 'max_energy' => 10, 'stat_points' => 0,
            'iron_scrap' => 0, 'spirit_tears' => 0, 'shard_skull' => 0
        ];

        // Пытаемся получить из БД
        try {
            // Профиль
            $dbProfile = $this->db->fetchOne(
                'SELECT u.username, uc.bronze, uc.gold 
                 FROM users u, user_currency uc 
                 WHERE u.id = uc.user_id AND u.id = ?',
                [$userId]
            );
            
            if ($dbProfile) {
                $profile = [...$profile, ...$dbProfile];
            }
            
            // Статы
            $dbStats = $this->db->fetchOne(
                'SELECT level, experience, experience_to_next, 
                        fury_steppe, blood_nomad, copper_scale,
                        energy, max_energy, stat_points
                 FROM hero_stats 
                 WHERE user_id = ?',
                [$userId]
            );
            
            if ($dbStats) {
                $stats = [...$stats, ...$dbStats];
            }
        } catch (\PDOException $e) {
            // Игнорируем ошибки
        }

        $expPercent = $stats['experience_to_next'] > 0 
            ? ($stats['experience'] / $stats['experience_to_next']) * 100 
            : 0;

        $this->render('profile/index', [
            'title' => 'Профиль',
            'profile' => $profile,
            'stats' => $stats,
            'expPercent' => $expPercent,
        ]);
    }
}
