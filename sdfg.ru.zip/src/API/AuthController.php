<?php
/**
 * API контроллер аутентификации
 */

require_once __DIR__ . '/../Core/ApiController.php';
require_once __DIR__ . '/../Repositories/PlayerRepository.php';

class AuthController extends ApiController {
    private PlayerRepository $playerRepo;

    public function __construct() {
        parent::__construct();
        $this->playerRepo = new PlayerRepository();
    }

    /**
     * Регистрация
     * POST /api/auth/register.php
     */
    public function register(): void {
        $data = $this->getJsonInput();

        // Валидация
        if (empty($data['username']) || empty($data['email']) || empty($data['password'])) {
            $this->error('Все поля обязательны');
            return;
        }

        if (strlen($data['username']) < 3 || strlen($data['username']) > 20) {
            $this->error('Имя должно быть от 3 до 20 символов');
            return;
        }

        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $this->error('Некорректный email');
            return;
        }

        if (strlen($data['password']) < 6) {
            $this->error('Пароль должен быть не менее 6 символов');
            return;
        }

        // Проверка существования
        if ($this->playerRepo->findByUsername($data['username'])) {
            $this->error('Имя пользователя уже занято');
            return;
        }

        if ($this->playerRepo->findByEmail($data['email'])) {
            $this->error('Email уже зарегистрирован');
            return;
        }

        // Создание игрока
        $passwordHash = $this->playerRepo->hashPassword($data['password']);
        $playerId = $this->playerRepo->createPlayer($data['username'], $data['email'], $passwordHash);

        $player = $this->playerRepo->find($playerId);

        // Авто-вход
        $this->auth->login($playerId);

        $this->success([
            'player' => $this->sanitizePlayer($player),
            'stats' => $this->playerRepo->getStats($playerId),
        ], 'Регистрация успешна');
    }

    /**
     * Вход
     * POST /api/auth/login.php
     */
    public function login(): void {
        $data = $this->getJsonInput();

        if (empty($data['username']) || empty($data['password'])) {
            $this->error('Введите имя и пароль');
            return;
        }

        $player = $this->playerRepo->findByUsername($data['username']);

        if (!$player || !$this->playerRepo->verifyPassword($data['password'], $player['password_hash'])) {
            $this->error('Неверное имя или пароль');
            return;
        }

        // Вход
        $this->auth->login($player['id']);
        $this->playerRepo->updateLastActivity($player['id']);

        $this->success([
            'player' => $this->sanitizePlayer($player),
            'stats' => $this->playerRepo->getStats($player['id']),
        ], 'Вход выполнен');
    }

    /**
     * Выход
     * POST /api/auth/logout.php
     */
    public function logout(): void {
        $this->auth->logout();
        $this->success([], 'Выход выполнен');
    }

    /**
     * Получить текущего игрока
     * GET /api/auth/me.php
     */
    public function me(): void {
        try {
            $playerId = $this->requireAuth();
            $player = $this->playerRepo->find($playerId);

            if (!$player) {
                $this->error('Игрок не найден', 404);
                return;
            }

            $this->success([
                'player' => $this->sanitizePlayer($player),
                'stats' => $this->playerRepo->getStats($playerId),
            ]);
        } catch (Exception $e) {
            $this->error($e->getMessage());
        }
    }

    /**
     * Очистка данных игрока перед отправкой
     */
    private function sanitizePlayer(array $player): array {
        unset($player['password_hash']);
        unset($player['email']);
        return $player;
    }
}
