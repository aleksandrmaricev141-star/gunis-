<?php
/**
 * API контроллер игрока
 */

require_once __DIR__ . '/../Core/ApiController.php';
require_once __DIR__ . '/../Repositories/PlayerRepository.php';
require_once __DIR__ . '/../Models/Item.php';

class PlayerController extends ApiController {
    private PlayerRepository $playerRepo;
    private Item $itemModel;

    public function __construct() {
        parent::__construct();
        $this->playerRepo = new PlayerRepository();
        $this->itemModel = new Item();
    }

    /**
     * Получить профиль
     * GET /api/player/profile.php
     */
    public function profile(): void {
        try {
            $playerId = $this->requireAuth();
            $player = $this->playerRepo->find($playerId);

            if (!$player) {
                $this->error('Игрок не найден', 404);
                return;
            }

            $this->success([
                'player' => $this->sanitizePlayer($player),
                'stats' => $this->playerRepo->getStats($playerId),
            ]);
        } catch (Exception $e) {
            $this->error($e->getMessage());
        }
    }

    /**
     * Тренировать параметр
     * POST /api/player/train.php
     */
    public function train(): void {
        try {
            $playerId = $this->requireAuth();
            $data = $this->getJsonInput();

            $stat = $data['stat_type'] ?? '';
            if (!in_array($stat, ['rage_steppe', 'blood_nomad', 'copper_scale'])) {
                $this->error('Неверный параметр');
                return;
            }

            $result = $this->playerRepo->trainStat($playerId, $stat);

            if (!$result['success']) {
                $this->error($result['error']);
                return;
            }

            $player = $this->playerRepo->find($playerId);
            $this->success([
                'player' => $this->sanitizePlayer($player),
                'stats' => $this->playerRepo->getStats($playerId),
                'trained_stat' => $stat,
                'new_level' => $result['new_level'],
                'cost' => $result['cost'],
            ], 'Параметр улучшен');
        } catch (Exception $e) {
            $this->error($e->getMessage());
        }
    }

    /**
     * Получить инвентарь
     * GET /api/player/inventory.php
     */
    public function inventory(): void {
        try {
            $playerId = $this->requireAuth();
            $items = $this->itemModel->getByPlayer($playerId);
            $equipped = $this->itemModel->getEquipped($playerId);

            $this->success([
                'items' => $items,
                'equipped' => $equipped,
            ]);
        } catch (Exception $e) {
            $this->error($e->getMessage());
        }
    }

    /**
     * Надеть предмет
     * POST /api/player/equip.php
     */
    public function equip(): void {
        try {
            $playerId = $this->requireAuth();
            $data = $this->getJsonInput();

            $itemId = (int) ($data['item_id'] ?? 0);
            $type = $data['type'] ?? '';

            if (!$itemId || !$type) {
                $this->error('Неверные данные');
                return;
            }

            // Проверка что предмет принадлежит игроку
            $item = $this->itemModel->getByPlayerAndId($playerId, $itemId);
            if (!$item) {
                $this->error('Предмет не найден');
                return;
            }

            if ($this->itemModel->equip($playerId, $itemId, $type)) {
                $this->success([], 'Предмет надет');
            } else {
                $this->error('Ошибка при экипировке');
            }
        } catch (Exception $e) {
            $this->error($e->getMessage());
        }
    }

    /**
     * Использовать предмет
     * POST /api/player/use_item.php
     */
    public function useItem(): void {
        try {
            $playerId = $this->requireAuth();
            $data = $this->getJsonInput();
            $itemId = (int) ($data['item_id'] ?? 0);

            $item = $this->itemModel->getByPlayerAndId($playerId, $itemId);
            if (!$item) {
                $this->error('Предмет не найден');
                return;
            }

            // Логика использования предметов
            if ($item['type'] === 'potion') {
                $player = $this->playerRepo->find($playerId);
                $healAmount = 50; // Базовое лечение
                $newHp = min($player['current_hp'] + $healAmount, $player['max_hp']);

                $this->playerRepo->update($playerId, ['current_hp' => $newHp]);
                $this->itemModel->remove($itemId);

                $this->success([
                    'player' => $this->sanitizePlayer($this->playerRepo->find($playerId)),
                ], "Предмет использован. Восстановлено {$healAmount} HP");
            } else {
                $this->error('Этот предмет нельзя использовать');
            }
        } catch (Exception $e) {
            $this->error($e->getMessage());
        }
    }

    private function sanitizePlayer(array $player): array {
        unset($player['password_hash']);
        unset($player['email']);
        return $player;
    }
}
