<?php
/**
 * СКИФЫ - Класс работы с БД
 * МАКСИМАЛЬНО ПРОСТОЙ ВАРИАНТ
 */

declare(strict_types=1);

namespace App\Core;

use PDO;
use PDOException;
use PDOStatement;

class Database
{
    private static ?Database $instance = null;
    private PDO $pdo;
    
    private function __construct()
    {
        try {
            $this->pdo = new PDO(
                DB_DSN,
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            log_message('fatal', 'DB connection failed: ' . $e->getMessage());
            die('Ошибка БД');
        }
    }
    
    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getPdo(): PDO
    {
        return $this->pdo;
    }
    
    /**
     * Простой SELECT с позиционными параметрами
     */
    public function fetchOne(string $sql, array $params = []): array|false
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch();
    }
    
    /**
     * SELECT все строки
     */
    public function fetchAll(string $sql, array $params = []): array
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    /**
     * SELECT одно значение
     */
    public function fetchValue(string $sql, array $params = []): mixed
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        return $row[0] ?? null;
    }
    
    /**
     * INSERT с именованными параметрами
     */
    public function insert(string $table, array $data): int
    {
        $columns = implode(', ', array_keys($data));
        $placeholders = ':' . implode(', :', array_keys($data));
        
        $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";
        $stmt = $this->pdo->prepare($sql);
        
        foreach ($data as $key => $value) {
            $stmt->bindValue(":$key", $value, $this->getType($value));
        }
        
        $stmt->execute();
        return (int)$this->pdo->lastInsertId();
    }
    
    /**
     * UPDATE
     */
    public function update(string $table, array $data, string $where, array $whereParams = []): int
    {
        $setParts = [];
        $allParams = [];
        $i = 1;
        
        // SET часть с именованными параметрами
        foreach ($data as $column => $value) {
            $paramName = "set_$column";
            $setParts[] = "$column = :$paramName";
            $allParams[$paramName] = $value;
        }
        
        // WHERE часть - заменяем ? на именованные
        $whereWithParams = $where;
        foreach ($whereParams as $key => $value) {
            $paramName = "where_$i";
            $whereWithParams = str_replace('?', ":$paramName", $whereWithParams, 1);
            $allParams[$paramName] = $value;
            $i++;
        }
        
        $sql = "UPDATE $table SET " . implode(', ', $setParts) . " WHERE $whereWithParams";
        $stmt = $this->pdo->prepare($sql);
        
        foreach ($allParams as $key => $value) {
            $stmt->bindValue(":$key", $value, $this->getType($value));
        }
        
        $stmt->execute();
        return $stmt->rowCount();
    }
    
    /**
     * DELETE
     */
    public function delete(string $table, string $where, array $params = []): int
    {
        $sql = "DELETE FROM $table WHERE $where";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->rowCount();
    }
    
    /**
     * COUNT
     */
    public function count(string $table, string $where = '', array $params = []): int
    {
        $sql = 'SELECT COUNT(*) FROM ' . $table;
        if ($where) {
            $sql .= ' WHERE ' . $where;
        }
        return (int)$this->fetchValue($sql, $params);
    }
    
    /**
     * Транзакции
     */
    public function beginTransaction(): bool
    {
        return $this->pdo->beginTransaction();
    }
    
    public function commit(): bool
    {
        return $this->pdo->commit();
    }
    
    public function rollback(): bool
    {
        return $this->pdo->rollBack();
    }
    
    public function lastInsertId(): int
    {
        return (int)$this->pdo->lastInsertId();
    }
    
    private function getType($value): int
    {
        if (is_int($value)) return PDO::PARAM_INT;
        if (is_bool($value)) return PDO::PARAM_BOOL;
        if (is_null($value)) return PDO::PARAM_NULL;
        return PDO::PARAM_STR;
    }
    
    private function __clone() {}
    
    public function __wakeup()
    {
        throw new \Exception('Cannot unserialize');
    }
}
