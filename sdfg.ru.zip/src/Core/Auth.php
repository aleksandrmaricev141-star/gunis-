<?php
/**
 * СКИФЫ - Класс авторизации и аутентификации
 */

declare(strict_types=1);

namespace App\Core;

use App\Core\Database;
use InvalidArgumentException;

use function BASE_URL;
use function redirect;
use function json_response;
use function is_ajax_request;
use function log_message;
use function get_client_ip;
use function password_hash;
use function password_verify;

class Auth
{
    private Database $db;
    
    public function __construct()
    {
        $this->db = Database::getInstance();
    }
    
    /**
     * Регистрация нового пользователя
     *
     * @param string $username Имя пользователя
     * @param string $email Email
     * @param string $password Пароль
     * @return array ['success' => bool, 'user_id' => int|null, 'error' => string|null]
     */
    public function register(string $username, string $email, string $password): array
    {
        // Валидация
        if (strlen($username) < 3 || strlen($username) > 50) {
            return ['success' => false, 'user_id' => null, 'error' => 'Имя должно быть от 3 до 50 символов'];
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'user_id' => null, 'error' => 'Некорректный email'];
        }
        
        if (strlen($password) < 6) {
            return ['success' => false, 'user_id' => null, 'error' => 'Пароль должен быть не менее 6 символов'];
        }
        
        // Проверка на существование
        $existing = $this->db->fetchOne(
            'SELECT id FROM users WHERE username = ? OR email = ?',
            [$username, $email]
        );
        
        if ($existing) {
            return ['success' => false, 'user_id' => null, 'error' => 'Пользователь с таким именем или email уже существует'];
        }
        
        // Хэширование пароля
        $passwordHash = password_hash($password, PASSWORD_ALGO, PASSWORD_OPTIONS);
        
        // Создание пользователя и начальных данных в транзакции
        try {
            return $this->db->transactional(function () use ($username, $email, $passwordHash) {
                // Создаём пользователя
                $userId = $this->db->insert('users', [
                    'username' => $username,
                    'email' => $email,
                    'password_hash' => $passwordHash,
                    'is_active' => 1,
                    'is_banned' => 0,
                    'is_admin' => 0,
                ]);
                
                // Создаём статистику героя
                $this->db->insert('hero_stats', [
                    'user_id' => $userId,
                    'level' => STARTING_LEVEL,
                    'experience' => STARTING_EXP,
                    'experience_to_next' => EXP_TO_LEVEL_BASE,
                    'fury_steppe' => STARTING_FURY,
                    'blood_nomad' => STARTING_BLOOD,
                    'copper_scale' => STARTING_COPPER,
                    'current_hp' => STARTING_BLOOD,
                    'energy' => MAX_ENERGY,
                    'max_energy' => MAX_ENERGY,
                    'stat_points' => 0,
                    'battle_count_today' => 0,
                    'last_daily_reset' => date('Y-m-d'),
                ]);
                
                // Создаём валюту
                $this->db->insert('user_currency', [
                    'user_id' => $userId,
                    'bronze' => STARTING_BRONZE,
                    'gold' => STARTING_GOLD,
                    'sacred_koumiss' => 0,
                    'koumiss_personal' => 0,
                ]);
                
                // Создаём материалы
                $this->db->insert('user_materials', [
                    'user_id' => $userId,
                    'iron_scrap' => 0,
                    'spirit_tears' => 0,
                    'shard_skull' => 0,
                    'honor_points' => 0,
                ]);
                
                // Создаём таймеры
                $this->db->insert('user_timers', [
                    'user_id' => $userId,
                    'wild_field_until' => null,
                    'pvp_until' => null,
                    'caravan_until' => null,
                    'daily_reward_at' => date('Y-m-d H:i:s'),
                    'quest_claimable_at' => null,
                    'energy_full_at' => date('Y-m-d H:i:s', time() + ENERGY_REGEN_TIME),
                ]);
                
                // Создаём оберег
                $this->db->insert('user_amulet', [
                    'user_id' => $userId,
                    'level' => 1,
                    'experience' => 0,
                    'experience_to_next' => 1000,
                    'bonus_exp_percent' => 0,
                    'bonus_bronze_percent' => 0,
                    'bonus_drop_percent' => 0,
                    'fed_spirit_tears' => 0,
                ]);
                
                // Создаём PvP рейтинг
                $this->db->insert('pvp_rating', [
                    'user_id' => $userId,
                    'rating' => PVP_STARTING_RATING,
                    'league' => 'bronze',
                    'wins' => 0,
                    'losses' => 0,
                    'draws' => 0,
                    'current_season_wins' => 0,
                    'current_season_losses' => 0,
                    'highest_rating' => PVP_STARTING_RATING,
                    'season_id' => 1,
                ]);
                
                // Логирование
                log_message('info', 'User registered', ['user_id' => $userId, 'username' => $username]);
                
                // Автоматический вход
                $this->loginById($userId);
                
                return ['success' => true, 'user_id' => $userId, 'error' => null];
            });
        } catch (\Exception $e) {
            log_message('error', 'Registration failed: ' . $e->getMessage());
            return ['success' => false, 'user_id' => null, 'error' => 'Ошибка при регистрации'];
        }
    }
    
    /**
     * Вход по логину и паролю
     *
     * @param string $login Email или username
     * @param string $password Пароль
     * @return array ['success' => bool, 'error' => string|null]
     */
    public function login(string $login, string $password): array
    {
        $user = $this->db->fetchOne(
            'SELECT id, password_hash, is_active, is_banned, ban_until 
             FROM users 
             WHERE username = ? OR email = ? 
             LIMIT 1',
            [$login, $login]
        );
        
        if (!$user) {
            log_message('warning', 'Login failed - user not found', ['login' => $login]);
            return ['success' => false, 'error' => 'Неверный логин или пароль'];
        }
        
        // Проверка бана
        if ($user['is_banned']) {
            if ($user['ban_until'] && strtotime($user['ban_until']) > time()) {
                return ['success' => false, 'error' => 'Аккаунт заблокирован до ' . $user['ban_until']];
            }
            return ['success' => false, 'error' => 'Аккаунт заблокирован'];
        }
        
        // Проверка пароля
        if (!password_verify($password, $user['password_hash'])) {
            log_message('warning', 'Login failed - wrong password', ['user_id' => $user['id']]);
            return ['success' => false, 'error' => 'Неверный логин или пароль'];
        }
        
        // Проверка активности
        if (!$user['is_active']) {
            return ['success' => false, 'error' => 'Аккаунт не активирован'];
        }
        
        // Обновление последнего входа
        $this->db->update('users', [
            'last_login' => date('Y-m-d H:i:s'),
            'last_ip' => get_client_ip(),
        ], 'id = ?', [$user['id']]);
        
        // Вход
        $this->loginById($user['id']);
        
        log_message('info', 'User logged in', ['user_id' => $user['id']]);
        
        return ['success' => true, 'error' => null];
    }
    
    /**
     * Вход по ID (после регистрации)
     */
    private function loginById(int $userId): void
    {
        $_SESSION['user_id'] = $userId;
        $_SESSION['login_time'] = time();
        
        // Регенерация ID сессии для безопасности
        session_regenerate_id(true);
    }
    
    /**
     * Выход
     */
    public function logout(): void
    {
        $userId = $this->getUserId();
        if ($userId) {
            log_message('info', 'User logged out', ['user_id' => $userId]);
        }
        
        $_SESSION = [];
        
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }
        
        session_destroy();
    }
    
    /**
     * Получить ID текущего пользователя
     */
    public function getUserId(): ?int
    {
        return $_SESSION['user_id'] ?? null;
    }
    
    /**
     * Проверка авторизации
     */
    public function isAuthenticated(): bool
    {
        return $this->getUserId() !== null;
    }
    
    /**
     * Требовать авторизацию (редирект или JSON ошибка)
     */
    public function requireAuth(): int
    {
        $userId = $this->getUserId();
        if ($userId === null) {
            if (\is_ajax_request()) {
                \json_response(['error' => 'Требуется авторизация', 'code' => 'AUTH_REQUIRED'], 401);
            }
            \redirect(BASE_URL . '/login');
        }
        return $userId;
    }
    
    /**
     * Получить данные пользователя
     *
     * @param int|null $userId ID пользователя (null = текущий)
     * @return array|null
     */
    public function getUser(?int $userId = null): ?array
    {
        $userId = $userId ?? $this->getUserId();
        if ($userId === null) {
            return null;
        }
        
        return $this->db->fetchOne(
            'SELECT u.id, u.username, u.email, u.created_at, u.last_login,
                    u.is_premium, u.premium_until, u.is_admin,
                    hs.level, hs.experience, hs.fury_steppe, hs.blood_nomad, hs.copper_scale,
                    uc.bronze, uc.gold
             FROM users u, hero_stats hs, user_currency uc
             WHERE u.id = hs.user_id AND u.id = uc.user_id AND u.id = ? 
               AND u.is_active = 1 AND u.is_banned = 0',
            [$userId]
        );
    }
    
    /**
     * Проверка на администратора
     */
    public function isAdmin(): bool
    {
        $userId = $this->getUserId();
        if ($userId === null) {
            return false;
        }
        
        $isAdmin = $this->db->fetchValue(
            'SELECT is_admin FROM users WHERE id = ?',
            [$userId]
        );
        
        return (bool)$isAdmin;
    }
    
    /**
     * Требовать права администратора
     */
    public function requireAdmin(): int
    {
        $userId = $this->requireAuth();

        if (!$this->isAdmin()) {
            if (\is_ajax_request()) {
                \json_response(['error' => 'Недостаточно прав', 'code' => 'ADMIN_REQUIRED'], 403);
            }
            \redirect(BASE_URL . '/');
        }

        return $userId;
    }
    
    /**
     * Сменить пароль
     */
    public function changePassword(int $userId, string $oldPassword, string $newPassword): array
    {
        $user = $this->db->fetchOne(
            'SELECT password_hash FROM users WHERE id = ?',
            [$userId]
        );
        
        if (!$user) {
            return ['success' => false, 'error' => 'Пользователь не найден'];
        }
        
        if (!password_verify($oldPassword, $user['password_hash'])) {
            return ['success' => false, 'error' => 'Неверный текущий пароль'];
        }
        
        if (strlen($newPassword) < 6) {
            return ['success' => false, 'error' => 'Новый пароль должен быть не менее 6 символов'];
        }
        
        $newHash = password_hash($newPassword, PASSWORD_ALGO, PASSWORD_OPTIONS);
        
        $this->db->update('users', [
            'password_hash' => $newHash,
        ], 'id = ?', [$userId]);
        
        log_message('info', 'Password changed', ['user_id' => $userId]);
        
        return ['success' => true, 'error' => null];
    }
    
    /**
     * Восстановление пароля (отправка токена)
     */
    public function requestPasswordReset(string $email): array
    {
        $user = $this->db->fetchOne(
            'SELECT id, username FROM users WHERE email = ? AND is_active = 1',
            [$email]
        );
        
        if (!$user) {
            // Не показываем, существует ли email (безопасность)
            return ['success' => true, 'error' => null];
        }
        
        // Генерация токена
        $token = bin2hex(random_bytes(32));
        $expiresAt = date('Y-m-d H:i:s', time() + 3600); // 1 час
        
        // Сохранение токена (можно в отдельную таблицу или в сессию)
        $_SESSION['password_reset'] = [
            'user_id' => $user['id'],
            'token' => $token,
            'expires_at' => $expiresAt,
        ];
        
        // Здесь должна быть отправка email
        // Для разработки просто возвращаем токен
        if (DEBUG) {
            return [
                'success' => true, 
                'error' => null, 
                'debug_token' => $token,
                'reset_url' => BASE_URL . '/reset-password?token=' . $token
            ];
        }
        
        // TODO: Отправка email
        // sendEmail($email, 'Восстановление пароля', "Ссылка: $resetUrl");
        
        return ['success' => true, 'error' => null];
    }
    
    /**
     * Сброс пароля по токену
     */
    public function resetPassword(string $token, string $newPassword): array
    {
        if (!isset($_SESSION['password_reset']) 
            || $_SESSION['password_reset']['token'] !== $token) {
            return ['success' => false, 'error' => 'Неверный токен'];
        }
        
        if (strtotime($_SESSION['password_reset']['expires_at']) < time()) {
            unset($_SESSION['password_reset']);
            return ['success' => false, 'error' => 'Токен истёк'];
        }
        
        $userId = $_SESSION['password_reset']['user_id'];
        
        $result = $this->changePassword($userId, '', $newPassword);
        
        if ($result['success']) {
            unset($_SESSION['password_reset']);
        }
        
        return $result;
    }
}
