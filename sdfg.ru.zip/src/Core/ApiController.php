<?php
/**
 * Базовый класс для API контроллеров
 */

abstract class ApiController {
    protected Auth $auth;
    protected ?int $playerId = null;

    public function __construct() {
        $this->auth = Auth::getInstance();
    }

    /**
     * Требовать авторизацию
     */
    protected function requireAuth(): int {
        return $this->auth->requireAuth();
    }

    /**
     * Получить JSON из тела запроса
     */
    protected function getJsonInput(): array {
        $input = file_get_contents('php://input');
        return json_decode($input, true) ?? [];
    }

    /**
     * Отправить JSON ответ
     */
    protected function json(array $data, int $statusCode = 200): void {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
    }

    /**
     * Отправить ошибку
     */
    protected function error(string $message, int $statusCode = 400): void {
        $this->json(['error' => $message], $statusCode);
    }

    /**
     * Отправить успех
     */
    protected function success(array $data = [], string $message = ''): void {
        $response = [];
        if ($message) {
            $response['message'] = $message;
        }
        $response['data'] = $data;
        $this->json($response);
    }

    /**
     * Получить параметр из GET
     */
    protected function get(string $key, $default = null) {
        return $_GET[$key] ?? $default;
    }

    /**
     * Получить параметр из POST
     */
    protected function post(string $key, $default = null) {
        $input = $this->getJsonInput();
        return $input[$key] ?? $_POST[$key] ?? $default;
    }
}
