<?php
/**
 * СКИФЫ - Проверка системы
 */

echo "<!DOCTYPE html><html><head><meta charset='utf-8'><title>Тест</title>";
echo "<style>body{font-family:monospace;background:#0f0f1a;color:#e8e8e8;padding:20px;}";
echo ".ok{color:#28a745;}.error{color:#dc3545;}.card{background:#16213e;border:1px solid #2d2d44;border-radius:8px;padding:15px;margin:10px 0;}</style>";
echo "</head><body>";

echo "<h1>🏹 СКИФЫ - Тест системы</h1>";

// Проверка конфига
echo "<div class='card'>";
echo "<h2>📋 Конфигурация</h2>";
if (file_exists(__DIR__ . '/config/config.php')) {
    echo "<div class='ok'>✓ config/config.php существует</div>";
    require_once __DIR__ . '/config/config.php';
    echo "<div class='ok'>✓ config.php загружен</div>";
    echo "<div>DB_HOST: " . DB_HOST . "</div>";
    echo "<div>DB_NAME: " . DB_NAME . "</div>";
    echo "<div>DB_USER: " . DB_USER . "</div>";
    echo "<div>BASE_URL: " . BASE_URL . "</div>";
} else {
    echo "<div class='error'>✗ config/config.php не найден</div>";
}
echo "</div>";

// Проверка БД
echo "<div class='card'>";
echo "<h2>🗄️ База данных</h2>";
try {
    $pdo = new PDO(DB_DSN, DB_USER, DB_PASS);
    echo "<div class='ok'>✓ Подключение к БД: OK</div>";
    
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo "<div>Таблиц: " . count($tables) . "</div>";
    
    if (count($tables) > 0) {
        echo "<div style='font-size:0.8rem;color:#a0a0a0;margin-top:5px;'>";
        echo implode(', ', array_slice($tables, 0, 10));
        if (count($tables) > 10) echo '...';
        echo "</div>";
    }
} catch (PDOException $e) {
    echo "<div class='error'>✗ Ошибка БД: " . htmlspecialchars($e->getMessage()) . "</div>";
}
echo "</div>";

// Проверка файлов
echo "<div class='card'>";
echo "<h2>📁 Файлы</h2>";
$files = [
    'public/index.php',
    'config/config.php',
    'src/Controllers/AuthController.php',
    'src/Controllers/ProfileController.php',
    'public/templates/layouts/main.php',
    'public/templates/profile/index.php',
];
foreach ($files as $file) {
    $path = __DIR__ . '/' . $file;
    if (file_exists($path)) {
        echo "<div class='ok'>✓ $file</div>";
    } else {
        echo "<div class='error'>✗ $file</div>";
    }
}
echo "</div>";

// Ссылки
echo "<div class='card'>";
echo "<h2>🔗 Быстрый доступ</h2>";
$baseUrl = '';
if (isset($_SERVER['HTTP_HOST'])) {
    $baseUrl = 'http://' . $_SERVER['HTTP_HOST'] . BASE_URL;
}
echo "<div><a href='$baseUrl/'>🏠 Главная</a></div>";
echo "<div><a href='$baseUrl/auth/login'>🔐 Вход</a></div>";
echo "<div><a href='$baseUrl/auth/register'>📝 Регистрация</a></div>";
echo "</div>";

echo "</body></html>";
