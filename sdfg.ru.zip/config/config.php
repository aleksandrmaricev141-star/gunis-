<?php
/**
 * СКИФЫ - Конфигурация
 * Версия 1.0 - Исправленная
 */

declare(strict_types=1);

// Режим отладки
define('DEBUG', true);

// Часовой пояс
date_default_timezone_set('Europe/Moscow');

// ============================================================
// БАЗА ДАННЫХ - ИЗМЕНИТЕ ПОД СЕБЯ!
// ============================================================
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'skifs');
define('DB_USER', 'skifs');
define('DB_PASS', 'skifs123');
define('DB_CHARSET', 'utf8mb4');

// DSN
define('DB_DSN', "mysql:host=".DB_HOST.";port=".DB_PORT.";dbname=".DB_NAME.";charset=".DB_CHARSET);

// ============================================================
// СЕССИИ
// ============================================================
define('SESSION_LIFETIME', 86400);
define('SESSION_NAME', 'SKIFS_SESSION');

// ============================================================
// БЕЗОПАСНОСТЬ
// ============================================================
define('CSRF_TOKEN_NAME', 'csrf_token');
define('PASSWORD_ALGO', PASSWORD_DEFAULT);
define('PASSWORD_OPTIONS', ['cost' => 12]);

// ============================================================
// ПУТИ
// ============================================================
define('ROOT_PATH', dirname(__DIR__));
define('PUBLIC_PATH', ROOT_PATH . '/public');
define('SRC_PATH', ROOT_PATH . '/src');
define('CONFIG_PATH', ROOT_PATH . '/config');
define('LOG_PATH', ROOT_PATH . '/logs');
define('CACHE_PATH', ROOT_PATH . '/cache');
define('TEMPLATE_PATH', PUBLIC_PATH . '/templates');

// URL - АВТОМАТИЧЕСКОЕ ОПРЕДЕЛЕНИЕ
$scriptDir = dirname($_SERVER['SCRIPT_NAME']);
if (strpos($scriptDir, '/public') !== false) {
    $scriptDir = str_replace('/public', '', $scriptDir);
}
define('BASE_URL', rtrim($scriptDir, '/') ?: '');
define('ASSETS_URL', BASE_URL . '/public/assets');

// ============================================================
// ИГРОВЫЕ КОНСТАНТЫ
// ============================================================
define('MAX_BATTLES_PER_DAY', 15);
define('BATTLE_COOLDOWN', 1800);
define('MAX_ENERGY', 10);
define('ENERGY_REGEN_TIME', 300);

define('STARTING_LEVEL', 1);
define('STARTING_EXP', 0);
define('STARTING_FURY', 10);
define('STARTING_BLOOD', 100);
define('STARTING_COPPER', 5);
define('STARTING_BRONZE', 100);
define('STARTING_GOLD', 10);

define('EXP_TO_LEVEL_BASE', 100);
define('STAT_COST_BASE', 50);
define('STAT_COST_MULTIPLIER', 1.3);

// ============================================================
// АВТОЗАГРУЗЧИК
// ============================================================
spl_autoload_register(function (string $class): void {
    $prefix = 'App\\';
    $baseDir = SRC_PATH . '/';
    $len = strlen($prefix);
    
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    $relativeClass = substr($class, $len);
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';
    
    if (file_exists($file)) {
        require $file;
    }
});

// ============================================================
// ФУНКЦИИ
// ============================================================
function e(string $data): string {
    return htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

function redirect(string $url): void {
    header('Location: ' . $url);
    exit;
}

function json_response(array $data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function log_message(string $level, string $message, array $context = []): void {
    if (!is_dir(LOG_PATH)) {
        @mkdir(LOG_PATH, 0755, true);
    }
    $logFile = LOG_PATH . '/' . date('Y-m-d') . '.log';
    $timestamp = date('Y-m-d H:i:s');
    $contextStr = !empty($context) ? ' ' . json_encode($context, JSON_UNESCAPED_UNICODE) : '';
    $logEntry = sprintf("[%s] [%s] %s%s\n", $timestamp, strtoupper($level), $message, $contextStr);
    @file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
}

function generate_csrf_token(): string {
    if (empty($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

function verify_csrf_token(string $token): bool {
    return isset($_SESSION[CSRF_TOKEN_NAME]) && hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
}

function get_current_user_id(): ?int {
    return $_SESSION['user_id'] ?? null;
}

function is_ajax_request(): bool {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) 
        && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

function get_client_ip(): string {
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

// ============================================================
// СЕССИЯ
// ============================================================
if (session_status() === PHP_SESSION_NONE) {
    @ini_set('session.cookie_httponly', '1');
    @ini_set('session.use_strict_mode', '1');
    session_name(SESSION_NAME);
    @session_start();
}

// ============================================================
// ОБРАБОТКА ОШИБОК
// ============================================================
if (DEBUG) {
    error_reporting(E_ALL);
    @ini_set('display_errors', '1');
} else {
    error_reporting(0);
    @ini_set('display_errors', '0');
}

set_error_handler(function ($severity, $message, $file, $line) {
    if (error_reporting() & $severity) {
        throw new ErrorException($message, 0, $severity, $file, $line);
    }
    return false;
});

set_exception_handler(function (Throwable $e): void {
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: text/html; charset=utf-8');
    }
    
    log_message('error', $e->getMessage(), [
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);

    if (DEBUG) {
        echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Ошибка</title>';
        echo '<style>body{font-family:monospace;background:#0f0f1a;color:#e8e8e8;padding:20px;}';
        echo '.error{background:#1a1a2e;border:1px solid #dc3545;border-radius:8px;padding:20px;margin:20px 0;}';
        echo '.title{color:#dc3545;font-size:1.5rem;font-weight:bold;margin-bottom:15px;}</style></head><body>';
        echo '<div class="error">';
        echo '<div class="title">❌ Ошибка PHP</div>';
        echo '<strong>' . e($e->getMessage()) . '</strong><br><br>';
        echo '📁 File: ' . e($e->getFile()) . '<br>';
        echo '📋 Line: ' . $e->getLine();
        echo '</div></body></html>';
    }
});

register_shutdown_function(function () {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR])) {
        log_message('fatal', $error['message']);
    }
});
