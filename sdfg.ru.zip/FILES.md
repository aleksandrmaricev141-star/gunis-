# 🏹 СКИФЫ - Список файлов проекта

## 📁 Структура проекта

```
skifs/
│
├── 📄 .gitignore                    # Игнорирование файлов Git
├── 📄 .htaccess                     # Настройки Apache (rewrite, кэш, безопасность)
├── 📄 README.md                     # Основная документация
├── 📄 INSTALL.md                    # Инструкция по быстрой установке
├── 📄 check.php                     # Диагностика системы
├── 📄 install.php                   # Мастер установки
│
├── 📂 config/
│   └── 📄 config.php                # Конфигурация проекта (БД, сессии, константы)
│
├── 📂 src/
│   ├── 📂 Core/
│   │   ├── 📄 Database.php          # PDO wrapper, Singleton
│   │   └── 📄 Auth.php              # Авторизация, регистрация, пароли
│   │
│   ├── 📂 Controllers/
│   │   ├── 📄 BaseController.php    # Базовый контроллер
│   │   ├── 📄 HomeController.php    # Главная страница
│   │   ├── 📄 AuthController.php    # Вход/регистрация
│   │   └── 📄 ProfileController.php # Профиль игрока
│   │
│   ├── 📂 Models/                   # (пусто, для будущих моделей)
│   ├── 📂 Repositories/             # (пусто, для будущих репозиториев)
│   └── 📂 Services/                 # (пусто, для будущих сервисов)
│
├── 📂 public/
│   ├── 📄 index.php                 # Точка входа (Front Controller)
│   │
│   ├── 📂 assets/
│   │   ├── 📂 css/
│   │   │   ├── 📄 reset.css         # Сброс стилей
│   │   │   ├── 📄 main.css          # Основные стили
│   │   │   ├── 📄 components.css    # Компоненты UI
│   │   │   └── 📄 mobile.css        # Мобильная версия
│   │   │
│   │   ├── 📂 js/
│   │   │   ├── 📄 utils.js          # Утилиты
│   │   │   ├── 📄 api.js            # API клиент
│   │   │   ├── 📄 ui.js             # UI компоненты
│   │   │   └── 📄 main.js           # Главный JS, игровой цикл
│   │   │
│   │   ├── 📂 img/                  # (пусто, для изображений)
│   │   └── 📂 fonts/                # (пусто, для шрифтов)
│   │
│   └── 📂 templates/
│       ├── 📂 layouts/
│       │   └── 📄 main.php          # Основной макет
│       │
│       ├── 📂 auth/
│       │   ├── 📄 login.php         # Страница входа
│       │   ├── 📄 register.php      # Страница регистрации
│       │   └── 📄 form.php          # Форма авторизации
│       │
│       ├── 📂 home/
│       │   └── 📄 index.php         # Главная страница
│       │
│       ├── 📂 profile/
│       │   └── 📄 index.php         # Профиль игрока
│       │
│       ├── 📂 errors/
│       │   └── 📄 404.php           # Страница 404
│       │
│       └── 📂 partials/             # (пусто, для частичных шаблонов)
│
├── 📂 sql/
│   ├── 📄 schema.sql                # Схема базы данных (26 таблиц)
│   └── 📄 data.sql                  # Тестовые данные
│
├── 📂 logs/
│   └── 📄 .gitkeep                  # Пустая директория для логов
│
└── 📂 cache/
    └── 📄 .gitkeep                  # Пустая директория для кэша
```

---

## 📊 Статистика проекта

| Категория | Файлов | Строк кода (примерно) |
|-----------|--------|----------------------|
| PHP Backend | 9 | ~2500 |
| JavaScript | 4 | ~1200 |
| CSS | 4 | ~1800 |
| Templates | 7 | ~800 |
| SQL | 2 | ~800 |
| Документация | 4 | ~600 |
| Конфигурация | 3 | ~200 |
| **ВСЕГО** | **33** | **~7900** |

---

## 🗄️ База данных

### Таблицы (26 шт.)

#### Основные
- `users` - пользователи
- `hero_stats` - характеристики героя
- `user_currency` - валюта
- `user_materials` - материалы

#### Предметы
- `items` - справочник предметов
- `inventory` - инвентарь игроков

#### Боевка
- `enemy_types` - типы врагов
- `battles` - история боёв
- `user_timers` - таймеры и кулдауны

#### Кланы
- `clans` - племена
- `clan_members` - участники кланов
- `clan_applications` - заявки в клан
- `clan_buildings` - здания клана
- `clan_logs` - лог клана

#### Прогрессия
- `campaign_chapters` - главы кампании
- `quests` - квесты
- `user_quest_progress` - прогресс квестов
- `user_chapter_progress` - прогресс глав

#### Доп. системы
- `user_amulet` - оберег шамана
- `pvp_rating` - PvP рейтинг
- `pvp_seasons` - сезоны PvP

#### Ивенты
- `daily_tasks` - ежедневные задания
- `user_daily_progress` - прогресс заданий
- `server_events` - серверные ивенты
- `siege_participation` - участие в осаде

#### Админка
- `admins` - администраторы
- `admin_logs` - лог админа
- `currency_logs` - лог валюты

### Представления (Views)
- `v_user_profile` - профиль игрока
- `v_level_leaderboard` - топ по уровню
- `v_pvp_leaderboard` - PvP рейтинг
- `v_clan_leaderboard` - топ кланов

### События (Events)
- `daily_battle_reset` - ежедневный сброс боёв
- `weekly_koumiss_reset` - еженедельное обнуление кумыса
- `pvp_season_check` - проверка сезона PvP

---

## 🎮 Игровые системы

### Реализовано ✅
- [x] Структура проекта
- [x] База данных (схема)
- [x] Авторизация/регистрация
- [x] Сессии
- [x] Роутинг (Front Controller)
- [x] Базовый MVC
- [x] Шаблоны (layouts)
- [x] CSS фреймворк
- [x] JavaScript утилиты
- [x] API клиент
- [x] Профиль игрока
- [x] Главная страница
- [x] Тестовые данные

### В разработке 🚧
- [ ] Контроллер тренировки
- [ ] Боевая система (PvE)
- [ ] PvP система
- [ ] Инвентарь
- [ ] Кузница
- [ ] Кланы
- [ ] Квесты
- [ ] Оберег
- [ ] Магазин
- [ ] Ивенты
- [ ] Админ-панель
- [ ] Чат

---

## 🔧 API Endpoints (запланированные)

### Авторизация
- `POST /api/auth/login` - вход
- `POST /api/auth/register` - регистрация
- `POST /api/auth/logout` - выход
- `POST /api/auth/reset-password` - сброс пароля

### Профиль
- `GET /api/profile` - данные профиля
- `POST /api/profile/train` - тренировка статов
- `GET /api/profile/view/:id` - просмотр игрока

### Боевка
- `POST /api/battle/start` - начать бой
- `POST /api/battle/attack` - атака
- `POST /api/battle/flee` - побег
- `GET /api/battle/log` - лог боя

### PvP
- `GET /api/pvp/leaderboard` - рейтинг
- `POST /api/pvp/find-match` - поиск матча
- `POST /api/pvp/attack` - атака в PvP

### Инвентарь
- `GET /api/inventory` - инвентарь
- `POST /api/inventory/equip` - экипировать
- `POST /api/inventory/unequip` - снять
- `POST /api/inventory/disassemble` - разобрать
- `POST /api/inventory/upgrade` - улучшить

### Кланы
- `GET /api/clan` - данные клана
- `POST /api/clan/create` - создать
- `POST /api/clan/apply` - подать заявку
- `POST /api/clan/leave` - покинуть
- `POST /api/clan/donate` - пожертвовать
- `POST /api/clan/upgrade-building` - улучшить здание

### Квесты
- `GET /api/quest/list` - список квестов
- `POST /api/quest/claim` - получить награду

### Оберег
- `GET /api/amulet` - данные оберега
- `POST /api/amulet/feed` - покормить

---

## 📝 Следующие шаги

1. **Запустить установку** (см. INSTALL.md)
2. **Протестировать авторизацию**
3. **Разработать контроллер тренировки**
4. **Реализовать боевую систему**
5. **Добавить инвентарь**
6. **Создать систему кланов**

---

**Проект готов к разработке! 🚀**
