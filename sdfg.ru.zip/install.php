<?php
/**
 * СКИФЫ - Установщик
 * Проверка требований и установка
 */

// Отключаем вывод ошибок для чистоты установки
error_reporting(E_ALL);
ini_set('display_errors', 1);

$step = $_GET['step'] ?? 'check';
$errors = [];
$warnings = [];
$success = [];

// ============================================================
// ШАГ 1: ПРОВЕРКА ТРЕБОВАНИЙ
// ============================================================

if ($step === 'check') {
    // Проверка версии PHP
    if (version_compare(PHP_VERSION, '8.0.0', '<')) {
        $errors[] = 'Требуется PHP 8.0 или выше (у вас ' . PHP_VERSION . ')';
    } else {
        $success[] = 'Версия PHP: ' . PHP_VERSION;
    }
    
    // Проверка расширений
    $requiredExtensions = ['pdo', 'pdo_mysql', 'json', 'mbstring', 'session'];
    foreach ($requiredExtensions as $ext) {
        if (extension_loaded($ext)) {
            $success[] = "Расширение $ext: ✓";
        } else {
            $errors[] = "Расширение $ext: не найдено";
        }
    }
    
    // Проверка прав на запись
    $writableDirs = [
        __DIR__ . '/logs',
        __DIR__ . '/cache',
        __DIR__ . '/public/assets'
    ];
    
    foreach ($writableDirs as $dir) {
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        
        if (is_writable($dir)) {
            $success[] = "Директория " . basename($dir) . ': доступна для записи';
        } else {
            $warnings[] = "Директория " . basename($dir) . ': нет прав на запись';
        }
    }
    
    // Проверка подключения к БД
    $dbConfig = [
        'host' => 'localhost',
        'port' => '3306',
        'name' => 'skifs',
        'user' => 'root',
        'pass' => ''
    ];
    
    try {
        $dsn = sprintf(
            'mysql:host=%s;port=%s;charset=utf8mb4',
            $dbConfig['host'],
            $dbConfig['port']
        );
        $pdo = new PDO($dsn, $dbConfig['user'], $dbConfig['pass']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Проверка существования БД
        $stmt = $pdo->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '{$dbConfig['name']}'");
        if ($stmt->rowCount() > 0) {
            $success[] = 'База данных "' . $dbConfig['name'] . '": найдена';
        } else {
            $warnings[] = 'База данных "' . $dbConfig['name'] . '": не существует. Создайте её перед установкой.';
        }
        
        $success[] = 'Подключение к MySQL: ✓';
        
    } catch (PDOException $e) {
        $errors[] = 'Подключение к MySQL: ошибка (' . $e->getMessage() . ')';
    }
}

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>СКИФЫ - Установка</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #0f0f1a 100%);
            color: #e8e8e8;
            min-height: 100vh;
            padding: 40px 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        h1 {
            text-align: center;
            color: #c9a962;
            margin-bottom: 10px;
            font-size: 2.5rem;
        }
        .subtitle {
            text-align: center;
            color: #a0a0a0;
            margin-bottom: 40px;
        }
        .card {
            background: #16213e;
            border: 1px solid #2d2d44;
            border-radius: 12px;
            padding: 30px;
            margin-bottom: 20px;
        }
        .card h2 {
            color: #c9a962;
            margin-bottom: 20px;
            font-size: 1.5rem;
        }
        .status-list {
            list-style: none;
        }
        .status-list li {
            padding: 8px 0;
            border-bottom: 1px solid #2d2d44;
            display: flex;
            justify-content: space-between;
        }
        .status-list li:last-child {
            border-bottom: none;
        }
        .success { color: #28a745; }
        .error { color: #dc3545; }
        .warning { color: #ffc107; }
        .btn {
            display: inline-block;
            padding: 12px 30px;
            background: linear-gradient(180deg, #c9a962 0%, #a08840 100%);
            color: #0f0f1a;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            transition: transform 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
        }
        .btn-block {
            display: block;
            text-align: center;
            width: 100%;
        }
        .steps {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 30px;
        }
        .step {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #1f2940;
            border: 2px solid #2d2d44;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        .step.active {
            border-color: #c9a962;
            background: #c9a962;
            color: #0f0f1a;
        }
        .step.completed {
            background: #28a745;
            border-color: #28a745;
        }
        .info-box {
            background: #1f2940;
            border-left: 4px solid #c9a962;
            padding: 15px;
            margin: 20px 0;
            border-radius: 0 8px 8px 0;
        }
        .code {
            background: #0f0f1a;
            padding: 15px;
            border-radius: 8px;
            font-family: monospace;
            font-size: 0.9rem;
            overflow-x: auto;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🏹 СКИФЫ</h1>
        <p class="subtitle">Установка игры</p>
        
        <div class="steps">
            <div class="step <?= $step === 'check' ? 'active' : ($step === 'db' ? 'completed' : '') ?>">1</div>
            <div class="step <?= $step === 'db' ? 'active' : '' ?>">2</div>
            <div class="step">3</div>
        </div>
        
        <?php if ($step === 'check'): ?>
        <div class="card">
            <h2>📋 Проверка требований</h2>
            
            <?php if (!empty($success)): ?>
            <ul class="status-list">
                <?php foreach ($success as $item): ?>
                <li><span><?= htmlspecialchars($item) ?></span> <span class="success">✓</span></li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
            
            <?php if (!empty($warnings)): ?>
            <h3 style="margin: 20px 0 10px; color: #ffc107;">⚠️ Предупреждения</h3>
            <ul class="status-list">
                <?php foreach ($warnings as $item): ?>
                <li><span><?= htmlspecialchars($item) ?></span> <span class="warning">!</span></li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
            <h3 style="margin: 20px 0 10px; color: #dc3545;">❌ Ошибки</h3>
            <ul class="status-list">
                <?php foreach ($errors as $item): ?>
                <li><span><?= htmlspecialchars($item) ?></span> <span class="error">✕</span></li>
                <?php endforeach; ?>
            </ul>
            
            <div class="info-box">
                <strong>Необходимо исправить ошибки</strong> перед продолжением установки.
            </div>
            <?php else: ?>
            
            <div class="info-box">
                <strong>Все проверки пройдены!</strong><br>
                Перед продолжением создайте базу данных:
                <div class="code">
                    CREATE DATABASE skifs CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
                </div>
                Затем импортируйте sql/schema.sql и sql/data.sql
            </div>
            
            <a href="?step=db" class="btn btn-block">Продолжить →</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <?php if ($step === 'db'): ?>
        <div class="card">
            <h2>🗄️ Установка базы данных</h2>
            
            <div class="info-box">
                <p><strong>Инструкция по установке БД:</strong></p>
                <ol style="margin-left: 20px; margin-top: 10px;">
                    <li>Откройте phpMyAdmin (обычно http://localhost/phpmyadmin)</li>
                    <li>Создайте базу данных <code>skifs</code></li>
                    <li>Выберите базу данных</li>
                    <li>Перейдите на вкладку "Импорт"</li>
                    <li>Выберите файл <code>sql/schema.sql</code></li>
                    <li>Нажмите "Вперёд"</li>
                    <li>Повторите для файла <code>sql/data.sql</code></li>
                </ol>
            </div>
            
            <div class="code">
Путь к файлам:<br>
<?= __DIR__ ?>/sql/schema.sql<br>
<?= __DIR__ ?>/sql/data.sql
            </div>
            
            <p style="margin: 20px 0; text-align: center;">
                После импорта SQL файлов перейдите на главную страницу:
            </p>
            
            <a href="/" class="btn btn-block">🏠 На главную</a>
            <a href="/skifs/" class="btn btn-block" style="margin-top: 10px;">🎮 Начать игру</a>
        </div>
        <?php endif; ?>
        
        <div class="card" style="text-align: center; color: #a0a0a0;">
            <p>СКИФЫ - Браузерная MMO RPG</p>
            <p style="font-size: 0.85rem; margin-top: 10px;">
                Тестовый аккаунт: <strong>admin / admin123</strong>
            </p>
        </div>
    </div>
</body>
</html>
