# 🏹 СКИФЫ - Полная документация проекта

## 📋 Содержание

1. [Быстрый старт](#быстрый-старт)
2. [Структура проекта](#структура-проекта)
3. [Настройка БД](#настройка-бд)
4. [Маршрутизация](#маршрутизация)
5. [API](#api)
6. [Устранение проблем](#устранение-проблем)

---

## 🚀 Быстрый старт

### 1. Установка

```bash
# Скопируйте проект в папку домена
C:\OpenServer\domains\sdfg.ru\
```

### 2. База данных

```sql
-- В phpMyAdmin создайте БД
CREATE DATABASE skifs CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Импортируйте схему
-- sql/schema.sql

-- Импортируйте тестовые данные (опционально)
-- sql/data.sql
```

### 3. Конфигурация

Откройте `config/config.php` и укажите ваши данные БД:

```php
define('DB_USER', 'skifs');     // Ваше имя пользователя
define('DB_PASS', 'ваш_пароль'); // Ваш пароль
```

### 4. Запуск

```
http://sdfg.ru/
```

---

## 📁 Структура проекта

```
skifs/
├── 📂 config/              # Конфигурация
│   └── config.php          # Основной конфиг (БД, сессии, константы)
│
├── 📂 src/                 # Исходный код PHP
│   ├── 📂 Core/
│   │   ├── Database.php    # PDO wrapper
│   │   └── Auth.php        # Авторизация
│   │
│   ├── 📂 Controllers/
│   │   ├── BaseController.php
│   │   ├── HomeController.php
│   │   ├── AuthController.php
│   │   └── ProfileController.php
│   │
│   ├── 📂 Models/          # (для будущих моделей)
│   ├── 📂 Repositories/    # (для будущих репозиториев)
│   └── 📂 Services/        # (для будущих сервисов)
│
├── 📂 public/              # Публичная директория (DOCUMENT_ROOT)
│   ├── index.php           # Точка входа
│   │
│   ├── 📂 assets/
│   │   ├── 📂 css/
│   │   │   ├── reset.css
│   │   │   ├── main.css
│   │   │   ├── components.css
│   │   │   └── mobile.css
│   │   ├── 📂 js/
│   │   │   ├── utils.js
│   │   │   ├── api.js
│   │   │   ├── ui.js
│   │   │   └── main.js
│   │   ├── 📂 img/
│   │   └── 📂 fonts/
│   │
│   └── 📂 templates/
│       ├── 📂 layouts/
│       │   └── main.php
│       ├── 📂 auth/
│       ├── 📂 home/
│       ├── 📂 profile/
│       └── 📂 errors/
│
├── 📂 sql/
│   ├── schema.sql          # Схема БД (26 таблиц)
│   └── data.sql            # Тестовые данные
│
├── 📂 logs/                # Логи
├── 📂 cache/               # Кэш
│
├── .htaccess               # Главный .htaccess
├── public/.htaccess        # Public .htaccess
├── check.php               # Диагностика
├── install.php             # Установщик
└── README.md               # Документация
```

---

## 🗄️ Настройка БД

### Создание пользователя MySQL

```sql
-- Создать пользователя
CREATE USER 'skifs'@'localhost' IDENTIFIED BY 'skifs123';

-- Создать БД и дать права
CREATE DATABASE skifs CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
GRANT ALL PRIVILEGES ON skifs.* TO 'skifs'@'localhost';
FLUSH PRIVILEGES;
```

### Импорт схемы

```bash
# Через консоль
mysql -u skifs -p skifs < sql/schema.sql
mysql -u skifs -p skifs < sql/data.sql

# Или через phpMyAdmin: Импорт → Выбрать файл
```

---

## 🛣️ Маршрутизация

### Как работает роутинг

```
URL → Контроллер → Метод
/auth/login → AuthController → loginAction()
/profile → ProfileController → indexAction()
/battle/start → BattleController → startAction()
```

### Доступные маршруты

#### Публичные (не требуют авторизации)
| URL | Контроллер | Описание |
|-----|------------|----------|
| `/` | HomeController | Главная |
| `/home/about` | HomeController | Об игре |
| `/auth/login` | AuthController | Вход |
| `/auth/register` | AuthController | Регистрация |

#### Требуют авторизации
| URL | Контроллер | Описание |
|-----|------------|----------|
| `/profile` | ProfileController | Профиль |
| `/training` | TrainingController | Тренировка |
| `/battle` | BattleController | Дикое Поле |
| `/pvp` | PvPController | Кровавый Круг |
| `/clan` | ClanController | Племя |
| `/inventory` | InventoryController | Инвентарь |
| `/quest` | QuestController | Квесты |
| `/amulet` | AmuletController | Оберег |

---

## 🔌 API

### Базовый URL

```
/api/{controller}/{action}
```

### Примеры запросов

```javascript
// Авторизация
await Api.auth.login('admin', 'admin123');

// Профиль
await Api.profile.get();
await Api.profile.train('fury_steppe', 1);

// Бой
await Api.battle.start(1);
await Api.battle.attack('normal');

// Инвентарь
await Api.inventory.get();
await Api.inventory.equip(123);
```

### Все эндпоинты

```
POST /api/auth/login
POST /api/auth/register
POST /api/auth/logout

GET  /api/profile
POST /api/profile/train

POST /api/battle/start
POST /api/battle/attack
POST /api/battle/flee

GET  /api/inventory
POST /api/inventory/equip
POST /api/inventory/unequip
```

---

## 🔧 Устранение проблем

### Ошибка: Access denied for user

**Проблема:** Неверный пароль БД

**Решение:**
```php
// config/config.php
define('DB_USER', 'skifs');
define('DB_PASS', 'ваш_пароль');
```

### Ошибка: Session cannot be started

**Проблема:** Сессия начинается после вывода

**Решение:** Убедитесь, что `config.php` подключается в самом начале `index.php`

### Ошибка: 404 на всех страницах

**Проблема:** Не работает mod_rewrite

**Решение:**
1. Проверьте `.htaccess`
2. Включите mod_rewrite в Apache
3. Проверьте `BASE_URL` в `config.php`

### Ошибка: Class not found

**Проблема:** Не работает автозагрузчик

**Решение:** Проверьте пространство имён:
```php
namespace App\Controllers;
```

### Белый экран

**Проблема:** Скрытая ошибка PHP

**Решение:**
```php
// config/config.php
define('DEBUG', true);
```

Проверьте `logs/` на наличие ошибок.

---

## 📊 Таблицы базы данных

### Основные
- `users` - пользователи
- `hero_stats` - характеристики
- `user_currency` - валюта
- `user_materials` - материалы

### Боевка
- `enemy_types` - враги
- `battles` - бои
- `user_timers` - таймеры

### Кланы
- `clans` - племена
- `clan_members` - участники
- `clan_buildings` - здания

### Прогрессия
- `campaign_chapters` - главы
- `quests` - квесты
- `user_quest_progress` - прогресс

### Доп. системы
- `user_amulet` - оберег
- `pvp_rating` - рейтинг
- `daily_tasks` - задания

---

## 🎮 Игровые константы

### Характеристики
```php
STARTING_FURY = 10      // Ярость Степи
STARTING_BLOOD = 100    // Кровь Кочевника
STARTING_COPPER = 5     // Медная Чешуя
```

### Валюты
```php
STARTING_BRONZE = 100   // Бронзовые Наконечники
STARTING_GOLD = 10      // Золото Курганов
```

### Боевка
```php
MAX_BATTLES_PER_DAY = 15
BATTLE_COOLDOWN = 1800  // 30 минут
MAX_ENERGY = 10
```

---

## 📞 Поддержка

### Диагностика
```
http://sdfg.ru/check.php
```

### Логи
```
logs/{дата}.log
```

### Тестовый аккаунт
```
Логин: admin
Пароль: admin123
```

---

**Версия:** 0.1.0-alpha  
**Последнее обновление:** 2024
