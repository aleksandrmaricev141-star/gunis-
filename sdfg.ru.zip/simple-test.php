<?php
/**
 * Простой тест - просто покажем текст
 */
echo "СКИФЫ - ТЕСТ\n";
echo "============\n\n";

// Проверка конфига
if (file_exists(__DIR__ . '/config/config.php')) {
    echo "✓ config/config.php существует\n";
    require_once __DIR__ . '/config/config.php';
    echo "✓ config.php загружен\n";
    echo "  DB_HOST: " . DB_HOST . "\n";
    echo "  DB_NAME: " . DB_NAME . "\n";
    echo "  DB_USER: " . DB_USER . "\n";
    echo "  BASE_URL: " . BASE_URL . "\n";
} else {
    echo "✗ config/config.php не найден\n";
}

echo "\n";

// Проверка БД
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS
    );
    echo "✓ Подключение к БД: OK\n";
    
    // Проверка таблиц
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo "  Таблиц: " . count($tables) . "\n";
    
    // Проверка пользователей
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $count = $stmt->fetchColumn();
    echo "  Пользователей: " . $count . "\n";
    
} catch (PDOException $e) {
    echo "✗ Подключение к БД: " . $e->getMessage() . "\n";
}

echo "\n";

// Проверка файлов
$files = [
    'public/index.php',
    'src/Controllers/AuthController.php',
    'src/Controllers/HomeController.php',
    'src/Controllers/ProfileController.php',
    'public/templates/layouts/main.php',
    'public/templates/auth/form.php',
    'public/templates/home/index.php',
    'public/templates/profile/index.php',
];

foreach ($files as $file) {
    $path = __DIR__ . '/' . $file;
    if (file_exists($path)) {
        echo "✓ $file\n";
    } else {
        echo "✗ $file\n";
    }
}

echo "\n";
echo "Тест завершён.\n";
echo "Откройте http://" . $_SERVER['HTTP_HOST'] . BASE_URL . "/auth/register\n";
