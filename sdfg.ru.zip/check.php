<?php
/**
 * СКИФЫ - Проверка конфигурации
 * Запустите этот файл для быстрой диагностики
 */

// Подключаем конфиг для получения данных БД
require_once __DIR__ . '/config/config.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>СКИФЫ - Диагностика</title>
    <style>
        body {
            font-family: monospace;
            background: #0f0f1a;
            color: #e8e8e8;
            padding: 20px;
            max-width: 900px;
            margin: 0 auto;
        }
        h1 { color: #c9a962; }
        .ok { color: #28a745; }
        .error { color: #dc3545; }
        .warn { color: #ffc107; }
        pre {
            background: #16213e;
            padding: 15px;
            border-radius: 8px;
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            padding: 10px;
            border: 1px solid #2d2d44;
            text-align: left;
        }
        th { background: #1f2940; color: #c9a962; }
    </style>
</head>
<body>
    <h1>🔍 СКИФЫ - Диагностика</h1>
    <p>Время проверки: <?= date('Y-m-d H:i:s') ?></p>
    
    <h2>📋 Информация о сервере</h2>
    <table>
        <tr>
            <th>Параметр</th>
            <th>Значение</th>
        </tr>
        <tr>
            <td>Версия PHP</td>
            <td class="<?= version_compare(PHP_VERSION, '8.0.0', '>=') ? 'ok' : 'error' ?>">
                <?= PHP_VERSION ?>
            </td>
        </tr>
        <tr>
            <td>ОС</td>
            <td><?= PHP_OS ?></td>
        </tr>
        <tr>
            <td>Веб-сервер</td>
            <td><?= $_SERVER['SERVER_SOFTWARE'] ?? 'Не определено' ?></td>
        </tr>
        <tr>
            <td>Путь к проекту</td>
            <td><?= __DIR__ ?></td>
        </tr>
        <tr>
            <td>DOCUMENT_ROOT</td>
            <td><?= $_SERVER['DOCUMENT_ROOT'] ?? 'Не определено' ?></td>
        </tr>
    </table>
    
    <h2>📦 Расширения PHP</h2>
    <table>
        <tr>
            <th>Расширение</th>
            <th>Статус</th>
            <th>Версия</th>
        </tr>
        <?php
        $extensions = ['pdo', 'pdo_mysql', 'json', 'mbstring', 'session', 'curl', 'openssl'];
        foreach ($extensions as $ext):
            $loaded = extension_loaded($ext);
            $version = $loaded ? phpversion($ext) : '-';
        ?>
        <tr>
            <td><?= $ext ?></td>
            <td class="<?= $loaded ? 'ok' : 'error' ?>"><?= $loaded ? '✓' : '✕' ?></td>
            <td><?= $version ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    
    <h2>🗄️ База данных</h2>
    <?php
    // Используем константы из config.php если они есть
    $dbHost = defined('DB_HOST') ? DB_HOST : 'localhost';
    $dbPort = defined('DB_PORT') ? DB_PORT : '3306';
    $dbName = defined('DB_NAME') ? DB_NAME : 'skifs';
    $dbUser = defined('DB_USER') ? DB_USER : 'skifs';
    $dbPass = defined('DB_PASS') ? DB_PASS : '';
    
    $dbConfig = [
        'host' => $dbHost,
        'port' => $dbPort,
        'name' => $dbName,
        'user' => $dbUser,
        'pass' => $dbPass
    ];

    $pdo = null;
    try {
        $dsn = sprintf(
            'mysql:host=%s;port=%s;charset=utf8mb4',
            $dbConfig['host'],
            $dbConfig['port']
        );
        $pdo = new PDO($dsn, $dbConfig['user'], $dbConfig['pass']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $mysqlVersion = $pdo->getAttribute(PDO::ATTR_SERVER_VERSION);
        echo '<p class="ok">✓ Подключение к MySQL успешно</p>';
        echo '<p>Версия MySQL: <strong>' . $mysqlVersion . '</strong></p>';

        // Проверка БД
        $stmt = $pdo->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '{$dbConfig['name']}'");
        $dbExists = $stmt->rowCount() > 0;

        if ($dbExists) {
            echo '<p class="ok">✓ База данных "' . $dbConfig['name'] . '" существует</p>';
            
            // Проверка таблиц
            $stmt = $pdo->query("SHOW TABLES FROM {$dbConfig['name']}");
            $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            echo '<p>Найдено таблиц: <strong>' . count($tables) . '</strong></p>';
            
            if (count($tables) > 0) {
                echo '<pre>' . htmlspecialchars(implode(', ', $tables)) . '</pre>';
            }
            
            // Проверка данных
            $stmt = $pdo->query("SELECT COUNT(*) FROM {$dbConfig['name']}.users");
            $userCount = $stmt->fetchColumn();
            echo '<p>Пользователей в БД: <strong>' . $userCount . '</strong></p>';
            
        } else {
            echo '<p class="error">✕ База данных "' . $dbConfig['name'] . '" не существует</p>';
            echo '<div class="warn">Создайте базу данных:</div>';
            echo '<pre>CREATE DATABASE skifs CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;</pre>';
        }
        
    } catch (PDOException $e) {
        echo '<p class="error">✕ Ошибка подключения к MySQL</p>';
        echo '<pre>' . htmlspecialchars($e->getMessage()) . '</pre>';
    }
    ?>
    
    <h2>📁 Права на файлы</h2>
    <table>
        <tr>
            <th>Директория</th>
            <th>Существует</th>
            <th>Доступна для записи</th>
        </tr>
        <?php
        $dirs = ['logs', 'cache', 'public', 'config', 'src', 'sql'];
        foreach ($dirs as $dir):
            $path = __DIR__ . '/' . $dir;
            $exists = is_dir($path);
            $writable = is_writable($path);
        ?>
        <tr>
            <td><?= $dir ?></td>
            <td class="<?= $exists ? 'ok' : 'error' ?>"><?= $exists ? '✓' : '✕' ?></td>
            <td class="<?= $writable ? 'ok' : ($exists ? 'warn' : '') ?>">
                <?= $writable ? '✓' : ($exists ? 'Нет прав' : '-') ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    
    <h2>⚙️ Конфигурация</h2>
    <?php
    $configFile = __DIR__ . '/config/config.php';
    if (file_exists($configFile)) {
        echo '<p class="ok">✓ config/config.php существует</p>';
        
        // Проверка констант
        require_once $configFile;
        
        $constants = ['DB_HOST', 'DB_NAME', 'DB_USER', 'DEBUG', 'BASE_URL'];
        echo '<table><tr><th>Константа</th><th>Значение</th></tr>';
        foreach ($constants as $const) {
            if (defined($const)) {
                $value = constant($const);
                if (strpos($const, 'PASS') !== false) {
                    $value = '***';
                }
                echo '<tr><td>' . $const . '</td><td>' . htmlspecialchars($value) . '</td></tr>';
            } else {
                echo '<tr><td>' . $const . '</td><td class="error">Не определена</td></tr>';
            }
        }
        echo '</table>';
    } else {
        echo '<p class="error">✕ config/config.php не найден</p>';
    }
    ?>
    
    <h2>🔗 URL тесты</h2>
    <table>
        <tr>
            <th>URL</th>
            <th>Статус</th>
        </tr>
        <tr>
            <td>BASE_URL</td>
            <td><?= defined('BASE_URL') ? BASE_URL : '<span class="error">Не определено</span>' ?></td>
        </tr>
        <tr>
            <td>ASSETS_URL</td>
            <td><?= defined('ASSETS_URL') ? ASSETS_URL : '<span class="error">Не определено</span>' ?></td>
        </tr>
    </table>
    
    <h2>📝 Рекомендации</h2>
    <ul>
        <?php if (!defined('BASE_URL')): ?>
        <li class="error">Настройте BASE_URL в config/config.php</li>
        <?php endif; ?>

        <?php if (!is_dir(__DIR__ . '/logs')): ?>
        <li class="warn">Создайте директорию logs для логирования</li>
        <?php endif; ?>

        <?php if (!is_dir(__DIR__ . '/cache')): ?>
        <li class="warn">Создайте директорию cache для кэширования</li>
        <?php endif; ?>

        <?php if (isset($pdo) && $pdo): 
            try {
                $stmt = $pdo->query("SELECT COUNT(*) FROM {$dbConfig['name']}.users");
                $userCount = $stmt->fetchColumn();
            } catch (PDOException $e) {
                $userCount = 0;
            }
            if ($userCount == 0):
        ?>
        <li class="warn">Импортируйте sql/data.sql для тестовых данных</li>
        <?php endif; ?>
        <?php endif; ?>
    </ul>
    
    <hr style="border-color: #2d2d44; margin: 30px 0;">
    <p style="text-align: center; color: #6c757d;">
        СКИФЫ v0.1.0-alpha | Браузерная MMO RPG
    </p>
</body>
</html>
