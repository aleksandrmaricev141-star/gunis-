/**
 * СКИФЫ - API клиент
 * Взаимодействие с сервером через AJAX
 */

'use strict';

const Api = {
    baseUrl: '/skifs/api',
    
    /**
     * Базовый запрос
     */
    async request(endpoint, options = {}) {
        const url = `${this.baseUrl}${endpoint}`;
        
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': window.csrfToken || this.getCsrfToken(),
                'X-Requested-With': 'XMLHttpRequest'
            }
        };
        
        const config = {
            ...defaultOptions,
            ...options,
            headers: {
                ...defaultOptions.headers,
                ...(options.headers || {})
            }
        };
        
        try {
            const response = await fetch(url, config);
            const data = await response.json();
            
            if (!response.ok) {
                throw new ApiError(data.error || 'Ошибка запроса', response.status, data);
            }
            
            return data;
        } catch (error) {
            if (error instanceof ApiError) {
                throw error;
            }
            throw new ApiError('Ошибка сети: ' + error.message, 0);
        }
    },
    
    /**
     * GET запрос
     */
    async get(endpoint, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        const url = queryString ? `${endpoint}?${queryString}` : endpoint;
        
        return this.request(url, {
            method: 'GET'
        });
    },
    
    /**
     * POST запрос
     */
    async post(endpoint, data = {}) {
        return this.request(endpoint, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    },
    
    /**
     * PUT запрос
     */
    async put(endpoint, data = {}) {
        return this.request(endpoint, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    },
    
    /**
     * DELETE запрос
     */
    async delete(endpoint) {
        return this.request(endpoint, {
            method: 'DELETE'
        });
    },
    
    /**
     * Получить CSRF токен из мета-тега
     */
    getCsrfToken() {
        const meta = document.querySelector('meta[name="csrf-token"]');
        return meta ? meta.getAttribute('content') : '';
    },
    
    // ============================================================
    // АВТОРИЗАЦИЯ
    // ============================================================
    
    auth: {
        login(login, password) {
            return Api.post('/auth/login', { login, password });
        },
        
        register(username, email, password, password_confirm) {
            return Api.post('/auth/register', { username, email, password, password_confirm });
        },
        
        logout() {
            return Api.post('/auth/logout');
        },
        
        resetPassword(email) {
            return Api.post('/auth/reset-password', { email });
        },
        
        newPassword(token, password, password_confirm) {
            return Api.post('/auth/new-password', { token, password, password_confirm });
        }
    },
    
    // ============================================================
    // ПРОФИЛЬ ИГРОКА
    // ============================================================
    
    profile: {
        get() {
            return Api.get('/profile');
        },
        
        train(statType, amount = 1) {
            return Api.post('/profile/train', { stat_type: statType, amount });
        },
        
        view(userId) {
            return Api.get('/profile/view', { id: userId });
        }
    },
    
    // ============================================================
    // БОЕВАЯ СИСТЕМА
    // ============================================================
    
    battle: {
        start(enemyId) {
            return Api.post('/battle/start', { enemy_id: enemyId });
        },
        
        attack(skill = 'normal') {
            return Api.post('/battle/attack', { skill });
        },
        
        flee() {
            return Api.post('/battle/flee');
        },
        
        getLog() {
            return Api.get('/battle/log');
        }
    },
    
    // ============================================================
    // PVP
    // ============================================================
    
    pvp: {
        getLeaderboard() {
            return Api.get('/pvp/leaderboard');
        },
        
        findMatch() {
            return Api.post('/pvp/find-match');
        },
        
        attack(skill = 'normal') {
            return Api.post('/pvp/attack', { skill });
        },
        
        getRating() {
            return Api.get('/pvp/rating');
        }
    },
    
    // ============================================================
    // ИНВЕНТАРЬ
    // ============================================================
    
    inventory: {
        get() {
            return Api.get('/inventory');
        },
        
        equip(itemId) {
            return Api.post('/inventory/equip', { item_id: itemId });
        },
        
        unequip(slot) {
            return Api.post('/inventory/unequip', { slot });
        },
        
        disassemble(itemId) {
            return Api.post('/inventory/disassemble', { item_id: itemId });
        },
        
        use(itemId, targetId = null) {
            return Api.post('/inventory/use', { item_id: itemId, target_id: targetId });
        },
        
        upgrade(itemId, materialId = null) {
            return Api.post('/inventory/upgrade', { item_id: itemId, material_id: materialId });
        },
        
        insertRune(itemId, runeId, slot) {
            return Api.post('/inventory/insert-rune', { item_id: itemId, rune_id: runeId, slot });
        },
        
        removeRune(itemId, slot) {
            return Api.post('/inventory/remove-rune', { item_id: itemId, slot });
        }
    },
    
    // ============================================================
    // КВЕСТЫ
    // ============================================================
    
    quest: {
        getList() {
            return Api.get('/quest/list');
        },
        
        getProgress(questId) {
            return Api.get('/quest/progress', { quest_id: questId });
        },
        
        claim(questId) {
            return Api.post('/quest/claim', { quest_id: questId });
        },
        
        getChapters() {
            return Api.get('/quest/chapters');
        }
    },
    
    // ============================================================
    // КЛАНЫ (ПЛЕМЕНА)
    // ============================================================
    
    clan: {
        get() {
            return Api.get('/clan');
        },
        
        create(name, tag) {
            return Api.post('/clan/create', { name, tag });
        },
        
        getLeaderboard() {
            return Api.get('/clan/leaderboard');
        },
        
        apply(clanId, message = '') {
            return Api.post('/clan/apply', { clan_id: clanId, message });
        },
        
        leave() {
            return Api.post('/clan/leave');
        },
        
        kick(userId) {
            return Api.post('/clan/kick', { user_id: userId });
        },
        
        changeRole(userId, role) {
            return Api.post('/clan/change-role', { user_id: userId, role });
        },
        
        donate(amount, currency = 'bronze') {
            return Api.post('/clan/donate', { amount, currency });
        },
        
        upgradeBuilding(buildingType) {
            return Api.post('/clan/upgrade-building', { building_type: buildingType });
        },
        
        startRitual(buildingType, ritualType = 'normal') {
            return Api.post('/clan/start-ritual', { building_type: buildingType, ritual_type: ritualType });
        },
        
        getLogs() {
            return Api.get('/clan/logs');
        }
    },
    
    // ============================================================
    // ОБЕРЕГ
    // ============================================================
    
    amulet: {
        get() {
            return Api.get('/amulet');
        },
        
        feed(amount) {
            return Api.post('/amulet/feed', { amount });
        },
        
        upgrade() {
            return Api.post('/amulet/upgrade');
        }
    },
    
    // ============================================================
    // МАГАЗИН
    // ============================================================
    
    shop: {
        getItems() {
            return Api.get('/shop/items');
        },
        
        buy(itemId, quantity = 1) {
            return Api.post('/shop/buy', { item_id: itemId, quantity });
        },
        
        sell(itemId, quantity = 1) {
            return Api.post('/shop/sell', { item_id: itemId, quantity });
        }
    },
    
    // ============================================================
    // ЕЖЕДНЕВНЫЕ ЗАДАНИЯ
    // ============================================================
    
    daily: {
        getTasks() {
            return Api.get('/daily/tasks');
        },
        
        claim(taskId) {
            return Api.post('/daily/claim', { task_id: taskId });
        }
    },
    
    // ============================================================
    // ИВЕНТЫ
    // ============================================================
    
    events: {
        getActive() {
            return Api.get('/events/active');
        },
        
        siegeJoin() {
            return Api.post('/events/siege/join');
        },
        
        siegeAttack() {
            return Api.post('/events/siege/attack');
        },
        
        caravanRaid() {
            return Api.post('/events/caravan/raid');
        }
    }
};

/**
 * Класс ошибки API
 */
class ApiError extends Error {
    constructor(message, status, data = null) {
        super(message);
        this.name = 'ApiError';
        this.status = status;
        this.data = data;
    }
}

// Экспорт для глобального доступа
window.Api = Api;
window.ApiError = ApiError;
