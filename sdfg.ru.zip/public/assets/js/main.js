/**
 * СКИФЫ - Главный JS файл
 * Инициализация игры
 */

'use strict';

// Глобальные переменные
window.Game = {
    // Состояние игры
    state: {
        user: null,
        activeBattle: null,
        activeEvent: null,
        lastUpdate: Date.now()
    },
    
    // Конфигурация
    config: {
        // Частота обновления (мс)
        updateInterval: 1000,
        
        // Авто-сохранение (мс)
        autoSaveInterval: 30000,
        
        // Таймаут запросов (мс)
        requestTimeout: 10000,
        
        // Звуки
        soundEnabled: true,
        musicEnabled: true,
        
        // Уведомления
        notificationsEnabled: true,
        
        // Анимации
        animationsEnabled: true
    },
    
    /**
     * Инициализация игры
     */
    async init() {
        console.log('🏹 СКИФЫ - Инициализация игры...');
        
        try {
            // Загружаем данные пользователя
            await this.loadUserData();
            
            // Инициализируем компоненты
            this.initComponents();
            
            // Запускаем игровой цикл
            this.startGameLoop();
            
            // Настраиваем события
            this.initEvents();
            
            // Проверяем обновления
            this.checkUpdates();
            
            console.log('✅ Игра готова!');
            
        } catch (error) {
            console.error('❌ Ошибка инициализации:', error);
            UI.toast('Ошибка загрузки игры. Обновите страницу.', 'error');
        }
    },
    
    /**
     * Загрузка данных пользователя
     */
    async loadUserData() {
        const userElement = document.querySelector('.player-mini-info');
        if (!userElement) {
            // Пользователь не авторизован
            return;
        }
        
        try {
            // Получаем данные из DOM (уже загружены сервером)
            this.state.user = {
                id: parseInt(userElement.dataset.userId || 0),
                username: userElement.querySelector('.player-name')?.textContent || '',
                level: parseInt(userElement.querySelector('.player-level')?.textContent.replace('Ур. ', '') || 1)
            };
            
            // Обновляем ресурсы
            this.updateResources();
            
        } catch (error) {
            console.error('Ошибка загрузки данных пользователя:', error);
        }
    },
    
    /**
     * Обновление ресурсов
     */
    updateResources() {
        const resourcesBar = document.querySelector('.resources-bar');
        if (!resourcesBar) return;
        
        // Здесь можно добавить AJAX обновление ресурсов
        // Пока данные обновляются при загрузке страницы
    },
    
    /**
     * Инициализация компонентов
     */
    initComponents() {
        // UI компоненты уже инициализированы в ui.js
        
        // Инициализация игровых компонентов
        this.initBattleSystem();
        this.initTradeSystem();
        this.initClanSystem();
    },
    
    /**
     * Инициализация боевой системы
     */
    initBattleSystem() {
        // Обработчики кнопок боя
        document.querySelectorAll('[data-battle-action]').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.preventDefault();
                
                const action = btn.dataset.battleAction;
                const enemyId = btn.dataset.enemyId;
                
                try {
                    btn.disabled = true;
                    
                    switch (action) {
                        case 'start':
                            await this.startBattle(enemyId);
                            break;
                        case 'attack':
                            await this.battleAttack(btn.dataset.skill || 'normal');
                            break;
                        case 'flee':
                            await this.battleFlee();
                            break;
                    }
                } catch (error) {
                    UI.toast(error.message, 'error');
                } finally {
                    btn.disabled = false;
                }
            });
        });
    },
    
    /**
     * Начало боя
     */
    async startBattle(enemyId) {
        try {
            const result = await Api.battle.start(enemyId);
            
            this.state.activeBattle = result.battle;
            
            // Показываем боевую сцену
            this.showBattleScene(result.battle);
            
        } catch (error) {
            throw error;
        }
    },
    
    /**
     * Атака в бою
     */
    async battleAttack(skill) {
        try {
            const result = await Api.battle.attack(skill);
            
            // Обновляем боевую сцену
            this.updateBattleScene(result.battle);
            
            // Проверяем конец боя
            if (result.battle.ended) {
                this.endBattle(result.battle);
            }
            
        } catch (error) {
            throw error;
        }
    },
    
    /**
     * Побег из боя
     */
    async battleFlee() {
        try {
            const result = await Api.battle.flee();
            
            this.endBattle(result.battle);
            
        } catch (error) {
            throw error;
        }
    },
    
    /**
     * Показ боевой сцены
     */
    showBattleScene(battle) {
        const scene = document.querySelector('.battle-scene');
        if (!scene) return;
        
        scene.innerHTML = `
            <div class="battle-field">
                <div class="battle-character player">
                    <div class="battle-sprite">🗡️</div>
                    <div class="battle-hp-bar">
                        <div class="battle-hp-label">
                            <span>Вы</span>
                            <span class="hp-current">${battle.playerHp}/${battle.playerMaxHp}</span>
                        </div>
                        <div class="progress">
                            <div class="progress-bar hp" style="width: ${(battle.playerHp / battle.playerMaxHp) * 100}%"></div>
                        </div>
                    </div>
                </div>
                
                <div class="battle-character enemy">
                    <div class="battle-sprite">👹</div>
                    <div class="battle-hp-bar">
                        <div class="battle-hp-label">
                            <span>${battle.enemyName}</span>
                            <span class="hp-current">${battle.enemyHp}/${battle.enemyMaxHp}</span>
                        </div>
                        <div class="progress">
                            <div class="progress-bar hp" style="width: ${(battle.enemyHp / battle.enemyMaxHp) * 100}%"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="battle-log" id="battle-log"></div>
            
            <div class="battle-actions">
                <button class="btn btn-danger" data-battle-action="attack" data-skill="normal">⚔️ Атака</button>
                <button class="btn btn-primary" data-battle-action="attack" data-skill="strong">💥 Сильный удар</button>
                <button class="btn btn-secondary" data-battle-action="flee">🏃 Побег</button>
            </div>
        `;
        
        // Пер-инициализируем обработчики
        this.initBattleSystem();
    },
    
    /**
     * Обновление боевой сцены
     */
    updateBattleScene(battle) {
        // Обновляем HP
        const hpBars = document.querySelectorAll('.battle-hp-bar');
        if (hpBars.length >= 2) {
            // Игрок
            hpBars[0].querySelector('.hp-current').textContent = `${battle.playerHp}/${battle.playerMaxHp}`;
            hpBars[0].querySelector('.progress-bar').style.width = `${(battle.playerHp / battle.playerMaxHp) * 100}%`;
            
            // Враг
            hpBars[1].querySelector('.hp-current').textContent = `${battle.enemyHp}/${battle.enemyMaxHp}`;
            hpBars[1].querySelector('.progress-bar').style.width = `${(battle.enemyHp / battle.enemyMaxHp) * 100}%`;
        }
        
        // Добавляем запись в лог
        const log = document.getElementById('battle-log');
        if (log && battle.lastAction) {
            const entry = document.createElement('div');
            entry.className = `battle-log-entry ${battle.lastAction.type}`;
            if (battle.lastAction.isCrit) {
                entry.classList.add('crit');
            }
            entry.textContent = battle.lastAction.text;
            log.insertBefore(entry, log.firstChild);
            
            // Ограничиваем размер лога
            while (log.children.length > 50) {
                log.removeChild(log.lastChild);
            }
        }
    },
    
    /**
     * Конец боя
     */
    endBattle(battle) {
        this.state.activeBattle = null;
        
        if (battle.result === 'win') {
            UI.toast(`Победа! +${battle.expGained} опыта, +${battle.bronzeGained} бронзы`, 'success');
        } else if (battle.result === 'lose') {
            UI.toast('Поражение. Отступайте и лечитесь!', 'error');
        }
        
        // Перезагрузка страницы для обновления данных
        setTimeout(() => {
            location.reload();
        }, 2000);
    },
    
    /**
     * Инициализация торговой системы
     */
    initTradeSystem() {
        // Обработчики кнопок покупки/продажи
        document.querySelectorAll('[data-trade-action]').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.preventDefault();
                
                const action = btn.dataset.tradeAction;
                const itemId = btn.dataset.itemId;
                const quantity = parseInt(btn.dataset.quantity || 1);
                
                try {
                    btn.disabled = true;
                    
                    if (action === 'buy') {
                        await Api.shop.buy(itemId, quantity);
                        UI.toast('Предмет куплен', 'success');
                    } else if (action === 'sell') {
                        await Api.shop.sell(itemId, quantity);
                        UI.toast('Предмет продан', 'success');
                    }
                    
                    setTimeout(() => location.reload(), 1000);
                    
                } catch (error) {
                    UI.toast(error.message, 'error');
                } finally {
                    btn.disabled = false;
                }
            });
        });
    },
    
    /**
     * Инициализация клановой системы
     */
    initClanSystem() {
        // Обработчики действий клана
        document.querySelectorAll('[data-clan-action]').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.preventDefault();
                
                const action = btn.dataset.clanAction;
                
                try {
                    btn.disabled = true;
                    
                    switch (action) {
                        case 'create':
                            await this.createClan();
                            break;
                        case 'apply':
                            await this.applyToClan(btn.dataset.clanId);
                            break;
                        case 'leave':
                            await UI.confirm('Вы уверены, что хотите покинуть племя?');
                            await Api.clan.leave();
                            UI.toast('Вы покинули племя', 'info');
                            setTimeout(() => location.reload(), 1000);
                            break;
                        case 'donate':
                            await this.clanDonate();
                            break;
                        case 'upgrade-building':
                            await this.upgradeBuilding(btn.dataset.buildingType);
                            break;
                    }
                } catch (error) {
                    if (error.message !== 'Cancelled') {
                        UI.toast(error.message, 'error');
                    }
                } finally {
                    btn.disabled = false;
                }
            });
        });
    },
    
    /**
     * Создание клана
     */
    async createClan() {
        const name = prompt('Название племени:');
        if (!name) return;
        
        const tag = prompt('Тег племени (до 5 символов):');
        if (!tag) return;
        
        await Api.clan.create(name, tag);
        UI.toast('Племя создано!', 'success');
        setTimeout(() => location.reload(), 1000);
    },
    
    /**
     * Подача заявки в клан
     */
    async applyToClan(clanId) {
        const message = prompt('Сообщение лидеру (необязательно):', '');
        
        await Api.clan.apply(clanId, message || '');
        UI.toast('Заявка отправлена', 'success');
    },
    
    /**
     * Пожертвование в клан
     */
    async clanDonate() {
        const amount = prompt('Сумма пожертвования:', '100');
        if (!amount) return;
        
        const currency = prompt('Валюта (bronze/gold):', 'bronze');
        
        await Api.clan.donate(parseInt(amount), currency);
        UI.toast('Пожертвование внесено', 'success');
        setTimeout(() => location.reload(), 1000);
    },
    
    /**
     * Улучшение здания клана
     */
    async upgradeBuilding(buildingType) {
        if (await UI.confirm('Улучшить здание?')) {
            await Api.clan.upgradeBuilding(buildingType);
            UI.toast('Здание улучшается', 'success');
            setTimeout(() => location.reload(), 1000);
        }
    },
    
    /**
     * Настройка событий
     */
    initEvents() {
        // Обработка видимости вкладки
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.onPageHidden();
            } else {
                this.onPageVisible();
            }
        });
        
        // Предупреждение о закрытии с активным боем
        window.addEventListener('beforeunload', (e) => {
            if (this.state.activeBattle) {
                e.preventDefault();
                e.returnValue = '';
            }
        });
        
        // Обновление таймеров
        setInterval(() => {
            this.updateTimers();
        }, 1000);
    },
    
    /**
     * Страница скрыта
     */
    onPageHidden() {
        console.log('Страница скрыта');
        // Можно приостановить анимации
    },
    
    /**
     * Страница видима
     */
    onPageVisible() {
        console.log('Страница видима');
        this.checkUpdates();
    },
    
    /**
     * Обновление таймеров
     */
    updateTimers() {
        // Обновление таймеров кулдаунов
        document.querySelectorAll('[data-timer]').forEach(timer => {
            const targetTime = new Date(timer.dataset.timer).getTime();
            const now = Date.now();
            const diff = targetTime - now;
            
            if (diff <= 0) {
                timer.textContent = 'Готово!';
                timer.classList.add('ready');
            } else {
                timer.textContent = formatTime(Math.floor(diff / 1000));
            }
        });
    },
    
    /**
     * Запуск игрового цикла
     */
    startGameLoop() {
        let lastUpdate = Date.now();
        
        const gameLoop = () => {
            const now = Date.now();
            const delta = now - lastUpdate;
            
            if (delta >= this.config.updateInterval) {
                this.update(delta);
                lastUpdate = now;
            }
            
            requestAnimationFrame(gameLoop);
        };
        
        requestAnimationFrame(gameLoop);
        
        // Авто-сохранение
        setInterval(() => {
            this.autoSave();
        }, this.config.autoSaveInterval);
    },
    
    /**
     * Обновление игры
     */
    update(delta) {
        this.state.lastUpdate = Date.now();
        
        // Здесь будет логика обновления
    },
    
    /**
     * Авто-сохранение
     */
    autoSave() {
        // Сохранение локальных настроек
        localStorage.setItem('skifs_config', JSON.stringify(this.config));
    },
    
    /**
     * Проверка обновлений
     */
    async checkUpdates() {
        try {
            // Проверка новых уведомлений, событий и т.д.
            const updates = await Api.get('/updates/check');
            
            if (updates.notifications > 0) {
                UI.toast(`У вас ${updates.notifications} новых уведомлений`, 'info');
            }
        } catch (error) {
            // Игнорируем ошибки проверки обновлений
        }
    }
};

// Запуск игры после загрузки DOM
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => Game.init());
} else {
    Game.init();
}

// Экспорт
window.Game = Game;
