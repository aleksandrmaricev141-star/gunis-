/**
 * СКИФЫ - Утилиты
 * Базовые вспомогательные функции
 */

'use strict';

/**
 * Форматирование чисел (1 000 000)
 */
function formatNumber(num) {
    return new Intl.NumberFormat('ru-RU').format(num);
}

/**
 * Форматирование времени (HH:MM:SS)
 */
function formatTime(seconds) {
    if (seconds <= 0) return '00:00:00';
    
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    
    return [h, m, s]
        .map(v => v.toString().padStart(2, '0'))
        .join(':');
}

/**
 * Форматирование относительного времени ("5 минут назад")
 */
function timeAgo(date) {
    const now = new Date();
    const then = new Date(date);
    const diff = Math.floor((now - then) / 1000);
    
    if (diff < 60) return 'только что';
    if (diff < 3600) return `${Math.floor(diff / 60)} мин. назад`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} ч. назад`;
    if (diff < 604800) return `${Math.floor(diff / 86400)} дн. назад`;
    
    return then.toLocaleDateString('ru-RU');
}

/**
 * Debounce функция
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Throttle функция
 */
function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

/**
 * Генерация случайного числа в диапазоне
 */
function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Глубокое клонирование объекта
 */
function deepClone(obj) {
    return JSON.parse(JSON.stringify(obj));
}

/**
 * Проверка на пустой объект
 */
function isEmpty(obj) {
    return Object.keys(obj).length === 0;
}

/**
 * Безопасное получение свойства из объекта
 */
function get(obj, path, defaultValue = undefined) {
    const keys = path.split('.');
    let result = obj;
    
    for (const key of keys) {
        if (result === null || result === undefined) {
            return defaultValue;
        }
        result = result[key];
    }
    
    return result !== undefined ? result : defaultValue;
}

/**
 * Склонение слов (1 бой, 2 боя, 5 боёв)
 */
function declension(number, titles) {
    const cases = [2, 0, 1, 1, 1, 2];
    return titles[(number % 100 > 4 && number % 100 < 20) ? 2 : cases[(number % 10 < 5) ? number % 10 : 5]];
}

/**
 * Загрузка данных из localStorage с парсингом
 */
function loadFromStorage(key, defaultValue = null) {
    try {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : defaultValue;
    } catch (e) {
        console.error('Error loading from storage:', e);
        return defaultValue;
    }
}

/**
 * Сохранение данных в localStorage
 */
function saveToStorage(key, value) {
    try {
        localStorage.setItem(key, JSON.stringify(value));
        return true;
    } catch (e) {
        console.error('Error saving to storage:', e);
        return false;
    }
}

/**
 * URL параметр
 */
function getUrlParam(name, defaultValue = null) {
    const params = new URLSearchParams(window.location.search);
    return params.get(name) || defaultValue;
}

/**
 * Проверка на мобильное устройство
 */
function isMobile() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

/**
 * Копирование в буфер обмена
 */
async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        return true;
    } catch (e) {
        // Fallback для старых браузеров
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        try {
            document.execCommand('copy');
            return true;
        } catch (e) {
            return false;
        } finally {
            document.body.removeChild(textarea);
        }
    }
}

/**
 * Sleep (задержка)
 */
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Обещание с таймаутом
 */
function withTimeout(promise, ms) {
    return Promise.race([
        promise,
        new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Timeout')), ms)
        )
    ]);
}

/**
 * Группировка массива по ключу
 */
function groupBy(array, key) {
    return array.reduce((result, item) => {
        const group = item[key];
        if (!result[group]) {
            result[group] = [];
        }
        result[group].push(item);
        return result;
    }, {});
}

/**
 * Уникализация массива
 */
function unique(array) {
    return [...new Set(array)];
}

/**
 * Сумма значений массива
 */
function sum(array, key = null) {
    if (key) {
        return array.reduce((acc, item) => acc + (item[key] || 0), 0);
    }
    return array.reduce((acc, num) => acc + num, 0);
}

/**
 * Среднее значение
 */
function average(array, key = null) {
    const total = sum(array, key);
    return array.length > 0 ? total / array.length : 0;
}

/**
 * Максимальное значение
 */
function max(array, key = null) {
    if (array.length === 0) return 0;
    if (key) {
        return Math.max(...array.map(item => item[key] || 0));
    }
    return Math.max(...array);
}

/**
 * Минимальное значение
 */
function min(array, key = null) {
    if (array.length === 0) return 0;
    if (key) {
        return Math.min(...array.map(item => item[key] || 0));
    }
    return Math.min(...array);
}

/**
 * Проверка на онлайн
 */
function isOnline() {
    return navigator.onLine;
}

/**
 * Получение хэша строки
 */
function hashCode(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
    }
    return hash;
}

/**
 * Случайный элемент массива
 */
function randomElement(array) {
    return array[Math.floor(Math.random() * array.length)];
}

/**
 * Перемешивание массива (Fisher-Yates)
 */
function shuffle(array) {
    const result = [...array];
    for (let i = result.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
}

/**
 * Обрезка строки с многоточием
 */
function truncate(str, length, suffix = '...') {
    if (str.length <= length) return str;
    return str.slice(0, length - suffix.length) + suffix;
}

/**
 * Экранирование HTML
 */
function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

/**
 * Форматирование байт в человекочитаемый вид
 */
function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Б';
    
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ'];
    
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

// Экспорт для использования в других модулях
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        formatNumber,
        formatTime,
        timeAgo,
        debounce,
        throttle,
        randomInt,
        deepClone,
        isEmpty,
        get,
        declension,
        loadFromStorage,
        saveToStorage,
        getUrlParam,
        isMobile,
        copyToClipboard,
        sleep,
        withTimeout,
        groupBy,
        unique,
        sum,
        average,
        max,
        min,
        isOnline,
        hashCode,
        randomElement,
        shuffle,
        truncate,
        escapeHtml,
        formatBytes
    };
}
