/**
 * СКИФЫ - UI компоненты
 * Интерактивные элементы интерфейса
 */

'use strict';

const UI = {
    /**
     * Инициализация компонентов
     */
    init() {
        this.initMobileMenu();
        this.initTabs();
        this.initModals();
        this.initTooltips();
        this.initAlerts();
        this.initConfirmations();
        this.initProgressBars();
        this.initCountdowns();
    },
    
    // ============================================================
    // МОБИЛЬНОЕ МЕНЮ
    // ============================================================
    
    initMobileMenu() {
        const menuBtn = document.querySelector('.mobile-menu-btn');
        const mobileMenu = document.querySelector('.mobile-menu');
        
        if (!menuBtn || !mobileMenu) return;
        
        menuBtn.addEventListener('click', () => {
            mobileMenu.classList.toggle('active');
            document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : '';
        });
        
        // Закрытие по клику вне меню
        document.addEventListener('click', (e) => {
            if (mobileMenu.classList.contains('active') && 
                !mobileMenu.contains(e.target) && 
                !menuBtn.contains(e.target)) {
                mobileMenu.classList.remove('active');
                document.body.style.overflow = '';
            }
        });
        
        // Закрытие по кнопке
        const closeBtn = mobileMenu.querySelector('.mobile-menu-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                mobileMenu.classList.remove('active');
                document.body.style.overflow = '';
            });
        }
    },
    
    // ============================================================
    // ВКЛАДКИ (TABS)
    // ============================================================
    
    initTabs() {
        document.querySelectorAll('.tabs').forEach(tabsContainer => {
            const tabs = tabsContainer.querySelectorAll('.tab');
            
            tabs.forEach(tab => {
                tab.addEventListener('click', () => {
                    const target = tab.dataset.tab;
                    
                    // Деактивируем все табы
                    tabs.forEach(t => t.classList.remove('active'));
                    tab.classList.add('active');
                    
                    // Скрываем все контенты
                    document.querySelectorAll('.tab-content').forEach(content => {
                        content.classList.remove('active');
                    });
                    
                    // Показываем нужный контент
                    if (target) {
                        const targetContent = document.getElementById(target);
                        if (targetContent) {
                            targetContent.classList.add('active');
                        }
                    }
                    
                    // Событие
                    tabsContainer.dispatchEvent(new CustomEvent('tabChange', {
                        detail: { tab, target }
                    }));
                });
            });
        });
    },
    
    // ============================================================
    // МОДАЛЬНЫЕ ОКНА
    // ============================================================
    
    modals: {},
    
    initModals() {
        // Авто-инициализация модальных окон по data-атрибутам
        document.querySelectorAll('[data-modal-open]').forEach(trigger => {
            const modalId = trigger.dataset.modalOpen;
            const modal = document.getElementById(modalId);
            
            if (modal) {
                trigger.addEventListener('click', () => this.modal.open(modalId));
            }
        });
        
        // Закрытие по кнопке
        document.querySelectorAll('.modal-close, [data-modal-close]').forEach(closeBtn => {
            closeBtn.addEventListener('click', () => {
                const modal = closeBtn.closest('.modal-overlay');
                if (modal) {
                    this.modal.close(modal.id);
                }
            });
        });
        
        // Закрытие по клику вне модального окна
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    this.modal.close(overlay.id);
                }
            });
        });
        
        // Закрытие по Escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const activeModal = document.querySelector('.modal-overlay.active');
                if (activeModal) {
                    this.modal.close(activeModal.id);
                }
            }
        });
    },
    
    modal: {
        open(modalId) {
            const modal = document.getElementById(modalId);
            if (!modal) return;
            
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
            
            // Фокус на первый input
            const firstInput = modal.querySelector('input, select, textarea');
            if (firstInput) {
                setTimeout(() => firstInput.focus(), 100);
            }
        },
        
        close(modalId) {
            const modal = document.getElementById(modalId);
            if (!modal) return;
            
            modal.classList.remove('active');
            document.body.style.overflow = '';
        },
        
        closeAll() {
            document.querySelectorAll('.modal-overlay.active').forEach(modal => {
                modal.classList.remove('active');
            });
            document.body.style.overflow = '';
        }
    },
    
    // ============================================================
    // ПОДСКАЗКИ (TOOLTIPS)
    // ============================================================
    
    initTooltips() {
        // Создаём контейнер для тултипов
        let tooltipContainer = document.querySelector('.tooltip-container');
        if (!tooltipContainer) {
            tooltipContainer = document.createElement('div');
            tooltipContainer.className = 'tooltip-container';
            document.body.appendChild(tooltipContainer);
        }
        
        document.querySelectorAll('[data-tooltip]').forEach(element => {
            element.addEventListener('mouseenter', (e) => {
                const content = element.dataset.tooltip;
                const position = element.dataset.tooltipPosition || 'top';
                
                const tooltip = document.createElement('div');
                tooltip.className = `tooltip tooltip-${position}`;
                tooltip.innerHTML = content;
                
                tooltipContainer.appendChild(tooltip);
                
                const rect = element.getBoundingClientRect();
                const tooltipRect = tooltip.getBoundingClientRect();
                
                let top, left;
                
                switch (position) {
                    case 'top':
                        top = rect.top - tooltipRect.height - 10;
                        left = rect.left + rect.width / 2 - tooltipRect.width / 2;
                        break;
                    case 'bottom':
                        top = rect.bottom + 10;
                        left = rect.left + rect.width / 2 - tooltipRect.width / 2;
                        break;
                    case 'left':
                        top = rect.top + rect.height / 2 - tooltipRect.height / 2;
                        left = rect.left - tooltipRect.width - 10;
                        break;
                    case 'right':
                        top = rect.top + rect.height / 2 - tooltipRect.height / 2;
                        left = rect.right + 10;
                        break;
                }
                
                tooltip.style.top = `${top}px`;
                tooltip.style.left = `${left}px`;
                
                element._tooltip = tooltip;
            });
            
            element.addEventListener('mouseleave', () => {
                if (element._tooltip) {
                    element._tooltip.remove();
                    element._tooltip = null;
                }
            });
        });
    },
    
    // ============================================================
    // УВЕДОМЛЕНИЯ (ALERTS)
    // ============================================================
    
    initAlerts() {
        // Авто-закрытие алертов
        document.querySelectorAll('.alert[data-auto-close]').forEach(alert => {
            const timeout = parseInt(alert.dataset.autoClose) || 5000;
            
            setTimeout(() => {
                this.alert.close(alert);
            }, timeout);
        });
        
        // Кнопки закрытия
        document.querySelectorAll('.alert-close').forEach(btn => {
            btn.addEventListener('click', () => {
                this.alert.close(btn.closest('.alert'));
            });
        });
    },
    
    alert: {
        show(message, type = 'info', duration = 5000) {
            const alert = document.createElement('div');
            alert.className = `alert alert-${type}`;
            alert.setAttribute('data-auto-close', duration);
            
            const icons = {
                success: '✅',
                error: '⚠️',
                info: 'ℹ️',
                warning: '⚠️'
            };
            
            alert.innerHTML = `
                <span class="alert-icon">${icons[type] || icons.info}</span>
                <span class="alert-text">${message}</span>
                <button class="alert-close">✕</button>
            `;
            
            const container = document.querySelector('.alert-container') || document.querySelector('.game-content .container');
            if (container) {
                container.insertBefore(alert, container.firstChild);
                
                // Инициализируем закрытие
                setTimeout(() => {
                    UI.alert.close(alert);
                }, duration);
            }
            
            return alert;
        },
        
        close(alert) {
            if (!alert) return;
            
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-10px)';
            
            setTimeout(() => {
                alert.remove();
            }, 300);
        }
    },
    
    // ============================================================
    // ПОДТВЕРЖДЕНИЕ ДЕЙСТВИЙ
    // ============================================================
    
    initConfirmations() {
        document.querySelectorAll('[data-confirm]').forEach(element => {
            element.addEventListener('click', (e) => {
                const message = element.dataset.confirm || 'Вы уверены?';
                
                if (!confirm(message)) {
                    e.preventDefault();
                    e.stopPropagation();
                }
            });
        });
    },
    
    /**
     * Показать диалог подтверждения
     */
    async confirm(message, options = {}) {
        return new Promise((resolve) => {
            const modal = document.createElement('div');
            modal.className = 'modal-overlay';
            modal.id = 'confirm-modal-' + Date.now();
            
            modal.innerHTML = `
                <div class="modal">
                    <div class="modal-header">
                        <h3 class="modal-title">${options.title || 'Подтверждение'}</h3>
                    </div>
                    <div class="modal-body">
                        <p>${message}</p>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" data-action="cancel">${options.cancelText || 'Отмена'}</button>
                        <button class="btn btn-${options.type || 'danger'}" data-action="confirm">${options.confirmText || 'OK'}</button>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            
            setTimeout(() => modal.classList.add('active'), 10);
            
            const cleanup = () => {
                modal.classList.remove('active');
                setTimeout(() => modal.remove(), 300);
            };
            
            modal.querySelector('[data-action="cancel"]').addEventListener('click', () => {
                cleanup();
                resolve(false);
            });
            
            modal.querySelector('[data-action="confirm"]').addEventListener('click', () => {
                cleanup();
                resolve(true);
            });
            
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    cleanup();
                    resolve(false);
                }
            });
        });
    },
    
    // ============================================================
    // ПРОГРЕСС БАРЫ
    // ============================================================
    
    initProgressBars() {
        // Анимация прогресс баров при появлении
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const progressBar = entry.target.querySelector('.progress-bar');
                    if (progressBar) {
                        const width = progressBar.style.width;
                        progressBar.style.width = '0';
                        setTimeout(() => {
                            progressBar.style.width = width || '0';
                        }, 100);
                    }
                }
            });
        }, { threshold: 0.1 });
        
        document.querySelectorAll('.progress').forEach(progress => {
            observer.observe(progress);
        });
    },
    
    /**
     * Обновить прогресс бар
     */
    updateProgress(selector, value, max = 100) {
        const progress = document.querySelector(selector);
        if (!progress) return;
        
        const percent = Math.min(100, Math.max(0, (value / max) * 100));
        const progressBar = progress.querySelector('.progress-bar');
        
        if (progressBar) {
            progressBar.style.width = `${percent}%`;
            
            // Обновляем текст
            const text = progressBar.dataset.text || '{value}/{max}';
            progressBar.textContent = text
                .replace('{value}', value)
                .replace('{max}', max)
                .replace('{percent}', Math.round(percent));
        }
    },
    
    // ============================================================
    // ТАЙМЕРЫ ОБРАТНОГО ОТСЧЁТА
    // ============================================================
    
    countdowns: [],
    
    initCountdowns() {
        document.querySelectorAll('[data-countdown]').forEach(element => {
            const targetTime = element.dataset.countdown;
            
            if (targetTime) {
                this.countdowns.push({
                    element,
                    targetTime: new Date(targetTime).getTime()
                });
            }
        });
        
        // Запускаем обновление таймеров
        if (this.countdowns.length > 0) {
            this.updateCountdowns();
        }
    },
    
    updateCountdowns() {
        const now = Date.now();
        
        this.countdowns.forEach(({ element, targetTime }) => {
            const diff = targetTime - now;
            
            if (diff <= 0) {
                element.textContent = '00:00:00';
                element.classList.add('expired');
                
                // Событие окончания
                element.dispatchEvent(new CustomEvent('countdownEnd'));
            } else {
                element.textContent = formatTime(Math.floor(diff / 1000));
                element.classList.remove('expired');
            }
        });
        
        // Продолжаем обновление
        setTimeout(() => this.updateCountdowns(), 1000);
    },
    
    // ============================================================
    // СПИННЕРЫ / ЗАГРУЗКА
    // ============================================================
    
    showLoading(container) {
        const spinner = document.createElement('div');
        spinner.className = 'loading-spinner';
        spinner.innerHTML = '<div class="spinner"></div>';
        
        container.style.position = 'relative';
        container.appendChild(spinner);
        
        return spinner;
    },
    
    hideLoading(spinner) {
        if (spinner) {
            spinner.remove();
        }
    },
    
    // ============================================================
    // TOAST УВЕДОМЛЕНИЯ
    // ============================================================
    
    toast(message, type = 'info', duration = 3000) {
        const container = document.querySelector('.toast-container') || (() => {
            const c = document.createElement('div');
            c.className = 'toast-container';
            document.body.appendChild(c);
            return c;
        })();
        
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        
        const icons = {
            success: '✅',
            error: '❌',
            info: 'ℹ️',
            warning: '⚠️'
        };
        
        toast.innerHTML = `
            <span class="toast-icon">${icons[type] || icons.info}</span>
            <span class="toast-message">${message}</span>
        `;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(100%)';
            setTimeout(() => toast.remove(), 300);
        }, duration);
        
        return toast;
    }
};

// Инициализация после загрузки DOM
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => UI.init());
} else {
    UI.init();
}

// Экспорт
window.UI = UI;
