<?php
/**
 * СКИФЫ - Главный входной файл
 * Точка входа для всех запросов
 */

declare(strict_types=1);

// Подключение конфига
require_once __DIR__ . '/../config/config.php';

use App\Core\Auth;
use App\Core\Database;

// ============================================================
// МАРШРУТИЗАЦИЯ
// ============================================================

$requestUri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$path = trim($requestUri, '/');

// Убираем префиксы (public, skifs и т.д.)
$prefixes = ['public', 'skifs'];
foreach ($prefixes as $prefix) {
    if (strpos($path, $prefix . '/') === 0) {
        $path = substr($path, strlen($prefix) + 1);
    }
}

$segments = $path ? explode('/', $path) : [''];
$controller = $segments[0] ?: 'home';
$action = $segments[1] ?? 'index';
$params = array_slice($segments, 2);

// ============================================================
// МАРШРУТЫ
// ============================================================

$publicRoutes = ['home', 'auth', 'api'];
$authRoutes = ['profile', 'training', 'battle', 'pvp', 'clan', 'inventory', 'quest', 'amulet', 'shop', 'leaderboard', 'settings'];
$adminRoutes = ['admin'];

$isAdmin = in_array($controller, $adminRoutes);
$isAuth = in_array($controller, $authRoutes);

// ============================================================
// ИНИЦИАЛИЗАЦИЯ
// ============================================================

$auth = new Auth();
$db = Database::getInstance();

// ============================================================
// ПРОВЕРКА ПРАВ
// ============================================================

if ($isAdmin) {
    $auth->requireAdmin();
} elseif ($isAuth && $controller !== 'api') {
    $auth->requireAuth();
}

// ============================================================
// ЗАГРУЗКА КОНТРОЛЛЕРА
// ============================================================

$controllerName = ucfirst(strtolower($controller)) . 'Controller';
$controllerFile = SRC_PATH . '/Controllers/' . $controllerName . '.php';

if (file_exists($controllerFile)) {
    $controllerClass = 'App\\Controllers\\' . $controllerName;
    
    if (class_exists($controllerClass)) {
        $controllerInstance = new $controllerClass($auth, $db);
        
        if (method_exists($controllerInstance, $action . 'Action')) {
            call_user_func_array([$controllerInstance, $action . 'Action'], $params);
            exit;
        }
    }
}

// ============================================================
// 404
// ============================================================

http_response_code(404);

if (is_ajax_request()) {
    json_response(['error' => 'Страница не найдена', 'code' => 'NOT_FOUND'], 404);
}

require_once \TEMPLATE_PATH . '/errors/404.php';
