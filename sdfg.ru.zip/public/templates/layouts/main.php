<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#1a1a2e">
    <title><?= e($title ?? 'СКИФЫ') ?></title>
    
    <style>
        /* ============================================================
           БАЗА - МОБИЛЬНЫЙ СТИЛЬ 9:16
           ============================================================ */
        * { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }
        
        html, body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(180deg, #1a1a2e 0%, #0f0f1a 100%);
            color: #e8e8e8;
            min-height: 100vh;
            font-size: 14px;
        }
        
        a { color: #c9a962; text-decoration: none; }
        button { cursor: pointer; font-family: inherit; border: none; background: none; }
        input, select, textarea { font-family: inherit; font-size: inherit; }
        
        /* ============================================================
           ВЕРХНЯЯ ПАНЕЛЬ
           ============================================================ */
        .top-bar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 50px;
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
            border-bottom: 1px solid #2d2d44;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 15px;
            z-index: 1000;
        }
        
        .top-bar .logo {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 1.1rem;
            font-weight: bold;
            color: #c9a962;
        }
        
        .logo-icon { font-size: 1.5rem; }
        
        .player-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .player-avatar {
            width: 32px;
            height: 32px;
            background: #2d2d44;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
        }
        
        .player-name { font-size: 0.85rem; color: #a0a0a0; }
        
        /* ============================================================
           ПАНЕЛЬ РЕСУРСОВ
           ============================================================ */
        .resources-bar {
            position: fixed;
            top: 50px;
            left: 0;
            right: 0;
            height: 45px;
            background: #16213e;
            border-bottom: 1px solid #2d2d44;
            display: flex;
            align-items: center;
            justify-content: space-around;
            padding: 5px 10px;
            z-index: 999;
        }
        
        .resource {
            display: flex;
            align-items: center;
            gap: 5px;
            padding: 5px 10px;
            background: #1f2940;
            border-radius: 6px;
            min-width: 70px;
        }
        
        .resource-icon { font-size: 1rem; }
        .resource-value { font-weight: bold; font-size: 0.85rem; }
        .resource.bronze .resource-value { color: #cd7f32; }
        .resource.gold .resource-value { color: #ffd700; }
        
        /* ============================================================
           КОНТЕНТ
           ============================================================ */
        .main-content {
            margin-top: 95px;
            padding: 15px;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
            padding-bottom: 80px;
        }
        
        .card {
            background: #16213e;
            border: 1px solid #2d2d44;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
        }
        
        .card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 12px;
            padding-bottom: 12px;
            border-bottom: 1px solid #2d2d44;
        }
        
        .card-title {
            font-size: 1rem;
            color: #c9a962;
            font-weight: bold;
        }
        
        /* ============================================================
           НИЖНЕЕ МЕНЮ
           ============================================================ */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            height: 60px;
            background: linear-gradient(0deg, #1a1a2e 0%, #16213e 100%);
            border-top: 1px solid #2d2d44;
            display: flex;
            z-index: 1000;
        }
        
        .nav-item {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 3px;
            color: #6c757d;
            font-size: 0.7rem;
        }
        
        .nav-item.active { color: #c9a962; }
        .nav-icon { font-size: 1.3rem; }
        
        /* ============================================================
           КНОПКИ
           ============================================================ */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: bold;
            font-size: 0.9rem;
            transition: transform 0.2s;
        }
        
        .btn:active { transform: scale(0.98); }
        
        .btn-primary {
            background: linear-gradient(180deg, #c9a962 0%, #a08840 100%);
            color: #0f0f1a;
        }
        
        .btn-secondary {
            background: #1f2940;
            color: #e8e8e8;
            border: 1px solid #2d2d44;
        }
        
        .btn-block { width: 100%; }
        
        /* ============================================================
           ФОРМЫ
           ============================================================ */
        .form-group { margin-bottom: 15px; }
        
        .form-label {
            display: block;
            margin-bottom: 6px;
            color: #a0a0a0;
            font-size: 0.85rem;
            font-weight: bold;
        }
        
        .form-input {
            width: 100%;
            padding: 12px;
            background: #1f2940;
            border: 1px solid #2d2d44;
            border-radius: 8px;
            color: #e8e8e8;
            font-size: 1rem;
        }
        
        .form-input:focus {
            outline: none;
            border-color: #c9a962;
        }
        
        /* ============================================================
           ПРОГРЕСС БАРЫ
           ============================================================ */
        .progress {
            background: #1f2940;
            border-radius: 10px;
            overflow: hidden;
            height: 18px;
            border: 1px solid #2d2d44;
        }
        
        .progress-bar {
            height: 100%;
            background: linear-gradient(90deg, #c9a962 0%, #a08840 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            font-weight: bold;
            color: #0f0f1a;
        }
        
        .progress-bar.hp { 
            background: linear-gradient(90deg, #28a745 0%, #1e7e34 100%); 
            color: white; 
        }
        
        .progress-bar.exp { 
            background: linear-gradient(90deg, #6f42c1 0%, #563d7c 100%); 
            color: white; 
        }
        
        /* ============================================================
           АЛЕРТЫ
           ============================================================ */
        .alert {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 0.85rem;
        }
        
        .alert-error {
            background: rgba(220, 53, 69, 0.2);
            border: 1px solid #dc3545;
            color: #ff6b6b;
        }
        
        .alert-success {
            background: rgba(40, 167, 69, 0.2);
            border: 1px solid #28a745;
            color: #5cd65c;
        }
        
        /* ============================================================
           УТИЛИТЫ
           ============================================================ */
        .text-center { text-align: center; }
        .text-gold { color: #c9a962; }
        .text-green { color: #28a745; }
        .text-red { color: #dc3545; }
        .text-muted { color: #6c757d; }
        
        .mt-1 { margin-top: 10px; }
        .mt-2 { margin-top: 15px; }
        .mb-1 { margin-bottom: 10px; }
        .mb-2 { margin-bottom: 15px; }
        
        .d-flex { display: flex; }
        .gap-1 { gap: 10px; }
        .gap-2 { gap: 15px; }
        .justify-between { justify-content: space-between; }
        .align-center { align-items: center; }
        
        /* Статы */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
        }
        
        .stat-item {
            background: #1f2940;
            border-radius: 8px;
            padding: 12px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .stat-icon { font-size: 1.5rem; }
        .stat-info { flex: 1; }
        .stat-name { font-size: 0.75rem; color: #a0a0a0; }
        .stat-value { font-size: 1.1rem; font-weight: bold; color: #c9a962; }
        
        /* Действия */
        .actions-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
        }
        
        .action-btn {
            background: #1f2940;
            border: 1px solid #2d2d44;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            color: #e8e8e8;
        }
        
        .action-btn:active { background: #2d2d44; }
        .action-icon { font-size: 2rem; display: block; margin-bottom: 8px; }
        .action-btn span { font-size: 0.85rem; font-weight: bold; }
        
        /* Ресурсы список */
        .resource-list {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .resource-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 0;
            border-bottom: 1px solid #2d2d44;
        }
        
        .resource-item:last-child { border-bottom: none; }
        .resource-label { color: #a0a0a0; font-size: 0.9rem; }
        .resource-value { font-weight: bold; }
        .resource-value.bronze { color: #cd7f32; }
        .resource-value.gold { color: #ffd700; }
    </style>
</head>
<body>
    <?php if (!empty($this->userId)): ?>
    <!-- Верхняя панель -->
    <div class="top-bar">
        <a href="<?= BASE_URL ?>/" class="logo">
            <span class="logo-icon">⚔️</span>
            <span>СКИФЫ</span>
        </a>
        <div class="player-info">
            <div class="player-avatar">🗡️</div>
            <span class="player-name"><?= e($this->user['username'] ?? 'Герой') ?></span>
        </div>
    </div>

    <!-- Ресурсы -->
    <div class="resources-bar">
        <div class="resource bronze">
            <span class="resource-icon">🥉</span>
            <span class="resource-value"><?= number_format($this->user['bronze'] ?? 100) ?></span>
        </div>
        <div class="resource gold">
            <span class="resource-icon">🥇</span>
            <span class="resource-value"><?= number_format($this->user['gold'] ?? 10) ?></span>
        </div>
    </div>
    <?php endif; ?>

    <!-- Основной контент -->
    <main class="main-content">
        <?php if (isset($error) && $error): ?>
        <div class="alert alert-error">⚠️ <?= e($error) ?></div>
        <?php endif; ?>
        
        <?php if (isset($success) && $success): ?>
        <div class="alert alert-success">✅ <?= e($success) ?></div>
        <?php endif; ?>
        
        <?= $content ?? '' ?>
    </main>

    <?php if (!empty($this->userId)): ?>
    <!-- Нижнее меню -->
    <nav class="bottom-nav">
        <a href="<?= BASE_URL ?>/profile" class="nav-item <?= ($controller ?? '') === 'profile' ? 'active' : '' ?>">
            <span class="nav-icon">👤</span>
            <span>Герой</span>
        </a>
        <a href="<?= BASE_URL ?>/training" class="nav-item <?= ($controller ?? '') === 'training' ? 'active' : '' ?>">
            <span class="nav-icon">💪</span>
            <span>Тренировка</span>
        </a>
        <a href="<?= BASE_URL ?>/battle" class="nav-item <?= ($controller ?? '') === 'battle' ? 'active' : '' ?>">
            <span class="nav-icon">⚔️</span>
            <span>Бой</span>
        </a>
        <a href="<?= BASE_URL ?>/inventory" class="nav-item <?= ($controller ?? '') === 'inventory' ? 'active' : '' ?>">
            <span class="nav-icon">🎒</span>
            <span>Вещи</span>
        </a>
        <a href="<?= BASE_URL ?>/clan" class="nav-item <?= ($controller ?? '') === 'clan' ? 'active' : '' ?>">
            <span class="nav-icon">🏕️</span>
            <span>Племя</span>
        </a>
    </nav>
    <?php endif; ?>

    <!-- Скрипты -->
    <script>
        window.csrfToken = '<?= generate_csrf_token() ?>';
        window.BASE_URL = '<?= BASE_URL ?>';
        <?php if (!empty($this->userId)): ?>
        window.USER_ID = <?= $this->userId ?>;
        <?php endif; ?>
    </script>
</body>
</html>
