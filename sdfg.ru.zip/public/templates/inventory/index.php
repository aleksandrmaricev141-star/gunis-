<?php
/**
 * Шаблон: Инвентарь
 * Мобильный стиль 9:16
 */

$equipment = $equipment ?? [];
$items = $items ?? [];
?>

<!-- Экипировка -->
<div class="card">
    <div class="card-header">
        <span class="card-title">🎒 Экипировка</span>
    </div>
    
    <div class="equip-grid">
        <?php
        $slots = [
            1 => ['name' => 'Копьё', 'icon' => '🗡️'],
            2 => ['name' => 'Акинак', 'icon' => '🗡️'],
            3 => ['name' => 'Лук', 'icon' => '🏹'],
            4 => ['name' => 'Шлем', 'icon' => '🪖'],
            5 => ['name' => 'Панцирь', 'icon' => '👕'],
            6 => ['name' => 'Сапоги', 'icon' => '👢'],
        ];
        ?>
        <?php foreach ($slots as $slotId => $slotData): 
            $item = null;
            foreach ($equipment as $eq) {
                if ($eq['slot'] == $slotId) {
                    $item = $eq;
                    break;
                }
            }
        ?>
        <div class="equip-slot <?= $item ? 'filled' : 'empty' ?>">
            <div class="equip-icon"><?= $slotData['icon'] ?></div>
            <div class="equip-name"><?= $item ? e($item['name']) : $slotData['name'] ?></div>
            <?php if ($item && isset($item['upgrade_level']) && $item['upgrade_level'] > 0): ?>
            <div class="equip-level">+<?= $item['upgrade_level'] ?></div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Рюкзак -->
<div class="card">
    <div class="card-header">
        <span class="card-title">📦 Рюкзак</span>
    </div>
    
    <?php if (empty($items)): ?>
    <p class="text-muted text-center">Пусто...</p>
    <?php else: ?>
    <div class="items-list">
        <?php foreach ($items as $item): ?>
        <div class="item-card">
            <div class="item-icon"><?= $item['icon'] ?? '📦' ?></div>
            <div class="item-info">
                <div class="item-name"><?= e($item['name']) ?></div>
                <div class="item-type"><?= e($item['type']) ?></div>
            </div>
            <div class="item-actions">
                <button class="btn-sm btn-secondary">Надеть</button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<style>
.equip-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 8px;
}

.equip-slot {
    aspect-ratio: 1;
    background: #1f2940;
    border: 2px dashed #2d2d44;
    border-radius: 8px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 8px;
    text-align: center;
    position: relative;
}

.equip-slot.filled {
    border-style: solid;
    border-color: #c9a962;
}

.equip-icon {
    font-size: 1.5rem;
    margin-bottom: 5px;
}

.equip-name {
    font-size: 0.65rem;
    color: #a0a0a0;
}

.equip-level {
    position: absolute;
    bottom: 5px;
    right: 5px;
    font-size: 0.7rem;
    font-weight: bold;
    color: #c9a962;
}

/* Предметы */
.items-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.item-card {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    background: #1f2940;
    border-radius: 8px;
}

.item-icon {
    font-size: 2rem;
}

.item-info {
    flex: 1;
}

.item-name {
    font-weight: bold;
    color: #e8e8e8;
    margin-bottom: 3px;
}

.item-type {
    font-size: 0.75rem;
    color: #a0a0a0;
}

.btn-sm {
    padding: 6px 12px;
    font-size: 0.8rem;
}
</style>
