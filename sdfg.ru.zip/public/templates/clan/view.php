<?php
/**
 * Шаблон: Просмотр клана
 * Мобильный стиль 9:16
 */

$clan = $clan ?? [];
?>

<div class="my-clan-page">
    <!-- Инфо о клане -->
    <div class="card clan-card">
        <div class="clan-header">
            <div class="clan-icon">🏕️</div>
            <div class="clan-info">
                <h1 class="clan-name">
                    <?= e($clan['name']) ?>
                    <?php if ($clan['tag']): ?>
                    <span class="clan-tag">[<?= e($clan['tag']) ?>]</span>
                    <?php endif; ?>
                </h1>
                <div class="clan-meta">
                    Ур. <?= $clan['level'] ?> | Роль: <?= e($clan['role']) ?>
                </div>
            </div>
        </div>
        
        <?php if ($clan['description']): ?>
        <p class="clan-desc"><?= e($clan['description']) ?></p>
        <?php endif; ?>
    </div>

    <!-- Действия -->
    <div class="card">
        <div class="card-header">
            <span class="card-title">⚙️ Действия</span>
        </div>
        
        <div class="actions-list">
            <a href="#" class="action-item">
                <span class="action-icon">📋</span>
                <span>Состав племени</span>
            </a>
            <a href="#" class="action-item">
                <span class="action-icon">📊</span>
                <span>Казна</span>
            </a>
            <a href="#" class="action-item">
                <span class="action-icon">🏗️</span>
                <span>Здания</span>
            </a>
            <a href="#" class="action-item">
                <span class="action-icon">💰</span>
                <span>Пожертвовать</span>
            </a>
        </div>
    </div>

    <!-- Выход из клана -->
    <div class="card">
        <button class="btn-leave" onclick="leaveClan()">
            🚪 Покинуть племя
        </button>
    </div>
</div>

<style>
.my-clan-page {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.clan-card {
    text-align: center;
}

.clan-header {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 15px;
}

.clan-icon {
    font-size: 3rem;
}

.clan-info {
    flex: 1;
    text-align: left;
}

.clan-name {
    font-size: 1.3rem;
    color: #c9a962;
    margin-bottom: 5px;
}

.clan-tag {
    color: #a0a0a0;
    font-size: 0.9rem;
}

.clan-meta {
    font-size: 0.85rem;
    color: #a0a0a0;
}

.clan-desc {
    color: #a0a0a0;
    line-height: 1.6;
}

.actions-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.action-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    background: #1f2940;
    border-radius: 8px;
    color: #e8e8e8;
}

.action-icon {
    font-size: 1.5rem;
}

.btn-leave {
    width: 100%;
    background: #1f2940;
    color: #ff6b6b;
    border: 1px solid #dc3545;
    border-radius: 8px;
    padding: 12px;
    font-weight: bold;
    cursor: pointer;
}

.btn-leave:active {
    background: #dc3545;
    color: white;
}
</style>

<script>
function leaveClan() {
    if (confirm('Вы уверены, что хотите покинуть племя?')) {
        alert('Функционал выхода в разработке');
    }
}
</script>
