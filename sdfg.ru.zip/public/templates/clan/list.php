<?php
/**
 * Шаблон: Список кланов
 * Мобильный стиль 9:16
 */

$clans = $clans ?? [];
?>

<div class="clan-page">
    <!-- Заголовок -->
    <div class="card">
        <div class="card-header">
            <span class="card-title">🏕️ Племена Степи</span>
        </div>
        <p class="text-muted">
            Выберите племя и подайте заявку на вступление
        </p>
        <button class="btn-primary btn-block mt-2" onclick="alert('Создание клана будет доступно позже')">
            🏕️ Создать своё племя (50 🥇)
        </button>
    </div>

    <!-- Список кланов -->
    <?php if (empty($clans)): ?>
    <div class="card">
        <p class="text-muted text-center">Пока нет активных племён...</p>
    </div>
    <?php else: ?>
    <div class="clans-list">
        <?php foreach ($clans as $clan): ?>
        <div class="clan-card">
            <div class="clan-header">
                <div class="clan-rank">#<?= $loop->iteration ?? ($key + 1) ?></div>
                <div class="clan-info">
                    <div class="clan-name">
                        <?= e($clan['name']) ?>
                        <?php if ($clan['tag']): ?>
                        <span class="clan-tag">[<?= e($clan['tag']) ?>]</span>
                        <?php endif; ?>
                    </div>
                    <div class="clan-meta">
                        👥 <?= $clan['member_count'] ?> | Ур. <?= $clan['level'] ?>
                    </div>
                </div>
            </div>
            
            <?php if ($clan['description']): ?>
            <p class="clan-desc"><?= e($clan['description']) ?></p>
            <?php endif; ?>
            
            <div class="clan-footer">
                <span class="clan-leader">Вождь: <?= e($clan['leader_name']) ?></span>
                <button class="btn-join" onclick="applyToClan(<?= $clan['id'] ?>)">
                    Подать заявку
                </button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<style>
.clan-page {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.clans-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.clan-card {
    background: #1f2940;
    border-radius: 8px;
    padding: 15px;
}

.clan-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 10px;
}

.clan-rank {
    font-size: 1.2rem;
    font-weight: bold;
    color: #c9a962;
    min-width: 40px;
}

.clan-info {
    flex: 1;
}

.clan-name {
    font-weight: bold;
    color: #e8e8e8;
    margin-bottom: 3px;
}

.clan-tag {
    color: #a0a0a0;
    font-size: 0.85rem;
}

.clan-meta {
    font-size: 0.75rem;
    color: #a0a0a0;
}

.clan-desc {
    font-size: 0.85rem;
    color: #a0a0a0;
    margin-bottom: 12px;
    line-height: 1.5;
}

.clan-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.clan-leader {
    font-size: 0.85rem;
    color: #a0a0a0;
}

.btn-join {
    background: linear-gradient(180deg, #c9a962 0%, #a08840 100%);
    color: #0f0f1a;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-weight: bold;
    font-size: 0.85rem;
    cursor: pointer;
}

.btn-join:active {
    transform: scale(0.98);
}
</style>

<script>
async function applyToClan(clanId) {
    const message = prompt('Сообщение лидеру (необязательно):', '');
    
    // Здесь будет API вызов
    alert('Заявка отправлена! (функционал в разработке)');
}
</script>
