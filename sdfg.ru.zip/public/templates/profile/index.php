<?php
// Данные по умолчанию если не переданы
$profile = $profile ?? ['username' => 'Герой', 'bronze' => 100, 'gold' => 10];
$stats = $stats ?? [
    'level' => 1, 'experience' => 0, 'experience_to_next' => 100,
    'fury_steppe' => 10, 'blood_nomad' => 100, 'copper_scale' => 5,
    'energy' => 10, 'max_energy' => 10, 'stat_points' => 0,
    'iron_scrap' => 0, 'spirit_tears' => 0, 'shard_skull' => 0
];
$expPercent = $expPercent ?? 0;
?>

<!-- Профиль -->
<div class="card">
    <div class="text-center" style="margin-bottom: 15px;">
        <div style="font-size: 3rem; margin-bottom: 10px;">🗡️</div>
        <h1 style="color: #c9a962; font-size: 1.3rem; margin-bottom: 5px;"><?= e($profile['username']) ?></h1>
        <span style="background: #6f42c1; color: white; padding: 3px 10px; border-radius: 4px; font-size: 0.8rem;">
            Уровень <?= (int)$stats['level'] ?>
        </span>
    </div>
    
    <!-- Опыт -->
    <div style="margin-top: 15px;">
        <div style="display: flex; justify-content: space-between; font-size: 0.8rem; color: #a0a0a0; margin-bottom: 5px;">
            <span>Опыт</span>
            <span><?= (int)$stats['experience'] ?> / <?= (int)$stats['experience_to_next'] ?></span>
        </div>
        <div class="progress">
            <div class="progress-bar exp" style="width: <?= (float)$expPercent ?>%"></div>
        </div>
    </div>
</div>

<!-- Характеристики -->
<div class="card">
    <div class="card-header">
        <span class="card-title">💪 Характеристики</span>
    </div>
    
    <div class="stats-grid">
        <div class="stat-item">
            <div class="stat-icon">⚔️</div>
            <div class="stat-info">
                <div class="stat-name">Ярость</div>
                <div class="stat-value"><?= (int)$stats['fury_steppe'] ?></div>
            </div>
        </div>
        
        <div class="stat-item">
            <div class="stat-icon">❤️</div>
            <div class="stat-info">
                <div class="stat-name">Здоровье</div>
                <div class="stat-value"><?= (int)$stats['blood_nomad'] ?></div>
            </div>
        </div>
        
        <div class="stat-item">
            <div class="stat-icon">🛡️</div>
            <div class="stat-info">
                <div class="stat-name">Броня</div>
                <div class="stat-value"><?= (int)$stats['copper_scale'] ?></div>
            </div>
        </div>
        
        <div class="stat-item">
            <div class="stat-icon">⚡</div>
            <div class="stat-info">
                <div class="stat-name">Энергия</div>
                <div class="stat-value"><?= (int)$stats['energy'] ?>/<?= (int)$stats['max_energy'] ?></div>
            </div>
        </div>
    </div>
</div>

<!-- Действия -->
<div class="card">
    <div class="card-header">
        <span class="card-title">⚔️ Действия</span>
    </div>
    
    <div class="actions-grid">
        <a href="<?= BASE_URL ?>/battle" class="action-btn">
            <span class="action-icon">⚔️</span>
            <span>В бой</span>
        </a>
        <a href="<?= BASE_URL ?>/training" class="action-btn">
            <span class="action-icon">💪</span>
            <span>Тренировка</span>
        </a>
        <a href="<?= BASE_URL ?>/inventory" class="action-btn">
            <span class="action-icon">🎒</span>
            <span>Вещи</span>
        </a>
        <a href="<?= BASE_URL ?>/clan" class="action-btn">
            <span class="action-icon">🏕️</span>
            <span>Племя</span>
        </a>
    </div>
</div>

<!-- Ресурсы -->
<div class="card">
    <div class="card-header">
        <span class="card-title">📊 Ресурсы</span>
    </div>
    
    <div class="resource-list">
        <div class="resource-item">
            <span class="resource-label">🥉 Бронза</span>
            <span class="resource-value bronze"><?= number_format((int)$profile['bronze']) ?></span>
        </div>
        <div class="resource-item">
            <span class="resource-label">🥇 Золото</span>
            <span class="resource-value gold"><?= number_format((int)$profile['gold']) ?></span>
        </div>
        <div class="resource-item">
            <span class="resource-label">⛓️ Лом</span>
            <span class="resource-value"><?= (int)$stats['iron_scrap'] ?></span>
        </div>
        <div class="resource-item">
            <span class="resource-label">💧 Слезы</span>
            <span class="resource-value"><?= (int)$stats['spirit_tears'] ?></span>
        </div>
        <div class="resource-item">
            <span class="resource-label">💀 Черепа</span>
            <span class="resource-value"><?= (int)$stats['shard_skull'] ?></span>
        </div>
    </div>
</div>
