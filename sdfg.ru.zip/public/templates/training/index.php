<?php
/**
 * Шаблон: Тренировка
 * Мобильный стиль 9:16
 */

$stats = $stats ?? [];
$costs = $costs ?? [];
?>

<div class="training-page">
    <!-- Инфо о герое -->
    <div class="card">
        <div class="card-header">
            <span class="card-title">💰 Доступно</span>
        </div>
        <div class="resource-info">
            <div class="resource-row">
                <span class="resource-icon">🥉</span>
                <span class="resource-name">Бронза:</span>
                <span class="resource-value bronze"><?= number_format($stats['bronze'] ?? 0) ?></span>
            </div>
            <div class="resource-row">
                <span class="resource-icon">✨</span>
                <span class="resource-name">Очки статов:</span>
                <span class="resource-value"><?= $stats['stat_points'] ?? 0 ?></span>
            </div>
        </div>
    </div>

    <!-- Характеристики -->
    <div class="card">
        <div class="card-header">
            <span class="card-title">💪 Прокачка характеристик</span>
        </div>

        <!-- Ярость Степи -->
        <div class="train-item">
            <div class="train-header">
                <span class="train-icon">⚔️</span>
                <div class="train-info">
                    <div class="train-name">Ярость Степи</div>
                    <div class="train-desc">+Урон, +Шанс крита</div>
                </div>
                <div class="train-value"><?= $stats['fury_steppe'] ?? 10 ?></div>
            </div>
            <button class="btn-train" onclick="trainStat('fury_steppe', <?= $costs['fury_steppe'] ?? 50 ?>)">
                Прокачать за <?= $costs['fury_steppe'] ?? 50 ?> 🥉
            </button>
        </div>

        <!-- Кровь Кочевника -->
        <div class="train-item">
            <div class="train-header">
                <span class="train-icon">❤️</span>
                <div class="train-info">
                    <div class="train-name">Кровь Кочевника</div>
                    <div class="train-desc">+Макс. HP</div>
                </div>
                <div class="train-value"><?= $stats['blood_nomad'] ?? 100 ?></div>
            </div>
            <button class="btn-train" onclick="trainStat('blood_nomad', <?= $costs['blood_nomad'] ?? 50 ?>)">
                Прокачать за <?= $costs['blood_nomad'] ?? 50 ?> 🥉
            </button>
        </div>

        <!-- Медная Чешуя -->
        <div class="train-item">
            <div class="train-header">
                <span class="train-icon">🛡️</span>
                <div class="train-info">
                    <div class="train-name">Медная Чешуя</div>
                    <div class="train-desc">+Защита</div>
                </div>
                <div class="train-value"><?= $stats['copper_scale'] ?? 5 ?></div>
            </div>
            <button class="btn-train" onclick="trainStat('copper_scale', <?= $costs['copper_scale'] ?? 50 ?>)">
                Прокачать за <?= $costs['copper_scale'] ?? 50 ?> 🥉
            </button>
        </div>
    </div>

    <!-- Информация -->
    <div class="card">
        <div class="card-header">
            <span class="card-title">ℹ️ Информация</span>
        </div>
        <div class="info-text">
            <p>📈 Стоимость прокачки растёт с каждым уровнем.</p>
            <p>💡 Очки статов можно получить за выполнение квестов или с уровнем.</p>
            <p>⚡ Тренировка мгновенная - статы увеличиваются сразу.</p>
        </div>
    </div>
</div>

<style>
.training-page {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.resource-info {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.resource-row {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px;
    background: #1f2940;
    border-radius: 8px;
}

.resource-icon {
    font-size: 1.3rem;
}

.resource-name {
    flex: 1;
    color: #a0a0a0;
}

.resource-value {
    font-weight: bold;
    font-size: 1.1rem;
}

.resource-value.bronze { color: #cd7f32; }

/* Тренировка */
.train-item {
    background: #1f2940;
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 10px;
}

.train-item:last-child {
    margin-bottom: 0;
}

.train-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 12px;
}

.train-icon {
    font-size: 2rem;
}

.train-info {
    flex: 1;
}

.train-name {
    font-weight: bold;
    color: #e8e8e8;
    margin-bottom: 3px;
}

.train-desc {
    font-size: 0.75rem;
    color: #a0a0a0;
}

.train-value {
    font-size: 1.3rem;
    font-weight: bold;
    color: #c9a962;
}

.btn-train {
    width: 100%;
    background: linear-gradient(180deg, #c9a962 0%, #a08840 100%);
    color: #0f0f1a;
    border: none;
    border-radius: 8px;
    padding: 12px;
    font-weight: bold;
    font-size: 0.9rem;
    cursor: pointer;
}

.btn-train:active {
    transform: scale(0.98);
}

.btn-train:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.info-text {
    color: #a0a0a0;
    font-size: 0.85rem;
    line-height: 1.6;
}

.info-text p {
    margin-bottom: 8px;
}

.info-text p:last-child {
    margin-bottom: 0;
}
</style>

<script>
async function trainStat(statType, cost) {
    const names = {
        'fury_steppe': 'Ярость',
        'blood_nomad': 'Здоровье',
        'copper_scale': 'Броня'
    };
    
    if (!confirm('Прокачать ' + names[statType] + ' за ' + cost + ' бронзы?')) return;
    
    try {
        const response = await fetch(window.BASE_URL + '/training/train', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': window.csrfToken
            },
            body: JSON.stringify({ stat_type: statType, amount: 1 })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('✅ ' + names[statType] + ' улучшена!');
            location.reload();
        } else {
            alert('❌ ' + (result.error || 'Ошибка'));
        }
    } catch (error) {
        alert('❌ Ошибка: ' + error.message);
    }
}
</script>
