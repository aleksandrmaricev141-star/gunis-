<!-- Герой -->
<div class="card" style="text-align: center; padding: 30px 20px;">
    <div style="font-size: 5rem; margin-bottom: 15px;">⚔️</div>
    <h1 style="color: #c9a962; font-size: 2rem; margin-bottom: 10px;">СКИФЫ</h1>
    <p style="color: #a0a0a0; font-size: 1.1rem; margin-bottom: 20px;">Браузерная MMO RPG</p>
    <p style="color: #e8e8e8; line-height: 1.6; margin-bottom: 25px;">
        Погрузись в мир скифо-сарматских племён. 
        Прокачивай героя, сражайся, вступи в племя!
    </p>
    
    <div style="display: flex; flex-direction: column; gap: 10px;">
        <a href="<?= BASE_URL ?>/auth/register" class="btn btn-primary btn-block">
            🏹 Начать игру
        </a>
        <a href="<?= BASE_URL ?>/auth/login" class="btn btn-secondary btn-block">
            🔐 Войти
        </a>
    </div>
</div>

<!-- Особенности -->
<div class="card">
    <div class="card-header">
        <span class="card-title">✨ Особенности</span>
    </div>
    
    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
        <div style="text-align: center; padding: 15px; background: #1f2940; border-radius: 8px;">
            <div style="font-size: 2.5rem; margin-bottom: 8px;">⚔️</div>
            <div style="color: #c9a962; font-weight: bold; margin-bottom: 5px;">Битвы</div>
            <div style="font-size: 0.75rem; color: #a0a0a0;">Сражайся в Диком Поле</div>
        </div>
        
        <div style="text-align: center; padding: 15px; background: #1f2940; border-radius: 8px;">
            <div style="font-size: 2.5rem; margin-bottom: 8px;">📈</div>
            <div style="color: #c9a962; font-weight: bold; margin-bottom: 5px;">Прокачка</div>
            <div style="font-size: 0.75rem; color: #a0a0a0;">Развивай героя</div>
        </div>
        
        <div style="text-align: center; padding: 15px; background: #1f2940; border-radius: 8px;">
            <div style="font-size: 2.5rem; margin-bottom: 8px;">🏕️</div>
            <div style="color: #c9a962; font-weight: bold; margin-bottom: 5px;">Племя</div>
            <div style="font-size: 0.75rem; color: #a0a0a0;">Вступай в клан</div>
        </div>
        
        <div style="text-align: center; padding: 15px; background: #1f2940; border-radius: 8px;">
            <div style="font-size: 2.5rem; margin-bottom: 8px;">🗡️</div>
            <div style="color: #c9a962; font-weight: bold; margin-bottom: 5px;">Шмот</div>
            <div style="font-size: 0.75rem; color: #a0a0a0;">Собирай экипировку</div>
        </div>
    </div>
</div>
