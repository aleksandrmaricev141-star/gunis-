<?php
/**
 * Шаблон: Страница регистрации
 */

$this->renderPartial('auth/form', [
    'title' => 'Регистрация нового героя',
    'action' => BASE_URL . '/auth/register',
    'submitText' => 'Создать героя',
    'error' => $error ?? null,
    'csrf_token' => $csrf_token ?? '',
    'showRegister' => false,
    'showReset' => false
]);
