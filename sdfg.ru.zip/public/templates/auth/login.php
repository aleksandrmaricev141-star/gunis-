<?php
/**
 * Шаблон: Страница входа
 */

$this->renderPartial('auth/form', [
    'title' => 'Вход в игру',
    'action' => BASE_URL . '/auth/login',
    'submitText' => 'Войти',
    'error' => $error ?? null,
    'csrf_token' => $csrf_token ?? '',
    'showRegister' => true,
    'showReset' => true
]);
