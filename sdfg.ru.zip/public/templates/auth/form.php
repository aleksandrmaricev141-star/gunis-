<?php
/**
 * Шаблон: Форма авторизации/регистрации
 * Мобильный стиль 9:16
 */

$isRegister = $isRegister ?? false;
?>

<div class="auth-wrapper">
    <div class="auth-box">
        <div class="auth-header">
            <div class="game-logo">⚔️</div>
            <h1 class="auth-title"><?= e($title) ?></h1>
        </div>

        <?php if ($error): ?>
        <div class="error-box">
            ⚠️ <?= e($error) ?>
        </div>
        <?php endif; ?>

        <form method="POST" action="<?= e($action) ?>" class="auth-form">
            <input type="hidden" name="csrf_token" value="<?= e($csrf_token) ?>">

            <?php if ($isRegister): ?>
            <!-- Регистрация -->
            <div class="form-group">
                <label class="form-label">Имя героя</label>
                <input type="text" name="username" class="form-input" 
                       placeholder="Введите имя" required minlength="3" maxlength="50" 
                       autocomplete="username" autofocus>
            </div>

            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-input" 
                       placeholder="Email" required maxlength="100" 
                       autocomplete="email">
            </div>

            <div class="form-group">
                <label class="form-label">Пароль</label>
                <input type="password" name="password" class="form-input" 
                       placeholder="Пароль" required minlength="6" 
                       autocomplete="new-password">
            </div>

            <div class="form-group">
                <label class="form-label">Повторите пароль</label>
                <input type="password" name="password_confirm" class="form-input" 
                       placeholder="Повторите" required minlength="6" 
                       autocomplete="new-password">
            </div>

            <button type="submit" class="btn-submit">
                🏹 Создать героя
            </button>

            <div class="auth-footer">
                Уже есть аккаунт? <a href="<?= BASE_URL ?>/auth/login">Войти</a>
            </div>

            <?php else: ?>
            <!-- Вход -->
            <div class="form-group">
                <label class="form-label">Логин или Email</label>
                <input type="text" name="login" class="form-input" 
                       placeholder="Введите логин" required 
                       autocomplete="username" autofocus>
            </div>

            <div class="form-group">
                <label class="form-label">Пароль</label>
                <input type="password" name="password" class="form-input" 
                       placeholder="Пароль" required 
                       autocomplete="current-password">
            </div>

            <button type="submit" class="btn-submit">
                ⚔️ Войти
            </button>

            <div class="auth-footer">
                Нет аккаунта? <a href="<?= BASE_URL ?>/auth/register">Создать</a>
            </div>
            <?php endif; ?>
        </form>
    </div>

    <!-- Особенности -->
    <div class="features-list">
        <div class="feature-item">
            <span class="feature-icon">⚔️</span>
            <span>Битвы</span>
        </div>
        <div class="feature-item">
            <span class="feature-icon">🏕️</span>
            <span>Племя</span>
        </div>
        <div class="feature-item">
            <span class="feature-icon">📈</span>
            <span>Прокачка</span>
        </div>
    </div>
</div>

<style>
* { box-sizing: border-box; margin: 0; padding: 0; }

.auth-wrapper {
    min-height: 100vh;
    background: linear-gradient(180deg, #1a1a2e 0%, #0f0f1a 100%);
    padding: 20px 15px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.auth-box {
    background: #16213e;
    border: 2px solid #2d2d44;
    border-radius: 12px;
    padding: 25px 20px;
    width: 100%;
    max-width: 400px;
    margin-bottom: 20px;
}

.auth-header {
    text-align: center;
    margin-bottom: 25px;
}

.game-logo {
    font-size: 4rem;
    display: block;
    margin-bottom: 10px;
}

.auth-title {
    color: #c9a962;
    font-size: 1.5rem;
    font-weight: bold;
}

.error-box {
    background: rgba(220, 53, 69, 0.2);
    border: 1px solid #dc3545;
    color: #ff6b6b;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 20px;
    font-size: 0.9rem;
}

.auth-form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.form-label {
    color: #a0a0a0;
    font-size: 0.85rem;
    font-weight: bold;
}

.form-input {
    background: #1f2940;
    border: 1px solid #2d2d44;
    border-radius: 8px;
    padding: 12px 15px;
    color: #e8e8e8;
    font-size: 1rem;
    width: 100%;
}

.form-input:focus {
    outline: none;
    border-color: #c9a962;
}

.form-input::placeholder {
    color: #6c757d;
}

.btn-submit {
    background: linear-gradient(180deg, #c9a962 0%, #a08840 100%);
    color: #0f0f1a;
    border: none;
    border-radius: 8px;
    padding: 14px 20px;
    font-size: 1rem;
    font-weight: bold;
    cursor: pointer;
    margin-top: 10px;
    transition: transform 0.2s;
}

.btn-submit:active {
    transform: scale(0.98);
}

.auth-footer {
    text-align: center;
    color: #a0a0a0;
    font-size: 0.85rem;
    margin-top: 15px;
    padding-top: 15px;
    border-top: 1px solid #2d2d44;
}

.auth-footer a {
    color: #c9a962;
}

.features-list {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap;
    max-width: 400px;
}

.feature-item {
    background: #16213e;
    border: 1px solid #2d2d44;
    border-radius: 8px;
    padding: 15px 20px;
    text-align: center;
    min-width: 80px;
}

.feature-icon {
    font-size: 2rem;
    display: block;
    margin-bottom: 5px;
}

.feature-item {
    color: #a0a0a0;
    font-size: 0.85rem;
}
</style>
