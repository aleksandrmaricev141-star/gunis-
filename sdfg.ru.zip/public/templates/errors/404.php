<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title ?? 'Страница не найдена') ?> - СКИФЫ</title>
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/css/reset.css">
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/css/main.css">
</head>
<body>
    <div class="error-page">
        <div class="container">
            <div class="error-content">
                <div class="error-icon">⚠️</div>
                <h1 class="error-title">404</h1>
                <p class="error-message">
                    <?php echo e($message ?? 'Такой страницы не существует'); ?>
                </p>
                <p class="error-description">
                    Похоже, вы забрели в неизведанные земли Дикого Поля...
                </p>
                <div class="error-actions">
                    <a href="<?= BASE_URL ?>/" class="btn btn-primary">
                        🏠 На главную
                    </a>
                    <a href="javascript:history.back()" class="btn btn-secondary">
                        ⬅️ Назад
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <style>
        .error-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--color-bg-dark) 0%, var(--color-bg-primary) 100%);
        }
        
        .error-content {
            text-align: center;
            padding: 40px 20px;
        }
        
        .error-icon {
            font-size: 5rem;
            margin-bottom: 20px;
        }
        
        .error-title {
            font-size: 8rem;
            color: var(--color-accent-gold);
            margin: 0;
            line-height: 1;
        }
        
        .error-message {
            font-size: 1.5rem;
            color: var(--color-text-primary);
            margin: 20px 0 10px;
        }
        
        .error-description {
            color: var(--color-text-secondary);
            margin-bottom: 30px;
        }
        
        .error-actions {
            display: flex;
            gap: 15px;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        @media (max-width: 480px) {
            .error-title {
                font-size: 5rem;
            }
            
            .error-message {
                font-size: 1.2rem;
            }
            
            .error-actions {
                flex-direction: column;
            }
            
            .error-actions .btn {
                width: 100%;
                max-width: 250px;
            }
        }
    </style>
</body>
</html>
