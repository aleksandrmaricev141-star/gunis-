<?php
/**
 * Шаблон: Дикое Поле (бой)
 * Мобильный стиль 9:16
 */

$stats = $stats ?? [];
$enemies = $enemies ?? [];
$canFight = $canFight ?? false;
$cooldownSeconds = $cooldownSeconds ?? 0;
?>

<!-- Статус -->
<div class="card">
    <div class="card-header">
        <span class="card-title">⚔️ Дикое Поле</span>
    </div>
    
    <div class="status-info">
        <div class="status-row">
            <span class="status-icon">⚡</span>
            <span>Энергия:</span>
            <span class="status-value"><?= $stats['energy'] ?? 0 ?>/<?= $stats['max_energy'] ?? 10 ?></span>
        </div>
        <div class="status-row">
            <span class="status-icon">📊</span>
            <span>Боёв сегодня:</span>
            <span class="status-value"><?= $stats['battle_count_today'] ?? 0 ?>/<?= MAX_BATTLES_PER_DAY ?></span>
        </div>
        <?php if (!$canFight && $cooldownSeconds > 0): ?>
        <div class="status-row">
            <span class="status-icon">⏳</span>
            <span>Кулдаун:</span>
            <span class="status-value" id="cooldown-timer"><?= gmdate('i:s', $cooldownSeconds) ?></span>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Враги -->
<div class="card">
    <div class="card-header">
        <span class="card-title">👹 Выбрать врага</span>
    </div>

    <?php if (!$canFight): ?>
    <div class="alert alert-error">
        <?php if ($cooldownSeconds > 0): ?>
        ⏳ Отдыхайте! Бой будет доступен через <span id="cooldown-text"><?= gmdate('i:s', $cooldownSeconds) ?></span>
        <?php elseif (($stats['energy'] ?? 0) <= 0): ?>
        ⚡ Недостаточно энергии!
        <?php else: ?>
        📊 Достигнут лимит боёв сегодня!
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <div class="enemies-list">
        <?php foreach ($enemies as $enemy): ?>
        <div class="enemy-card">
            <div class="enemy-header">
                <span class="enemy-icon"><?= $enemy['icon'] ?? '👹' ?></span>
                <div class="enemy-info">
                    <div class="enemy-name"><?= e($enemy['name']) ?></div>
                    <div class="enemy-stats">
                        Ур. <?= $enemy['base_level'] ?> | HP <?= $enemy['base_hp'] ?>
                    </div>
                </div>
                <span class="enemy-category category-<?= $enemy['category'] ?>">
                    <?= $enemy['category'] === 'red' ? '🔥' : '' ?>
                </span>
            </div>
            
            <div class="enemy-rewards">
                <span class="reward">+<?= $enemy['exp_reward'] ?> XP</span>
                <span class="reward bronze">+<?= $enemy['bronze_reward_min'] ?>-<?= $enemy['bronze_reward_max'] ?> 🥉</span>
                <?php if ($enemy['gold_drop_chance'] > 0): ?>
                <span class="reward gold">🥇 <?= round($enemy['gold_drop_chance'] * 100) ?>%</span>
                <?php endif; ?>
            </div>
            
            <?php if ($canFight): ?>
            <button class="btn-fight" onclick="startBattle(<?= $enemy['id'] ?>)">
                ⚔️ В бой
            </button>
            <?php else: ?>
            <button class="btn-fight disabled" disabled>
                🔒 Недоступно
            </button>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Результат боя -->
<div id="battle-result" class="card" style="display: none;">
    <div class="result-content"></div>
</div>

<style>
.status-info {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.status-row {
    display: flex;
    align-items: center;
    gap: 10px;
}

.status-icon {
    font-size: 1.2rem;
}

.status-value {
    margin-left: auto;
    font-weight: bold;
    color: #c9a962;
}

/* Враги */
.enemies-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.enemy-card {
    background: #1f2940;
    border-radius: 8px;
    padding: 12px;
}

.enemy-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 10px;
}

.enemy-icon {
    font-size: 2.5rem;
}

.enemy-info {
    flex: 1;
}

.enemy-name {
    font-weight: bold;
    color: #e8e8e8;
    margin-bottom: 3px;
}

.enemy-stats {
    font-size: 0.75rem;
    color: #a0a0a0;
}

.enemy-category {
    font-size: 1.2rem;
}

.category-red {
    color: #fd7e14;
}

.enemy-rewards {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 10px;
}

.reward {
    font-size: 0.75rem;
    padding: 3px 8px;
    background: #16213e;
    border-radius: 4px;
}

.reward.bronze {
    color: #cd7f32;
}

.reward.gold {
    color: #ffd700;
}

.btn-fight {
    width: 100%;
    background: linear-gradient(180deg, #c9a962 0%, #a08840 100%);
    color: #0f0f1a;
    border: none;
    border-radius: 8px;
    padding: 12px;
    font-weight: bold;
    cursor: pointer;
}

.btn-fight:active {
    transform: scale(0.98);
}

.btn-fight.disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

/* Результат */
.result-content {
    text-align: center;
    padding: 20px;
}

.result-win {
    color: #28a745;
    font-size: 1.5rem;
    font-weight: bold;
}

.result-lose {
    color: #dc3545;
    font-size: 1.5rem;
    font-weight: bold;
}

.result-rewards {
    margin-top: 15px;
    font-size: 1rem;
}
</style>

<script>
let isFighting = false;

async function startBattle(enemyId) {
    if (isFighting) return;
    
    isFighting = true;
    
    try {
        const response = await fetch(window.BASE_URL + '/battle/start', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': window.csrfToken
            },
            body: JSON.stringify({ enemy_id: enemyId })
        });
        
        const result = await response.json();
        
        const resultDiv = document.getElementById('battle-result');
        const contentDiv = resultDiv.querySelector('.result-content');
        
        resultDiv.style.display = 'block';
        
        if (result.win) {
            contentDiv.innerHTML = `
                <div class="result-win">🎉 ${result.message}</div>
                <div class="result-rewards">
                    +${result.exp} опыта<br>
                    +${result.bronze} бронзы
                    ${result.gold > 0 ? '<br>+1 золото 🥇' : ''}
                </div>
            `;
        } else {
            contentDiv.innerHTML = `
                <div class="result-lose">💀 ${result.message}</div>
                <div class="result-rewards">
                    Попробуйте ещё раз!
                </div>
            `;
        }
        
        // Обновление таймера
        setTimeout(() => {
            location.reload();
        }, 3000);
        
    } catch (error) {
        alert('Ошибка: ' + error.message);
        isFighting = false;
    }
}

// Таймер кулдауна
<?php if (!$canFight && $cooldownSeconds > 0): ?>
let seconds = <?= $cooldownSeconds ?>;

const timer = setInterval(() => {
    seconds--;
    
    if (seconds <= 0) {
        clearInterval(timer);
        location.reload();
        return;
    }
    
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    const time = String(mins).padStart(2, '0') + ':' + String(secs).padStart(2, '0');
    
    const timerEl = document.getElementById('cooldown-timer');
    const textEl = document.getElementById('cooldown-text');
    
    if (timerEl) timerEl.textContent = time;
    if (textEl) textEl.textContent = time;
}, 1000);
<?php endif; ?>
</script>
