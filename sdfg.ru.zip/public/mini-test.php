<?php
/**
 * МИНИ-ТЕСТ
 */
require_once __DIR__ . '/../config/config.php';

echo "<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>МИНИ-ТЕСТ</title><style>body{background:#0f0f1a;color:#e8e8e8;padding:20px;font-family:sans-serif;}";
echo ".ok{color:#28a745;}.error{color:#dc3545;}.card{background:#16213e;border:1px solid #2d2d44;border-radius:8px;padding:15px;margin:10px 0;}</style></head><body>";

echo "<h1>🧪 МИНИ-ТЕСТ</h1>";

// Константы
echo "<div class='card'><h2>1. КОНСТАНТЫ</h2>";
echo "<div class='" . (defined('BASE_URL') ? 'ok' : 'error') . "'>BASE_URL: " . (defined('BASE_URL') ? BASE_URL : '❌') . "</div>";
echo "<div class='" . (defined('TEMPLATE_PATH') ? 'ok' : 'error') . "'>TEMPLATE_PATH: " . (defined('TEMPLATE_PATH') ? TEMPLATE_PATH : '❌') . "</div>";
echo "</div>";

// БД
echo "<div class='card'><h2>2. БАЗА ДАННЫХ</h2>";
try {
    $pdo = new PDO(DB_DSN, DB_USER, DB_PASS);
    echo "<div class='ok'>✓ БД: OK</div>";
    
    // Простой запрос
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $count = $stmt->fetchColumn();
    echo "<div>Пользователей: $count</div>";
    
    // Тест позиционных параметров
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->execute([1]);
    $user = $stmt->fetchColumn();
    echo "<div>Пользователь #1: " . ($user ?: 'нет') . "</div>";
    
} catch (PDOException $e) {
    echo "<div class='error'>✗ " . htmlspecialchars($e->getMessage()) . "</div>";
}
echo "</div>";

// Ссылки
echo "<div class='card'><h2>3. ССЫЛКИ</h2>";
echo "<div><a href='" . BASE_URL . "/auth/login'>🔐 Вход</a></div>";
echo "<div><a href='" . BASE_URL . "/auth/register'>📝 Регистрация</a></div>";
echo "</div>";

echo "</body></html>";
