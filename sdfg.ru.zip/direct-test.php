<?php
/**
 * ПРЯМОЙ ТЕСТ - без роутинга
 */

require_once __DIR__ . '/config/config.php';

echo "<!DOCTYPE html>";
echo "<html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>ПРЯМОЙ ТЕСТ</title>";
echo "<style>body{background:#0f0f1a;color:#e8e8e8;padding:20px;font-family:sans-serif;}";
echo ".card{background:#16213e;border:1px solid #2d2d44;border-radius:8px;padding:15px;margin:10px 0;}";
echo ".ok{color:#28a745;}.error{color:#dc3545;}</style></head><body>";

echo "<h1>🧪 ПРЯМОЙ ТЕСТ</h1>";

// Проверка констант
echo "<div class='card'><h2>1. КОНСТАНТЫ</h2>";
echo "<div>BASE_URL: <strong>" . (defined('BASE_URL') ? BASE_URL : '❌ НЕ ОПРЕДЕЛЕНА') . "</strong></div>";
echo "<div>TEMPLATE_PATH: <strong>" . (defined('TEMPLATE_PATH') ? TEMPLATE_PATH : '❌ НЕ ОПРЕДЕЛЕНА') . "</strong></div>";
echo "<div>SRC_PATH: <strong>" . (defined('SRC_PATH') ? SRC_PATH : '❌ НЕ ОПРЕДЕЛЕНА') . "</strong></div>";
echo "</div>";

// Проверка файлов
echo "<div class='card'><h2>2. ФАЙЛЫ</h2>";
$files = [
    'config/config.php' => file_exists(__DIR__ . '/config/config.php'),
    'public/index.php' => file_exists(__DIR__ . '/public/index.php'),
    'src/Controllers/AuthController.php' => file_exists(__DIR__ . '/src/Controllers/AuthController.php'),
    'public/templates/layouts/main.php' => file_exists(__DIR__ . '/public/templates/layouts/main.php'),
    'public/templates/auth/form.php' => file_exists(__DIR__ . '/public/templates/auth/form.php'),
];
foreach ($files as $file => $exists) {
    echo "<div class='" . ($exists ? 'ok' : 'error') . "'>" . ($exists ? '✓' : '✗') . " $file</div>";
}
echo "</div>";

// Проверка БД
echo "<div class='card'><h2>3. БАЗА ДАННЫХ</h2>";
try {
    $pdo = new PDO(DB_DSN, DB_USER, DB_PASS);
    echo "<div class='ok'>✓ Подключение к БД: OK</div>";
    
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo "<div>Таблиц: " . count($tables) . "</div>";
} catch (PDOException $e) {
    echo "<div class='error'>✗ Ошибка: " . htmlspecialchars($e->getMessage()) . "</div>";
}
echo "</div>";

// Проверка сессии
echo "<div class='card'><h2>4. СЕССИЯ</h2>";
echo "<div>Session status: <strong>" . session_status() . "</strong></div>";
echo "<div>Session name: <strong>" . session_name() . "</strong></div>";
echo "</div>";

// Тест роутинга
echo "<div class='card'><h2>5. РОУТИНГ</h2>";
echo "<div><a href='" . BASE_URL . "/'>🏠 Главная</a></div>";
echo "<div><a href='" . BASE_URL . "/auth/login'>🔐 Вход</a></div>";
echo "<div><a href='" . BASE_URL . "/auth/register'>📝 Регистрация</a></div>";
echo "</div>";

echo "</body></html>";
