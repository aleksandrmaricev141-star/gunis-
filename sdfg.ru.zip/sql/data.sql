-- ============================================================
-- СКИФЫ - Тестовые данные для разработки
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ============================================================
-- ТЕСТОВЫЙ АДМИН
-- ============================================================

-- Пароль: admin123 (захэшированный)
INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `is_active`, `is_admin`) VALUES
(1, 'admin', 'admin@skifs.local', '$argon2id$v=19$m=131072,t=4,p=2$ZVdQYkJyb0xJQzNkLk5GTw==$3jKl8mN9pQ2rS5tU6vW7xY8zA1bC2dE3fG4hI5jK6lM', 1, 1);

INSERT INTO `hero_stats` (`user_id`, `level`, `experience`, `fury_steppe`, `blood_nomad`, `copper_scale`, `current_hp`, `energy`, `max_energy`) VALUES
(1, 10, 5000, 50, 300, 30, 300, 10, 10);

INSERT INTO `user_currency` (`user_id`, `bronze`, `gold`, `sacred_koumiss`) VALUES
(1, 100000, 1000, 0);

INSERT INTO `user_materials` (`user_id`, `iron_scrap`, `spirit_tears`, `shard_skull`, `honor_points`) VALUES
(1, 500, 200, 100, 500);

INSERT INTO `user_amulet` (`user_id`, `level`, `bonus_exp_percent`, `bonus_bronze_percent`) VALUES
(1, 5, 10, 10);

INSERT INTO `pvp_rating` (`user_id`, `rating`, `league`, `wins`, `losses`) VALUES
(1, 1500, 'gold', 50, 20);

-- ============================================================
-- ТЕСТОВЫЕ ИГРОКИ
-- ============================================================

INSERT INTO `users` (`username`, `email`, `password_hash`, `is_active`, `created_at`) VALUES
('СкифВоин', 'warrior@skifs.local', '$argon2id$v=19$m=131072,t=4,p=2$ZVdQYkJyb0xJQzNkLk5GTw==$3jKl8mN9pQ2rS5tU6vW7xY8zA1bC2dE3fG4hI5jK6lM', 1, NOW()),
('СтепнойВолк', 'wolf@skifs.local', '$argon2id$v=19$m=131072,t=4,p=2$ZVdQYkJyb0xJQzNkLk5GTw==$3jKl8mN9pQ2rS5tU6vW7xY8zA1bC2dE3fG4hI5jK6lM', 1, NOW()),
('ДочьКургана', 'kurgan@skifs.local', '$argon2id$v=19$m=131072,t=4,p=2$ZVdQYkJyb0xJQzNkLk5GTw==$3jKl8mN9pQ2rS5tU6vW7xY8zA1bC2dE3fG4hI5jK6lM', 1, NOW()),
('ШаманТенгри', 'shaman@skifs.local', '$argon2id$v=19$m=131072,t=4,p=2$ZVdQYkJyb0xJQzNkLk5GTw==$3jKl8mN9pQ2rS5tU6vW7xY8zA1bC2dE3fG4hI5jK6lM', 1, NOW()),
('ЛучникОрда', 'archer@skifs.local', '$argon2id$v=19$m=131072,t=4,p=2$ZVdQYkJyb0xJQzNkLk5GTw==$3jKl8mN9pQ2rS5tU6vW7xY8zA1bC2dE3fG4hI5jK6lM', 1, NOW());

-- Статы для тестовых игроков
INSERT INTO `hero_stats` (`user_id`, `level`, `experience`, `fury_steppe`, `blood_nomad`, `copper_scale`) VALUES
(2, 5, 1500, 25, 200, 15),
(3, 7, 2500, 35, 250, 20),
(4, 10, 5000, 40, 300, 25),
(5, 3, 800, 15, 150, 10),
(6, 8, 3500, 38, 280, 22);

INSERT INTO `user_currency` (`user_id`, `bronze`, `gold`) VALUES
(2, 5000, 50),
(3, 8000, 100),
(4, 15000, 200),
(5, 2000, 20),
(6, 10000, 150);

INSERT INTO `user_materials` (`user_id`, `iron_scrap`, `spirit_tears`) VALUES
(2, 100, 50),
(3, 200, 80),
(4, 300, 150),
(5, 50, 20),
(6, 250, 100);

INSERT INTO `user_amulet` (`user_id`, `level`, `bonus_exp_percent`, `bonus_bronze_percent`) VALUES
(2, 2, 5, 5),
(3, 3, 7, 7),
(4, 5, 10, 10),
(5, 1, 0, 0),
(6, 4, 8, 8);

INSERT INTO `pvp_rating` (`user_id`, `rating`, `league`, `wins`, `losses`) VALUES
(2, 1100, 'silver', 20, 15),
(3, 1250, 'silver', 35, 25),
(4, 1600, 'purple', 60, 30),
(5, 950, 'bronze', 10, 20),
(6, 1400, 'gold', 45, 35);

-- ============================================================
-- ТЕСТОВЫЕ КЛАНЫ
-- ============================================================

INSERT INTO `clans` (`id`, `name`, `tag`, `leader_id`, `description`, `treasury_bronze`, `treasury_gold`, `sacred_koumiss`, `siege_rating`) VALUES
(1, 'Волки Степи', 'WOLF', 2, 'Древнее племя степных волков', 50000, 500, 100, 1500),
(2, 'Всадники Кургана', 'KURG', 3, 'Хранители древних курганов', 75000, 750, 150, 2000),
(3, 'Дети Тенгри', 'TNGR', 4, 'Избранные небесным богом', 100000, 1000, 200, 2500);

-- Участники кланов
INSERT INTO `clan_members` (`clan_id`, `user_id`, `role`, `contribution_bronze`, `contribution_koumiss`) VALUES
-- Волки Степи
(1, 2, 'chief', 10000, 50),
(1, 5, 'warrior', 2000, 10),
-- Всадники Кургана
(2, 3, 'chief', 15000, 75),
(2, 6, 'sotnik', 8000, 40),
-- Дети Тенгри
(3, 4, 'chief', 20000, 100),
(3, 1, 'shaman', 5000, 25);

-- Здания кланов
INSERT INTO `clan_buildings` (`clan_id`, `building_type`, `level`) VALUES
-- Волки Степи
(1, 'chief_tent', 3),
(1, 'horse_tether', 2),
(1, 'sacrificial_fire', 4),
(1, 'smithy', 2),
-- Всадники Кургана
(2, 'chief_tent', 4),
(2, 'horse_tether', 3),
(2, 'sacrificial_fire', 5),
(2, 'merchant_tent', 2),
(2, 'smithy', 3),
(2, 'blood_arena', 1),
-- Дети Тенгри
(3, 'chief_tent', 5),
(3, 'horse_tether', 4),
(3, 'sacrificial_fire', 6),
(3, 'merchant_tent', 3),
(3, 'smithy', 4),
(3, 'tannery', 2),
(3, 'spirit_totem', 3),
(3, 'blood_arena', 2);

-- ============================================================
-- ДОПОЛНИТЕЛЬНЫЕ ПРЕДМЕТЫ
-- ============================================================

INSERT INTO `items` (`name`, `description`, `type`, `rarity`, `min_level`, `base_price`, `can_disassemble`, `disassemble_yield`, `bonus_fury`, `bonus_blood`, `bonus_copper`, `slot_count`) VALUES
-- Оружие высокого уровня
('Копьё Сармата', 'Легендарное копьё с гравировкой', 'weapon_spear', 'purple', 10, 2000, 1, 10, 35, 0, 0, 2),
('Акинак Вождя', 'Меч предводителя племени', 'weapon_akinak', 'orange', 15, 5000, 1, 15, 50, 0, 0, 3),
('Лук Орлиного Глаза', 'Лук с невероятной точностью', 'weapon_bow', 'gold', 20, 10000, 1, 20, 70, 0, 0, 3),
-- Броня высокого уровня
('Шлем Берсерка', 'Шлем из черепа медведя', 'armor_helmet', 'purple', 12, 2500, 1, 12, 0, 100, 20, 2),
('Панцирь Дракона', 'Чешуя мифического дракона', 'armor_chest', 'orange', 18, 8000, 1, 20, 0, 250, 50, 3),
('Сапоги Ветра', 'Неуловимые как степной ветер', 'armor_boots', 'blue', 8, 800, 1, 6, 0, 80, 15, 1),
-- Руны высокого уровня
('Камень Тигра', 'Дух свирепого тигра', 'rune_stone', 'purple', 10, 500, 0, 0, 20, 0, 0, 0),
('Камень Феникса', 'Дух возрождающейся птицы', 'rune_stone', 'orange', 15, 1500, 0, 0, 0, 100, 0, 0),
('Камень Дракона', 'Дух древнего дракона', 'rune_stone', 'gold', 20, 3000, 0, 0, 30, 150, 10, 0),
-- Расходники
('Кумыс Воина', 'Священный напиток степняков', 'consumable', 'green', 1, 50, 0, 0, 0, 50, 0, 0),
('Зелье Ярсоти', 'Временно увеличивает ярость', 'consumable', 'blue', 5, 150, 0, 0, 10, 0, 0, 0),
('Свиток Опыта', 'Древний свиток с знаниями', 'consumable', 'purple', 10, 500, 0, 0, 0, 0, 0, 0);

-- ============================================================
-- ТЕСТОВЫЕ БОИ
-- ============================================================

INSERT INTO `battles` (`user_id`, `enemy_id`, `battle_type`, `result`, `damage_dealt`, `damage_received`, `exp_gained`, `bronze_gained`, `gold_gained`) VALUES
(2, 1, 'pve', 'win', 150, 50, 50, 100, 0),
(2, 2, 'pve', 'win', 200, 80, 75, 150, 0),
(2, 3, 'pve', 'lose', 100, 200, 20, 50, 0),
(3, 4, 'pve', 'win', 300, 100, 100, 200, 5),
(3, 5, 'pve', 'win', 250, 120, 90, 180, 0),
(4, 6, 'pve', 'win', 500, 150, 200, 400, 10),
(4, 7, 'pve', 'win', 600, 200, 300, 500, 15),
(5, 1, 'pve', 'win', 100, 30, 30, 80, 0),
(6, 3, 'pve', 'win', 350, 130, 120, 250, 5);

-- ============================================================
-- ТЕСТОВЫЕ КВЕСТЫ
-- ============================================================

INSERT INTO `campaign_chapters` (`name`, `description`, `order_num`, `min_level`, `region`, `trophy_bonus_type`, `trophy_bonus_value`) VALUES
('Северные Пустоши', 'Дикие земли полные опасностей', 1, 1, 'north_wasteland', 'fury', 5),
('Предгорья Кавказа', 'Горные перевалы с древними тайнами', 2, 5, 'caucasus_foothills', 'blood', 50),
('Граница Империи', 'Римские легионы у границ степи', 3, 10, 'empire_border', 'copper', 10);

INSERT INTO `quests` (`chapter_id`, `name`, `description`, `order_num`, `quest_type`, `target_enemy_id`, `target_count`, `exp_reward`, `bronze_reward`, `gold_reward`) VALUES
(1, 'Первая кровь', 'Убейте первых врагов в пустошах', 1, 'kill_count', 1, 5, 100, 200, 0),
(1, 'Охота на кабана', 'Избавьте лагерь от диких кабанов', 2, 'kill_count', 1, 10, 200, 400, 5),
(1, 'Вождь изгоёв', 'Убейте предводителя кочевников-изгоев', 3, 'boss_kill', 2, 1, 500, 1000, 10),
(2, 'Горный дозор', 'Исследуйте горные перевалы', 1, 'kill_count', 3, 15, 400, 800, 15),
(2, 'Древний курган', 'Найдите вход в древний курган', 2, 'battle', NULL, 1, 600, 1200, 20),
(3, 'Римская угроза', 'Отразите нападение легионеров', 1, 'kill_count', 5, 20, 800, 1600, 25),
(3, 'Центурион', 'Победите римского центуриона', 2, 'boss_kill', 6, 1, 1500, 3000, 50);

-- ============================================================
-- ТЕСТОВЫЕ ЕЖЕДНЕВНЫЕ ЗАДАНИЯ
-- ============================================================

INSERT INTO `daily_tasks` (`task_type`, `description`, `target_value`, `exp_reward`, `bronze_reward`, `gold_reward`) VALUES
('win_battles', 'Победить в 10 боях на Диком Поле', 10, 200, 500, 0),
('kill_elite', 'Убить 3 элитных врагов', 3, 300, 200, 10),
('pvp_wins', 'Победить в 5 PvP боях', 5, 400, 300, 0),
('donate_clan', 'Внести 5000 бронзы в казну племени', 5000, 100, 0, 5),
('collect_tears', 'Собрать 100 Слёз Духов', 100, 150, 200, 0);

-- ============================================================
-- ВОССТАНОВЛЕНИЕ AUTO_INCREMENT
-- ============================================================

ALTER TABLE `users` AUTO_INCREMENT = 100;
ALTER TABLE `clans` AUTO_INCREMENT = 10;
ALTER TABLE `items` AUTO_INCREMENT = 100;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- ГОТОВО!
-- ============================================================
-- Тестовый аккаунт админа:
-- Логин: admin
-- Пароль: admin123
--
-- Тестовые игроки (пароль: admin123):
-- СкифВоин, СтепнойВолк, ДочьКургана, ШаманТенгри, ЛучникОрда
-- ============================================================
