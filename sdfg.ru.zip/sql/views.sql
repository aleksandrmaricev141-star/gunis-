-- ============================================================
-- СКИФЫ - Создание представлений (Views)
-- Выполните этот SQL в phpMyAdmin для базы skifs
-- ============================================================

USE skifs;

-- Общий профиль игрока
CREATE OR REPLACE VIEW `v_user_profile` AS
SELECT 
    u.id,
    u.username,
    u.is_premium,
    hs.level,
    hs.experience,
    hs.fury_steppe,
    hs.blood_nomad,
    hs.copper_scale,
    hs.current_hp,
    uc.bronze,
    uc.gold,
    uc.sacred_koumiss,
    cm.clan_id,
    cl.name AS clan_name,
    cm.role AS clan_role
FROM users u
JOIN hero_stats hs ON u.id = hs.user_id
JOIN user_currency uc ON u.id = uc.user_id
LEFT JOIN clan_members cm ON u.id = cm.user_id AND cm.is_approved = 1
LEFT JOIN clans cl ON cm.clan_id = cl.id
WHERE u.is_active = 1 AND u.is_banned = 0;

-- Рейтинг игроков по уровню
CREATE OR REPLACE VIEW `v_level_leaderboard` AS
SELECT 
    u.id,
    u.username,
    hs.level,
    hs.experience,
    cl.name AS clan_name,
    cl.tag AS clan_tag
FROM users u
JOIN hero_stats hs ON u.id = hs.user_id
LEFT JOIN clan_members cm ON u.id = cm.user_id AND cm.is_approved = 1
LEFT JOIN clans cl ON cm.clan_id = cl.id
WHERE u.is_active = 1 AND u.is_banned = 0
ORDER BY hs.experience DESC
LIMIT 100;

-- PvP рейтинг
CREATE OR REPLACE VIEW `v_pvp_leaderboard` AS
SELECT 
    u.id,
    u.username,
    pr.rating,
    pr.league,
    pr.wins,
    pr.losses,
    cl.name AS clan_name
FROM users u
JOIN pvp_rating pr ON u.id = pr.user_id
LEFT JOIN clan_members cm ON u.id = cm.user_id AND cm.is_approved = 1
LEFT JOIN clans cl ON cm.clan_id = cl.id
WHERE u.is_active = 1 AND u.is_banned = 0
  AND pr.season_id = (SELECT id FROM pvp_seasons WHERE is_active = 1 LIMIT 1)
ORDER BY pr.rating DESC
LIMIT 100;

-- Рейтинг кланов
CREATE OR REPLACE VIEW `v_clan_leaderboard` AS
SELECT 
    c.id,
    c.name,
    c.tag,
    c.level,
    c.siege_rating,
    c.total_wins,
    c.total_losses,
    COUNT(cm.id) AS member_count,
    u.username AS leader_name
FROM clans c
JOIN clan_members cm ON c.id = cm.clan_id AND cm.is_approved = 1
JOIN users u ON c.leader_id = u.id
GROUP BY c.id
ORDER BY c.siege_rating DESC, c.level DESC
LIMIT 100;

-- ============================================================
-- ГОТОВО! Проверьте создания представлений:
-- SHOW FULL TABLES WHERE TABLE_TYPE = 'VIEW';
-- ============================================================
