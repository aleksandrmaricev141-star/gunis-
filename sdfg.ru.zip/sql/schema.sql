-- ============================================================
-- СКИФЫ - Браузерная MMO RPG
-- Схема базы данных MySQL 8.0
-- Сеттинг: Скифо-сарматское дарк-фэнтези
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ============================================================
-- ОСНОВНЫЕ ТАБЛИЦЫ ИГРОКОВ
-- ============================================================

-- Таблица пользователей (аккаунты)
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(50) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `password_hash` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `last_login` TIMESTAMP NULL DEFAULT NULL,
    `last_ip` VARCHAR(45) DEFAULT NULL,
    `is_active` TINYINT(1) DEFAULT 1,
    `is_banned` TINYINT(1) DEFAULT 0,
    `ban_reason` VARCHAR(255) DEFAULT NULL,
    `ban_until` TIMESTAMP NULL DEFAULT NULL,
    `is_admin` TINYINT(1) DEFAULT 0,
    `is_premium` TINYINT(1) DEFAULT 0,
    `premium_until` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_username` (`username`),
    UNIQUE KEY `uk_email` (`email`),
    KEY `idx_is_active` (`is_active`),
    KEY `idx_is_banned` (`is_banned`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Статистика героя (основные параметры)
CREATE TABLE IF NOT EXISTS `hero_stats` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `level` INT UNSIGNED DEFAULT 1,
    `experience` BIGINT UNSIGNED DEFAULT 0,
    `experience_to_next` BIGINT UNSIGNED DEFAULT 100,
    `fury_steppe` INT UNSIGNED DEFAULT 10,        -- Ярость Степи (Сила)
    `blood_nomad` INT UNSIGNED DEFAULT 100,        -- Кровь Кочевника (HP)
    `copper_scale` INT UNSIGNED DEFAULT 5,         -- Медная Чешуя (Броня)
    `current_hp` INT UNSIGNED DEFAULT 100,
    `energy` INT UNSIGNED DEFAULT 10,              -- Энергия для боев
    `max_energy` INT UNSIGNED DEFAULT 10,
    `energy_regen_at` TIMESTAMP NULL DEFAULT NULL, -- Время полной регенерации
    `stat_points` INT UNSIGNED DEFAULT 0,          -- Свободные очки для распределения
    `battle_count_today` INT UNSIGNED DEFAULT 0,   -- Счётчик боев сегодня
    `last_battle_time` TIMESTAMP NULL DEFAULT NULL,
    `battle_cooldown_until` TIMESTAMP NULL DEFAULT NULL,
    `last_daily_reset` DATE DEFAULT NULL,          -- Для сброса ежедневных активностей
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_id` (`user_id`),
    KEY `idx_level` (`level`),
    KEY `idx_experience` (`experience`),
    CONSTRAINT `fk_hero_stats_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Валюта игрока
CREATE TABLE IF NOT EXISTS `user_currency` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `bronze` BIGINT UNSIGNED DEFAULT 0,            -- Бронзовые Наконечники
    `gold` INT UNSIGNED DEFAULT 0,                  -- Золото Курганов
    `sacred_koumiss` INT UNSIGNED DEFAULT 0,        -- Священный Кумыс (клановый)
    `koumiss_personal` INT UNSIGNED DEFAULT 0,      -- Личный кумыс (для крафта)
    `last_koumiss_reset` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_id` (`user_id`),
    KEY `idx_bronze` (`bronze`),
    KEY `idx_gold` (`gold`),
    CONSTRAINT `fk_currency_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- ПРЕДМЕТЫ И ИНВЕНТАРЬ
-- ============================================================

-- Справочник предметов
CREATE TABLE IF NOT EXISTS `items` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `type` ENUM('weapon_spear', 'weapon_akinak', 'weapon_bow', 
                'armor_helmet', 'armor_chest', 'armor_boots',
                'rune_stone', 'consumable', 'material', 'trophy', 'quest') NOT NULL,
    `rarity` ENUM('gray', 'green', 'blue', 'purple', 'orange', 'gold') DEFAULT 'gray',
    `min_level` INT UNSIGNED DEFAULT 1,
    `base_price` INT UNSIGNED DEFAULT 0,           -- Базовая цена в бронзе
    `can_trade` TINYINT(1) DEFAULT 1,
    `can_disassemble` TINYINT(1) DEFAULT 0,        -- Можно разобрать на лом
    `disassemble_yield` INT UNSIGNED DEFAULT 0,    -- Количество лома при разборе
    -- Бонусы к статам
    `bonus_fury` INT DEFAULT 0,
    `bonus_blood` INT DEFAULT 0,
    `bonus_copper` INT DEFAULT 0,
    `bonus_exp_percent` INT DEFAULT 0,             -- +% к опыту
    `bonus_bronze_percent` INT DEFAULT 0,          -- +% к бронзе
    `bonus_crit_chance` DECIMAL(4,2) DEFAULT 0,    -- Шанс крита в %
    `bonus_crit_damage` INT DEFAULT 0,             -- +% к криту
    `bonus_armor_penetration` INT DEFAULT 0,       -- Пробивание брони
    `slot_count` INT UNSIGNED DEFAULT 0,           -- Количество слотов для рун
    `icon` VARCHAR(100) DEFAULT 'default.png',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_type` (`type`),
    KEY `idx_rarity` (`rarity`),
    KEY `idx_min_level` (`min_level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Инвентарь игрока
CREATE TABLE IF NOT EXISTS `inventory` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `item_id` INT UNSIGNED NOT NULL,
    `quantity` INT UNSIGNED DEFAULT 1,
    `slot` TINYINT UNSIGNED DEFAULT NULL,          -- 1-6 для экипировки, NULL для рюкзака
    `is_equipped` TINYINT(1) DEFAULT 0,
    `upgrade_level` TINYINT DEFAULT 0,             -- Уровень заточки (+0 до +15)
    `upgrade_exp` INT UNSIGNED DEFAULT 0,          -- Опыт заточки
    `rune_slot_1` INT UNSIGNED DEFAULT NULL,       -- ID камня в слоте 1
    `rune_slot_2` INT UNSIGNED DEFAULT NULL,       -- ID камня в слоте 2
    `rune_slot_3` INT UNSIGNED DEFAULT NULL,       -- ID камня в слоте 3
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_item_slot` (`user_id`, `item_id`, `slot`),
    KEY `idx_equipped` (`is_equipped`),
    CONSTRAINT `fk_inventory_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_inventory_item` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Материалы (Железный Лом и другие ресурсы)
CREATE TABLE IF NOT EXISTS `user_materials` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `iron_scrap` INT UNSIGNED DEFAULT 0,           -- Железный Лом
    `spirit_tears` INT UNSIGNED DEFAULT 0,         -- Слезы Духов (для оберега)
    `shard_skull` INT UNSIGNED DEFAULT 0,          -- Фрагменты черепов (PvP валюта)
    `honor_points` INT UNSIGNED DEFAULT 0,         -- Очки чести (рейтинг)
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_id` (`user_id`),
    CONSTRAINT `fk_materials_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- БОЕВАЯ СИСТЕМА
-- ============================================================

-- Типы врагов (справочник)
CREATE TABLE IF NOT EXISTS `enemy_types` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `category` ENUM('common', 'elite', 'red', 'boss', 'caravan') DEFAULT 'common',
    `base_level` INT UNSIGNED DEFAULT 1,
    `base_hp` INT UNSIGNED DEFAULT 50,
    `base_fury` INT UNSIGNED DEFAULT 5,
    `base_copper` INT UNSIGNED DEFAULT 2,
    `exp_reward` INT UNSIGNED DEFAULT 10,
    `bronze_reward_min` INT UNSIGNED DEFAULT 5,
    `bronze_reward_max` INT UNSIGNED DEFAULT 15,
    `gold_drop_chance` DECIMAL(5,4) DEFAULT 0.0000,
    `item_drop_table` VARCHAR(100) DEFAULT NULL,   -- Ссылка на таблицу лута
    `icon` VARCHAR(100) DEFAULT 'enemy.png',
    PRIMARY KEY (`id`),
    KEY `idx_category` (`category`),
    KEY `idx_level` (`base_level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- История боев
CREATE TABLE IF NOT EXISTS `battles` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `enemy_id` INT UNSIGNED DEFAULT NULL,          -- NULL для PvP
    `opponent_user_id` INT UNSIGNED DEFAULT NULL,  -- Для PvP
    `battle_type` ENUM('pve', 'pvp', 'caravan', 'raid', 'siege') NOT NULL,
    `result` ENUM('win', 'lose', 'draw', 'flee') NOT NULL,
    `damage_dealt` INT UNSIGNED DEFAULT 0,
    `damage_received` INT UNSIGNED DEFAULT 0,
    `crit_count` INT UNSIGNED DEFAULT 0,
    `exp_gained` INT UNSIGNED DEFAULT 0,
    `bronze_gained` INT UNSIGNED DEFAULT 0,
    `gold_gained` INT UNSIGNED DEFAULT 0,
    `items_looted` JSON DEFAULT NULL,              -- JSON с выпавшими предметами
    `battle_log` JSON DEFAULT NULL,                -- Полный лог боя по ходам
    `duration_seconds` INT UNSIGNED DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_battle_type` (`battle_type`),
    KEY `idx_result` (`result`),
    KEY `idx_created_at` (`created_at`),
    CONSTRAINT `fk_battles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Кулдауны и таймеры игрока
CREATE TABLE IF NOT EXISTS `user_timers` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `wild_field_until` TIMESTAMP NULL DEFAULT NULL,    -- КД Дикое Поле
    `pvp_until` TIMESTAMP NULL DEFAULT NULL,           -- КД Кровавый Круг
    `caravan_until` TIMESTAMP NULL DEFAULT NULL,       -- КД на набег на караван
    `daily_reward_at` TIMESTAMP NULL DEFAULT NULL,     -- Ежедневная награда
    `quest_claimable_at` TIMESTAMP NULL DEFAULT NULL,
    `energy_full_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_id` (`user_id`),
    CONSTRAINT `fk_timers_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- КЛАНЫ (ПЛЕМЕНА)
-- ============================================================

-- Племена (кланы)
CREATE TABLE IF NOT EXISTS `clans` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(50) NOT NULL,
    `tag` VARCHAR(10) DEFAULT NULL,
    `leader_id` INT UNSIGNED NOT NULL,
    `description` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `level` INT UNSIGNED DEFAULT 1,
    `exp` BIGINT UNSIGNED DEFAULT 0,
    -- Казна
    `treasury_bronze` BIGINT UNSIGNED DEFAULT 0,
    `treasury_gold` INT UNSIGNED DEFAULT 0,
    `sacred_koumiss` INT UNSIGNED DEFAULT 0,         -- Общий кумыс
    `koumiss_last_reset` TIMESTAMP NULL DEFAULT NULL,
    -- Статистика
    `total_wins` INT UNSIGNED DEFAULT 0,
    `total_losses` INT UNSIGNED DEFAULT 0,
    `siege_rating` INT UNSIGNED DEFAULT 0,           -- Рейтинг для Битвы за Степь
    `is_registered_siege` TINYINT(1) DEFAULT 0,      -- Зарегистрировано на осаду
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_name` (`name`),
    KEY `idx_leader` (`leader_id`),
    KEY `idx_siege_rating` (`siege_rating`),
    CONSTRAINT `fk_clans_leader` FOREIGN KEY (`leader_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Участники клана
CREATE TABLE IF NOT EXISTS `clan_members` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `clan_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED NOT NULL,
    `role` ENUM('chief', 'shaman', 'sotnik', 'warrior', 'young') DEFAULT 'young',
    `joined_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `contribution_bronze` BIGINT UNSIGNED DEFAULT 0, -- Всего внесено бронзы
    `contribution_gold` INT UNSIGNED DEFAULT 0,      -- Всего внесено золота
    `contribution_koumiss` INT UNSIGNED DEFAULT 0,   -- Заработано кумыса для клана
    `pvp_wins` INT UNSIGNED DEFAULT 0,
    `pvp_losses` INT UNSIGNED DEFAULT 0,
    `last_activity` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `is_approved` TINYINT(1) DEFAULT 1,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_clan` (`user_id`, `clan_id`),
    KEY `idx_clan_id` (`clan_id`),
    KEY `idx_role` (`role`),
    CONSTRAINT `fk_clan_members_clan` FOREIGN KEY (`clan_id`) REFERENCES `clans` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_clan_members_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Заявки в клан
CREATE TABLE IF NOT EXISTS `clan_applications` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `clan_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED NOT NULL,
    `message` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    `reviewed_by` INT UNSIGNED DEFAULT NULL,
    `reviewed_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_clan_id` (`clan_id`),
    KEY `idx_status` (`status`),
    CONSTRAINT `fk_applications_clan` FOREIGN KEY (`clan_id`) REFERENCES `clans` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_applications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Здания клана
CREATE TABLE IF NOT EXISTS `clan_buildings` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `clan_id` INT UNSIGNED NOT NULL,
    `building_type` ENUM('chief_tent', 'horse_tether', 'sacrificial_fire', 
                         'merchant_tent', 'smithy', 'tannery', 
                         'spirit_totem', 'blood_arena') NOT NULL,
    `level` INT UNSIGNED DEFAULT 0,
    `upgrade_progress` INT UNSIGNED DEFAULT 0,     -- Прогресс улучшения (0-100%)
    `upgrade_ends_at` TIMESTAMP NULL DEFAULT NULL,
    `last_ritual_at` TIMESTAMP NULL DEFAULT NULL,  -- Время последнего ритуала
    `ritual_type` ENUM('none', 'normal', 'great') DEFAULT 'none',
    `ritual_ends_at` TIMESTAMP NULL DEFAULT NULL,
    `ritual_bonus_percent` INT DEFAULT 0,          -- Текущий бонус от ритуала
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_clan_building` (`clan_id`, `building_type`),
    KEY `idx_building_type` (`building_type`),
    CONSTRAINT `fk_buildings_clan` FOREIGN KEY (`clan_id`) REFERENCES `clans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Лог действий клана
CREATE TABLE IF NOT EXISTS `clan_logs` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `clan_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED DEFAULT NULL,
    `action` ENUM('member_join', 'member_leave', 'member_kick', 
                  'role_change', 'donation', 'building_upgrade', 
                  'ritual_start', 'koumiss_reset', 'siege_register',
                  'treasury_withdraw') NOT NULL,
    `details` JSON DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_clan_id` (`clan_id`),
    KEY `idx_action` (`action`),
    CONSTRAINT `fk_clan_logs_clan` FOREIGN KEY (`clan_id`) REFERENCES `clans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- КВЕСТЫ И КАМПАНИЯ
-- ============================================================

-- Главы кампании
CREATE TABLE IF NOT EXISTS `campaign_chapters` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `order_num` INT UNSIGNED NOT NULL,
    `min_level` INT UNSIGNED DEFAULT 1,
    `region` ENUM('north_wasteland', 'caucasus_foothills', 'empire_border') NOT NULL,
    `trophy_item_id` INT UNSIGNED DEFAULT NULL,    -- ID трофея за главу
    `trophy_bonus_type` VARCHAR(50) DEFAULT NULL,  -- Тип бонуса трофея
    `trophy_bonus_value` INT DEFAULT 0,            -- Значение бонуса
    PRIMARY KEY (`id`),
    KEY `idx_order` (`order_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Квесты
CREATE TABLE IF NOT EXISTS `quests` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `chapter_id` INT UNSIGNED NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `order_num` INT UNSIGNED NOT NULL,
    `quest_type` ENUM('battle', 'kill_count', 'collect_items', 'boss_kill') NOT NULL,
    `target_enemy_id` INT UNSIGNED DEFAULT NULL,   -- Целевой враг
    `target_count` INT UNSIGNED DEFAULT 1,         -- Сколько убить/собрать
    `required_item_id` INT UNSIGNED DEFAULT NULL,  -- Требуемый предмет
    `exp_reward` INT UNSIGNED DEFAULT 0,
    `bronze_reward` INT UNSIGNED DEFAULT 0,
    `gold_reward` INT UNSIGNED DEFAULT 0,
    PRIMARY KEY (`id`),
    KEY `idx_chapter` (`chapter_id`),
    KEY `idx_type` (`quest_type`),
    CONSTRAINT `fk_quests_chapter` FOREIGN KEY (`chapter_id`) REFERENCES `campaign_chapters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Прогресс квестов игрока
CREATE TABLE IF NOT EXISTS `user_quest_progress` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `quest_id` INT UNSIGNED NOT NULL,
    `current_count` INT UNSIGNED DEFAULT 0,
    `status` ENUM('not_started', 'in_progress', 'completed', 'claimed') DEFAULT 'not_started',
    `started_at` TIMESTAMP NULL DEFAULT NULL,
    `completed_at` TIMESTAMP NULL DEFAULT NULL,
    `claimed_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_quest` (`user_id`, `quest_id`),
    KEY `idx_status` (`status`),
    CONSTRAINT `fk_quest_progress_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_quest_progress_quest` FOREIGN KEY (`quest_id`) REFERENCES `quests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Прогресс глав
CREATE TABLE IF NOT EXISTS `user_chapter_progress` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `chapter_id` INT UNSIGNED NOT NULL,
    `status` ENUM('locked', 'available', 'completed') DEFAULT 'locked',
    `completed_at` TIMESTAMP NULL DEFAULT NULL,
    `trophy_claimed` TINYINT(1) DEFAULT 0,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_chapter` (`user_id`, `chapter_id`),
    CONSTRAINT `fk_chapter_progress_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_chapter_progress_chapter` FOREIGN KEY (`chapter_id`) REFERENCES `campaign_chapters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- ОБЕРЕГ ШАМАНА
-- ============================================================

CREATE TABLE IF NOT EXISTS `user_amulet` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `level` INT UNSIGNED DEFAULT 1,
    `experience` BIGINT UNSIGNED DEFAULT 0,
    `experience_to_next` BIGINT UNSIGNED DEFAULT 1000,
    `bonus_exp_percent` INT DEFAULT 0,             -- +% к опыту от оберега
    `bonus_bronze_percent` INT DEFAULT 0,          -- +% к бронзе от оберега
    `bonus_drop_percent` INT DEFAULT 0,            -- +% к шансу дропа
    `fed_spirit_tears` BIGINT UNSIGNED DEFAULT 0,  -- Всего скормлено слез
    `last_feed_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_id` (`user_id`),
    CONSTRAINT `fk_amulet_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- PVP РЕЙТИНГ И ЛИГИ
-- ============================================================

CREATE TABLE IF NOT EXISTS `pvp_rating` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `rating` INT DEFAULT 1000,                     -- Начальный рейтинг
    `league` ENUM('bronze', 'silver', 'gold', 'purple', 'orange') DEFAULT 'bronze',
    `wins` INT UNSIGNED DEFAULT 0,
    `losses` INT UNSIGNED DEFAULT 0,
    `draws` INT UNSIGNED DEFAULT 0,
    `current_season_wins` INT UNSIGNED DEFAULT 0,
    `current_season_losses` INT UNSIGNED DEFAULT 0,
    `highest_rating` INT DEFAULT 1000,
    `last_battle_at` TIMESTAMP NULL DEFAULT NULL,
    `season_id` INT UNSIGNED DEFAULT 1,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_id` (`user_id`),
    KEY `idx_rating` (`rating`),
    KEY `idx_league` (`league`),
    KEY `idx_season` (`season_id`),
    CONSTRAINT `fk_pvp_rating_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Сезоны PvP
CREATE TABLE IF NOT EXISTS `pvp_seasons` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL,
    `start_date` TIMESTAMP NOT NULL,
    `end_date` TIMESTAMP NOT NULL,
    `is_active` TINYINT(1) DEFAULT 0,
    `rewards_distributed` TINYINT(1) DEFAULT 0,
    PRIMARY KEY (`id`),
    KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- ЕЖЕДНЕВНЫЕ ЗАДАНИЯ И ИВЕНТЫ
-- ============================================================

CREATE TABLE IF NOT EXISTS `daily_tasks` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `task_type` ENUM('win_battles', 'kill_elite', 'donate_clan', 
                     'pvp_wins', 'collect_tears', 'upgrade_item') NOT NULL,
    `description` VARCHAR(255) NOT NULL,
    `target_value` INT UNSIGNED DEFAULT 1,
    `exp_reward` INT UNSIGNED DEFAULT 0,
    `bronze_reward` INT UNSIGNED DEFAULT 0,
    `gold_reward` INT UNSIGNED DEFAULT 0,
    `is_active` TINYINT(1) DEFAULT 1,
    PRIMARY KEY (`id`),
    KEY `idx_type` (`task_type`),
    KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Прогресс ежедневных заданий
CREATE TABLE IF NOT EXISTS `user_daily_progress` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `task_id` INT UNSIGNED NOT NULL,
    `current_value` INT UNSIGNED DEFAULT 0,
    `is_completed` TINYINT(1) DEFAULT 0,
    `is_claimed` TINYINT(1) DEFAULT 0,
    `date` DATE NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_task_date` (`user_id`, `task_id`, `date`),
    KEY `idx_date` (`date`),
    CONSTRAINT `fk_daily_progress_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_daily_progress_task` FOREIGN KEY (`task_id`) REFERENCES `daily_tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Активные ивенты сервера
CREATE TABLE IF NOT EXISTS `server_events` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `event_type` ENUM('siege_olbia', 'night_raid', 'blood_circle_tournament') NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `start_time` TIMESTAMP NOT NULL,
    `end_time` TIMESTAMP NOT NULL,
    `is_active` TINYINT(1) DEFAULT 0,
    `participants` JSON DEFAULT NULL,              -- JSON с участниками и их вкладом
    `rewards_distributed` TINYINT(1) DEFAULT 0,
    PRIMARY KEY (`id`),
    KEY `idx_type` (`event_type`),
    KEY `idx_active` (`is_active`),
    KEY `idx_time` (`start_time`, `end_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Участие в осаде Ольвии
CREATE TABLE IF NOT EXISTS `siege_participation` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `event_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED NOT NULL,
    `clan_id` INT UNSIGNED DEFAULT NULL,
    `damage_dealt` BIGINT UNSIGNED DEFAULT 0,
    `battles_count` INT UNSIGNED DEFAULT 0,
    `reward_claimed` TINYINT(1) DEFAULT 0,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_event_user` (`event_id`, `user_id`),
    KEY `idx_event` (`event_id`),
    CONSTRAINT `fk_siege_event` FOREIGN KEY (`event_id`) REFERENCES `server_events` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_siege_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- АДМИН-ПАНЕЛЬ И ЛОГИРОВАНИЕ
-- ============================================================

-- Администраторы
CREATE TABLE IF NOT EXISTS `admins` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `permissions` JSON DEFAULT NULL,               -- JSON с правами доступа
    `last_login` TIMESTAMP NULL DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_id` (`user_id`),
    CONSTRAINT `fk_admins_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Лог действий администраторов
CREATE TABLE IF NOT EXISTS `admin_logs` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `admin_id` INT UNSIGNED NOT NULL,
    `action` VARCHAR(100) NOT NULL,
    `target_user_id` INT UNSIGNED DEFAULT NULL,
    `details` JSON DEFAULT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_admin` (`admin_id`),
    KEY `idx_created_at` (`created_at`),
    CONSTRAINT `fk_admin_logs_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Лог транзакций валюты
CREATE TABLE IF NOT EXISTS `currency_logs` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `currency_type` ENUM('bronze', 'gold', 'koumiss') NOT NULL,
    `amount` BIGINT NOT NULL,                      -- Отрицательное для списания
    `balance_after` BIGINT NOT NULL,
    `source` VARCHAR(100) NOT NULL,                -- battle, quest, trade, admin, etc.
    `details` JSON DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_user` (`user_id`),
    KEY `idx_type` (`currency_type`),
    KEY `idx_created_at` (`created_at`),
    CONSTRAINT `fk_currency_logs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- НАЧАЛЬНЫЕ ДАННЫЕ
-- ============================================================

-- Стартовый сезон PvP
INSERT INTO `pvp_seasons` (`name`, `start_date`, `end_date`, `is_active`) VALUES
('Сезон 1: Волчья Степь', NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY), 1);

-- Типы врагов (примеры)
INSERT INTO `enemy_types` (`name`, `description`, `category`, `base_level`, `base_hp`, `base_fury`, `base_copper`, `exp_reward`, `bronze_reward_min`, `bronze_reward_max`, `gold_drop_chance`) VALUES
('Дикий Кабан', 'Голодный зверь из северных пустошей', 'common', 1, 50, 8, 3, 10, 5, 12, 0.0000),
('Кочевник-изгой', 'Изгнанный из племени за трусость', 'common', 2, 70, 10, 5, 15, 8, 18, 0.0000),
('Греческий Дезертир', 'Бывший гоплит, ставший мародёром', 'common', 3, 90, 12, 6, 20, 10, 22, 0.0000),
('Разбойник с большой дороги', 'Опасный преступник с ножом', 'common', 4, 110, 14, 7, 25, 12, 26, 0.0000),
('Наёмник из Ольвии', 'Профессиональный воин', 'common', 5, 130, 16, 8, 30, 15, 30, 0.0000),
('Центурион-отступник', 'Бывший римский офицер', 'red', 10, 500, 40, 25, 200, 100, 200, 0.1000),
('Вождь чужого племени', 'Легендарный воин севера', 'red', 15, 800, 60, 35, 400, 200, 400, 0.1500),
('Римский Караван', 'Торговый обоз с охраной', 'caravan', 5, 300, 20, 15, 100, 50, 150, 0.0500);

-- Ежедневные задания (шаблоны)
INSERT INTO `daily_tasks` (`task_type`, `description`, `target_value`, `exp_reward`, `bronze_reward`, `gold_reward`, `is_active`) VALUES
('win_battles', 'Победить в боях на Диком Поле', 5, 100, 200, 0, 1),
('kill_elite', 'Убить элитного врага (красного)', 1, 150, 100, 5, 1),
('pvp_wins', 'Победить в Кровавом Круге', 3, 200, 150, 0, 1),
('donate_clan', 'Внести пожертвование в казну племени', 1000, 50, 0, 2, 1),
('collect_tears', 'Собрать Слезы Духов с врагов', 50, 100, 100, 0, 1);

-- ============================================================
-- ПРЕДМЕТЫ (ПРИМЕРЫ)
-- ============================================================

INSERT INTO `items` (`name`, `description`, `type`, `rarity`, `min_level`, `base_price`, `can_disassemble`, `disassemble_yield`, `bonus_fury`, `bonus_blood`, `bonus_copper`, `slot_count`) VALUES
-- Оружие
('Ржавое Копьё', 'Старое копьё, видевшее многие битвы', 'weapon_spear', 'gray', 1, 50, 1, 2, 5, 0, 0, 0),
('Острое Копьё Скифа', 'Надёжное оружие степного воина', 'weapon_spear', 'green', 3, 150, 1, 3, 10, 0, 0, 0),
('Копьё Волка', 'Копьё с наконечником в форме волчьей головы', 'weapon_spear', 'blue', 5, 400, 1, 5, 18, 0, 0, 1),
('Акинак Новичка', 'Простой скифский меч', 'weapon_akinak', 'gray', 1, 40, 1, 2, 4, 0, 0, 0),
('Акинак Ветерана', 'Меч опытного воина', 'weapon_akinak', 'green', 4, 200, 1, 4, 12, 0, 0, 0),
('Степной Лук', 'Лук из рога и дерева', 'weapon_bow', 'gray', 2, 80, 1, 2, 6, 0, 0, 0),
('Лук Орла', 'Точный лук с орлиным пером', 'weapon_bow', 'blue', 6, 500, 1, 5, 20, 0, 0, 1),
-- Броня
('Кожаный Шлем', 'Простая защита головы', 'armor_helmet', 'gray', 1, 30, 1, 1, 0, 10, 2, 0),
('Медный Шлем', 'Шлем с медными накладками', 'armor_helmet', 'green', 3, 120, 1, 3, 0, 25, 5, 0),
('Шлем Волка', 'Шлем в форме волчьей пасти', 'armor_helmet', 'blue', 7, 450, 1, 5, 0, 50, 10, 1),
('Кожаный Панцирь', 'Доспех из дублёной кожи', 'armor_chest', 'gray', 1, 60, 1, 3, 0, 30, 5, 0),
('Панцирь Кочевника', 'Укреплённый костяными пластинами', 'armor_chest', 'green', 4, 250, 1, 5, 0, 60, 12, 0),
('Медная Чешуя Вождя', 'Дорогой доспех с золотыми узорами', 'armor_chest', 'purple', 10, 1000, 1, 10, 0, 150, 30, 2),
('Кожаные Сапоги', 'Обычные походные сапоги', 'armor_boots', 'gray', 1, 25, 1, 1, 0, 15, 2, 0),
('Сапоги Ветра', 'Лёгкие сапоги для быстрого бега', 'armor_boots', 'blue', 5, 350, 1, 4, 0, 40, 8, 1),
-- Руны
('Камень Медведя', 'Дух древнего медведя', 'rune_stone', 'green', 2, 100, 0, 0, 5, 20, 0, 0),
('Камень Змеи', 'Дух ядовитой змеи', 'rune_stone', 'green', 3, 120, 0, 0, 8, 0, 3, 0),
('Камень Орла', 'Дух горного орла', 'rune_stone', 'blue', 5, 300, 0, 0, 12, 0, 0, 0),
('Камень Волка', 'Дух степного волка', 'rune_stone', 'blue', 6, 350, 0, 0, 10, 30, 0, 0),
-- Материалы
('Железный Лом', 'Металл для заточки', 'material', 'gray', 1, 10, 0, 0, 0, 0, 0, 0),
('Слезы Духов', 'Мистическая субстанция для оберега', 'material', 'purple', 1, 50, 0, 0, 0, 0, 0, 0),
('Фрагмент Черепа', 'Трофей с поверженного врага', 'material', 'green', 1, 25, 0, 0, 0, 0, 0, 0);

-- ============================================================
-- ТРИГГЕРЫ И СОБЫТИЯ
-- ============================================================

-- Событие для ежесуточного сброса боевого счётчика
DELIMITER $$

CREATE EVENT IF NOT EXISTS `daily_battle_reset`
ON SCHEDULE EVERY 1 DAY
STARTS CURDATE() + INTERVAL 1 DAY
DO
BEGIN
    UPDATE `hero_stats` 
    SET `battle_count_today` = 0, 
        `last_daily_reset` = CURDATE()
    WHERE `last_daily_reset` < CURDATE() OR `last_daily_reset` IS NULL;
    
    UPDATE `user_timers`
    SET `daily_reward_at` = NOW()
    WHERE `daily_reward_at` < NOW() OR `daily_reward_at` IS NULL;
END$$

-- Событие для еженедельного обнуления Священного Кумыса (воскресенье 23:59)
CREATE EVENT IF NOT EXISTS `weekly_koumiss_reset`
ON SCHEDULE EVERY 1 WEEK
STARTS DATE_SUB(NEXT_DAY(NOW(), 'SUNDAY'), INTERVAL 1 SECOND)
DO
BEGIN
    -- Логгирование перед обнулением (можно добавить в clan_logs)
    UPDATE `clans` 
    SET `sacred_koumiss` = 0,
        `koumiss_last_reset` = NOW();
    
    UPDATE `user_currency`
    SET `sacred_koumiss` = 0,
        `last_koumiss_reset` = NOW();
END$$

-- Событие для проверки окончания PvP сезона
CREATE EVENT IF NOT EXISTS `pvp_season_check`
ON SCHEDULE EVERY 1 HOUR
DO
BEGIN
    UPDATE `pvp_seasons`
    SET `is_active` = 0,
        `rewards_distributed` = 0
    WHERE `end_date` < NOW()
      AND `is_active` = 1;
END$$

DELIMITER ;

-- ============================================================
-- ПРЕДСТАВЛЕНИЯ (VIEWS) ДЛЯ БЫСТРОЙ СТАТИСТИКИ
-- ============================================================

-- Общий профиль игрока
CREATE OR REPLACE VIEW `v_user_profile` AS
SELECT 
    u.id,
    u.username,
    u.is_premium,
    hs.level,
    hs.experience,
    hs.fury_steppe,
    hs.blood_nomad,
    hs.copper_scale,
    hs.current_hp,
    uc.bronze,
    uc.gold,
    uc.sacred_koumiss,
    cm.clan_id,
    cl.name AS clan_name,
    cm.role AS clan_role
FROM users u
JOIN hero_stats hs ON u.id = hs.user_id
JOIN user_currency uc ON u.id = uc.user_id
LEFT JOIN clan_members cm ON u.id = cm.user_id AND cm.is_approved = 1
LEFT JOIN clans cl ON cm.clan_id = cl.id
WHERE u.is_active = 1 AND u.is_banned = 0;

-- Рейтинг игроков по уровню
CREATE OR REPLACE VIEW `v_level_leaderboard` AS
SELECT 
    u.id,
    u.username,
    hs.level,
    hs.experience,
    cl.name AS clan_name,
    cl.tag AS clan_tag
FROM users u
JOIN hero_stats hs ON u.id = hs.user_id
LEFT JOIN clan_members cm ON u.id = cm.user_id AND cm.is_approved = 1
LEFT JOIN clans cl ON cm.clan_id = cl.id
WHERE u.is_active = 1 AND u.is_banned = 0
ORDER BY hs.experience DESC
LIMIT 100;

-- PvP рейтинг
CREATE OR REPLACE VIEW `v_pvp_leaderboard` AS
SELECT 
    u.id,
    u.username,
    pr.rating,
    pr.league,
    pr.wins,
    pr.losses,
    cl.name AS clan_name
FROM users u
JOIN pvp_rating pr ON u.id = pr.user_id
LEFT JOIN clan_members cm ON u.id = cm.user_id AND cm.is_approved = 1
LEFT JOIN clans cl ON cm.clan_id = cl.id
WHERE u.is_active = 1 AND u.is_banned = 0
  AND pr.season_id = (SELECT id FROM pvp_seasons WHERE is_active = 1 LIMIT 1)
ORDER BY pr.rating DESC
LIMIT 100;

-- Рейтинг кланов
CREATE OR REPLACE VIEW `v_clan_leaderboard` AS
SELECT 
    c.id,
    c.name,
    c.tag,
    c.level,
    c.siege_rating,
    c.total_wins,
    c.total_losses,
    COUNT(cm.id) AS member_count,
    u.username AS leader_name
FROM clans c
JOIN clan_members cm ON c.id = cm.clan_id AND cm.is_approved = 1
JOIN users u ON c.leader_id = u.id
GROUP BY c.id
ORDER BY c.siege_rating DESC, c.level DESC
LIMIT 100;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- КОНЕЦ СХЕМЫ
-- ============================================================
