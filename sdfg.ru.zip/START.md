# 🏹 СКИФЫ - ЗАПУСК

## ✅ Чек-лист установки

### 1. Проверьте файлы
- ✅ `config/config.php` - существует
- ✅ `public/index.php` - существует
- ✅ `.htaccess` - существует
- ✅ `public/.htaccess` - существует

### 2. База данных
```sql
-- 1. Создайте пользователя (в MySQL)
CREATE USER 'skifs'@'localhost' IDENTIFIED BY 'skifs123';

-- 2. Создайте базу данных
CREATE DATABASE skifs CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 3. Дайте права
GRANT ALL PRIVILEGES ON skifs.* TO 'skifs'@'localhost';
FLUSH PRIVILEGES;

-- 4. Импортируйте схему
-- Откройте phpMyAdmin → skifs → Импорт → sql/schema.sql

-- 5. (Опционально) Импортируйте данные
-- sql/data.sql
```

### 3. Настройте конфиг
Откройте `config/config.php`, найдите строки 19-23:

```php
define('DB_USER', 'skifs');        // Ваше имя пользователя MySQL
define('DB_PASS', 'skifs123');     // Ваш пароль MySQL
```

**Впишите ваши данные!**

### 4. Проверка
Откройте в браузере:
```
http://sdfg.ru/check.php
```

Должно быть:
- ✅ Версия PHP: 8.x
- ✅ Расширение pdo_mysql: ✓
- ✅ Подключение к MySQL: ✓
- ✅ База данных "skifs": найдена

### 5. Запуск игры
```
http://sdfg.ru/auth/register
```

Зарегистрируйте первого героя!

---

## 🔧 Если что-то не работает

### Ошибка БД
```
SQLSTATE[HY000] [1045] Access denied
```
→ Проверьте `DB_USER` и `DB_PASS` в `config/config.php`

### 404 на всех страницах
→ Проверьте `.htaccess`
→ Убедитесь, что mod_rewrite включён в Apache

### Белый экран
→ Откройте `config/config.php`
→ Установите `define('DEBUG', true);`
→ Проверьте `logs/` на ошибки

### Сессии не работают
→ Проверьте права на папку `cache/`
→ Очистите куки браузера

---

## 📞 Быстрая помощь

1. Откройте `http://sdfg.ru/check.php`
2. Посмотрите на ошибки
3. Проверьте `logs/{сегодня}.log`

---

**Готово? Откройте `http://sdfg.ru/` и начните играть! 🎮**
